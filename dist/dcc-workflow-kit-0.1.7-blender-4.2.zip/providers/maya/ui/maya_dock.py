# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya's docking model: every Maya panel is its own area or window, torn off by its ::::: handle
(docs/steps/step_116.md 「계획」).

Maya builds every UI element as a dockable ``workspaceControl``; the right column is one tab stack of Channel Box /
Layer Editor, Attribute Editor and Modeling Toolkit, and a panel's
dotted handle tears it off into a floating window. Here:

- **Dock areas.** A Maya panel lives in its own Properties editor on the Tool tab, header and tab column hidden (the
  Tool tab draws 3D View "Tool"-category panels, step 106), never in the viewport's sidebar. The area's role is kept
  in the space's hidden tab flags (``ROLE_FLAGS``: Tool tab + one flag), so it survives saving and ``area_dupli``
  (measured: the copy keeps context, flags and the hidden header). The Tool Settings dock (``tool_dock``) is the
  Tool tab with no role flag.
- **Stack.** The ``STACK`` area shows Maya's vertical tab strip on its right edge (step 142) and the selected tab
  (``WindowManager.allset_dock``); kinds that have a floating window leave the strip.
- **Tear off / dock.** The handle row (``ALLSET_OT_dock_handle``) on a docked panel opens a floating window with only
  that panel (``area_dupli`` + role); on a floating panel it offers Dock (close the window, the panel goes back) and
  Close. A floating window closed by its OS button docks back by itself (the stack only hides kinds that float).
  Cross-window drag and drop isn't possible from Python: a click replaces Maya's drag.
- **Menus.** Kit Maya menus start with Maya's dotted tear-off line: a floating ``MENU`` window draws that menu's items
  as buttons (the menu id per window is kept in memory, ``_torn_menus``; a MENU window loaded from a file closes).
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import math
import bpy
from ..compat import property_flags, property_flag, set_property_flag
from bpy.props import EnumProperty, StringProperty
from .. import live_refs
KINDS = ('CHANNEL_BOX', 'ATTRIBUTE_EDITOR', 'MODELING_TOOLKIT')
LABELS = {'CHANNEL_BOX': _dcc_source('Channel Box / Layer Editor'), 'ATTRIBUTE_EDITOR': _dcc_source('Attribute Editor'), 'MODELING_TOOLKIT': _dcc_source('Modeling Toolkit'), 'TOOL_SETTINGS': _dcc_source('Tool Settings'), 'OUTLINER': _dcc_source('Outliner')}
ROLE_FLAGS = {'STACK': 'show_properties_world', 'CHANNEL_BOX': 'show_properties_physics', 'ATTRIBUTE_EDITOR': 'show_properties_effects', 'MODELING_TOOLKIT': 'show_properties_particles', 'MENU': 'show_properties_texture'}
WIDTH = 260
HANDLE = ':' * 8
TEAR_LINE = '- ' * 18
_torn_menus = {}
_pending = {}

def _flags(space):
    return property_flags(space)

def role(area):
    """'STACK' / a KINDS member / 'MENU' for a kit dock area, else None (the Tool Settings dock has no role)."""
    if area is None or area.type != 'PROPERTIES':
        return None
    space = area.spaces.active
    if space.show_region_header or not property_flag(space, 'show_properties_tool'):
        return None
    on = [name for (name, flag) in ROLE_FLAGS.items() if property_flag(space, flag, False)]
    if len(on) != 1:
        return None
    from .. import compat
    if any((property_flag(space, f) for f in _flags(space) if f not in ('show_properties_tool', ROLE_FLAGS[on[0]]) and f not in compat.LATER_PROPERTIES_TABS)):
        return None
    return on[0]

def set_role(area, name, window=None):
    """Make ``area`` (a Properties editor) a kit dock area with role ``name``. True when done; a space that hasn't
    drawn yet can't take the Tool tab, so callers retry (``set_role_later``)."""
    space = area.spaces.active
    try:
        space.context = 'TOOL'
    except TypeError:
        return False
    for flag in _flags(space):
        set_property_flag(space, flag, flag == 'show_properties_tool' or flag == ROLE_FLAGS.get(name))
    space.show_region_header = False
    nav = next((r for r in area.regions if r.type == 'NAVIGATION_BAR'), None)
    if nav is not None and nav.width > 1 and (window is not None) and (not bpy.app.background):
        try:
            with bpy.context.temp_override(window=window, area=area):
                bpy.ops.screen.region_toggle(region_type='NAVIGATION_BAR')
        except (RuntimeError, TypeError):
            pass
    area.tag_redraw()
    return True

def set_role_later(area, name, window=None, tries=40):
    if set_role(area, name, window):
        return
    key = area.as_pointer()
    win_ptr = live_refs.pointer(window)
    _pending[key] = name
    state = {'n': tries}

    def tick():
        (win, area_) = live_refs.find_area(key, win_ptr or None)
        try:
            if area_ is None:
                done = True
            elif win_ptr:
                with bpy.context.temp_override(window=win):
                    done = set_role(area_, name, win)
            else:
                done = set_role(area_, name, None)
        except ReferenceError:
            done = True
        state['n'] -= 1
        if done or state['n'] <= 0:
            _pending.pop(key, None)
            return None
        return 0.05
    bpy.app.timers.register(tick, first_interval=0.0)

def area_role(context):
    return role(getattr(context, 'area', None))

def is_floating(window, wm=None):
    """A window holding a single area (Maya's floating panel), not the first window."""
    wm = wm or bpy.context.window_manager
    return window is not None and len(window.screen.areas) == 1 and (wm.windows[0] != window)

def floating_kinds(wm=None):
    wm = wm or bpy.context.window_manager
    out = set()
    for window in wm.windows:
        for area in window.screen.areas:
            r = role(area)
            if r in KINDS:
                out.add(r)
    return out

def stack_tabs(wm=None):
    floating = floating_kinds(wm)
    return [k for k in KINDS if k not in floating]

def current_tab(wm=None):
    wm = wm or bpy.context.window_manager
    tabs = stack_tabs(wm)
    want = getattr(wm, 'allset_dock', 'CHANNEL_BOX')
    return want if want in tabs else tabs[0] if tabs else None

def shown_kind(context):
    """The Maya panel this dock area shows (None: nothing)."""
    r = area_role(context)
    if r == 'STACK':
        return current_tab(context.window_manager)
    return r

def find_stack(screen):
    """The tab-stack area of ``screen`` (also one made this tick whose role is still pending)."""
    return next((a for a in (screen.areas if screen else ()) if role(a) == 'STACK' or _pending.get(a.as_pointer()) == 'STACK'), None)

def kind_visible(wm, kind):
    """The panel shows somewhere: the selected tab of a stack, or a floating window of its own."""
    if kind in floating_kinds(wm):
        return True
    if current_tab(wm) != kind:
        return False
    return any((find_stack(w.screen) is not None for w in wm.windows))

def _main_view(screen):
    from .status_line import main_view3d
    return main_view3d(screen)

def main_window(wm=None):
    """The window with the main Maya viewport (the first non-floating window)."""
    wm = wm or bpy.context.window_manager
    for window in wm.windows:
        if not is_floating(window, wm) and _main_view(window.screen)[0] is not None:
            return window
    return wm.windows[0] if wm.windows else None

def split_side(context, window, side, width, ui_type):
    """Split ``window``'s main viewport and return the new area on ``side`` ('LEFT' / 'RIGHT') of ``width`` unscaled
    px (measured: VERTICAL factor < 0.5 = new area left, factor > 0.5 = new area right, ``1 - factor`` wide)."""
    screen = window.screen
    (area, region) = _main_view(screen)
    if area is None or region is None:
        return None
    scale = context.preferences.system.ui_scale or 1.0
    share = min(0.4, width * scale / max(area.width, 1))
    factor = share if side == 'LEFT' else 1.0 - share
    before = {a.as_pointer() for a in screen.areas}
    with context.temp_override(window=window, screen=screen, area=area, region=region):
        if bpy.ops.screen.area_split(direction='VERTICAL', factor=factor) != {'FINISHED'}:
            return None
    new = next((a for a in screen.areas if a.as_pointer() not in before), None)
    if new is not None:
        new.ui_type = ui_type
    return new

def open_stack(context, window=None):
    """The stack area right of ``window``'s viewport (made if missing)."""
    window = window or main_window(context.window_manager)
    if window is None:
        return None
    stack = find_stack(window.screen)
    if stack is not None:
        return stack
    new = split_side(context, window, 'RIGHT', WIDTH, 'PROPERTIES')
    if new is not None:
        set_role_later(new, 'STACK', window)
    return new

def close_area(context, window, area):
    """``screen.area_close`` (GUI only: it hangs in background)."""
    if bpy.app.background or area is None:
        return False
    with context.temp_override(window=window, screen=window.screen, area=area):
        return bpy.ops.screen.area_close() == {'FINISHED'}

def close_window_later(window):
    """Close a window from a timer (closing the window an operator runs in would pull the context away)."""
    ptr = live_refs.pointer(window)

    def tick():
        window = live_refs.window(ptr)
        try:
            if window is not None:
                with bpy.context.temp_override(window=window):
                    bpy.ops.wm.window_close()
        except (ReferenceError, RuntimeError):
            pass
        return None
    bpy.app.timers.register(tick, first_interval=0.0)

def show(context, kind):
    """Maya Windows > ... : raise the panel (stack tab), else open it floating when the layout has no stack."""
    wm = context.window_manager
    wm.allset_dock = kind
    if kind in floating_kinds(wm):
        return 'FLOATING'
    window = main_window(wm)
    if window is not None and find_stack(window.screen) is not None:
        redraw()
        return 'DOCKED'
    for w in wm.windows:
        if is_floating(w, wm) and role(w.screen.areas[0]) in KINDS:
            set_role(w.screen.areas[0], kind, w)
            redraw()
            return 'FLOATING'
    return 'FLOATING' if open_floating(context, kind) is not None else None

def toggle(context, kind, show_only=False):
    """Maya Windows > UI Elements toggle: a hidden or tabbed-behind panel is raised; a shown one is hidden (its
    floating window closed, or the tab stack closed when it is the stack's tab). Returns True = shown after."""
    wm = context.window_manager
    if kind_visible(wm, kind):
        if show_only:
            return True
        for window in list(wm.windows):
            if is_floating(window, wm) and role(window.screen.areas[0]) == kind:
                close_window_later(window)
                return False
        window = main_window(wm)
        stack = find_stack(window.screen) if window is not None else None
        if stack is not None:
            close_area(context, window, stack)
        return False
    window = main_window(wm)
    if window is not None and find_stack(window.screen) is None and (_main_view(window.screen)[0] is not None):
        wm.allset_dock = kind
        with context.temp_override(window=window):
            open_stack(bpy.context, window)
        return True
    return show(context, kind) is not None

def open_floating(context, kind):
    """A floating window with only ``kind`` (no stack to raise it in)."""
    from ..operators.menu_extras import open_window
    window = context.window or main_window(context.window_manager)
    if window is None:
        return None
    area = max(window.screen.areas, key=lambda a: a.width * a.height, default=None)
    if area is None:
        return None
    new = open_window(context, area)
    if new is None:
        return None
    target = new.screen.areas[0]
    target.ui_type = 'PROPERTIES'
    set_role_later(target, kind, new)
    return new
MIN_ROWS = 6
PAD_ROWS = 1.5
MIN_KEEP_PX = 40

def content_height(context, n_rows, limit):
    """Window height (px) for ``n_rows`` rows of content, clamped to [MIN_ROWS rows, ``limit``]."""
    from . import layout_measure
    rows = max(MIN_ROWS, (n_rows or 0) + PAD_ROWS)
    return min(layout_measure.px(rows, context), limit)

def panel_rows(context, area=None):
    """Rows the Maya panel in ``area`` draws now (estimated for the Outliner / Tool Settings), or None."""
    from . import layout_measure
    area = area or context.area
    if area is not None and area.type == 'OUTLINER':
        n = sum((1 for _ in context.scene.objects)) + 7
        return min(n, 40)
    if role(area) is None:
        from . import tool_dock
        return 24 if tool_dock.is_dock(area) else None
    return layout_measure.rows(ALLSET_PT_maya_dock.draw, context)

def menu_rows(context, idname):
    """Rows a torn-off menu window shows: handle + title + the menu's items."""
    from . import layout_measure
    cls = getattr(bpy.types, idname, None)
    if cls is None:
        return None
    _drawing_torn[0] = True
    try:
        n = layout_measure.rows(cls.draw, context)
    finally:
        _drawing_torn[0] = False
    return None if n is None else n + 2

def sized_window(context, window, area, height, then, tries=20):
    """Open a window copying ``area`` about ``height`` px tall (the area's full height when it isn't taller), then
    call ``then(new_window)`` (now or from a timer). Returns True when a window is (being) made."""
    from ..operators.menu_extras import open_window
    if bpy.app.background or area is None:
        return False
    full = area.height
    if height >= full - MIN_KEEP_PX:
        with context.temp_override(window=window):
            new = open_window(bpy.context, area)
        if new is None:
            return False
        then(new)
        return True
    screen = window.screen
    before = {a.as_pointer() for a in screen.areas}
    factor = 1.0 - height / max(full, 1)
    with context.temp_override(window=window, screen=screen, area=area):
        if bpy.ops.screen.area_split(direction='HORIZONTAL', factor=factor) != {'FINISHED'}:
            return False
    piece_ptr = next((a.as_pointer() for a in screen.areas if a.as_pointer() not in before), None)
    if piece_ptr is None:
        return False
    state = {'n': tries}
    win_ptr = window.as_pointer()

    def tick():
        try:
            wm = bpy.context.window_manager
            win = next((w for w in wm.windows if w.as_pointer() == win_ptr), None)
            if win is None:
                return None
            piece = next((a for a in win.screen.areas if a.as_pointer() == piece_ptr), None)
            if piece is None:
                return None
            if piece.height <= 1 and state['n'] > 0:
                state['n'] -= 1
                return 0.02
            with bpy.context.temp_override(window=win):
                new = open_window(bpy.context, piece)
            close_area(bpy.context, win, piece)
            if new is not None:
                then(new)
        except ReferenceError:
            pass
        return None
    bpy.app.timers.register(tick, first_interval=0.02)
    return True

def _area_by_pointer(window, ptr):
    try:
        return next((a for a in window.screen.areas if a.as_pointer() == ptr), None)
    except ReferenceError:
        return None

def tear_off(context, area=None):
    """Tear the panel in ``area`` off into a floating window sized to the panel (issue #4). Returns True when the
    window is (being) made, None when this area can't be torn off."""
    from . import tool_dock
    area = area or context.area
    window = context.window
    wm = context.window_manager
    r = role(area)
    if r != 'STACK' and (not (area is not None and (tool_dock.is_dock(area) or area.type == 'OUTLINER'))):
        return None
    height = content_height(context, panel_rows(context, area), area.height)
    area_ptr = area.as_pointer()
    if r == 'STACK':
        kind = current_tab(wm)
        if kind is None:
            return None
        rest = [k for k in stack_tabs(wm) if k != kind]

        def then(new):
            set_role_later(new.screen.areas[0], kind, new)
            if rest:
                bpy.context.window_manager.allset_dock = rest[0]
            else:
                close_area(bpy.context, window, _area_by_pointer(window, area_ptr))
            redraw()
        return True if sized_window(context, window, area, height, then) else None
    outliner = area.type == 'OUTLINER'

    def then(new):
        if outliner:
            from . import maya_outliner
            maya_outliner.setup(new.screen.areas[0].spaces.active)
        close_area(bpy.context, window, _area_by_pointer(window, area_ptr))
    return True if sized_window(context, window, area, height, then) else None

def dock(context, window=None):
    """Put the floating panel in ``window`` back into the main window's layout and close the window."""
    window = window or context.window
    area = window.screen.areas[0] if window and window.screen.areas else None
    if area is None:
        return False
    r = role(area)
    main = main_window(context.window_manager)
    main_ptr = live_refs.pointer(main)
    if r == 'MENU':
        _torn_menus.pop(window.as_pointer(), None)
    elif r in KINDS:
        close_window_later(window)

        def back():
            main = live_refs.window(main_ptr)
            try:
                bpy.context.window_manager.allset_dock = r
                if main is not None:
                    with bpy.context.temp_override(window=main):
                        open_stack(bpy.context, main)
                redraw()
            except ReferenceError:
                pass
            return None
        bpy.app.timers.register(back, first_interval=0.05)
        return True
    else:
        from . import tool_dock
        kind = 'TOOL_SETTINGS' if tool_dock.is_dock(area) else 'OUTLINER' if area.type == 'OUTLINER' else None
        if kind is None or main is None:
            return False
        close_window_later(window)

        def back():
            main = live_refs.window(main_ptr)
            if main is None:
                return None
            try:
                with bpy.context.temp_override(window=main):
                    if kind == 'TOOL_SETTINGS':
                        tool_dock.open_dock(bpy.context, main)
                    elif not any((a.type == 'OUTLINER' for a in main.screen.areas)):
                        new = split_side(bpy.context, main, 'LEFT', WIDTH, 'OUTLINER')
                        if new is not None:
                            from . import maya_outliner
                            maya_outliner.setup(new.spaces.active)
            except ReferenceError:
                pass
            return None
        bpy.app.timers.register(back, first_interval=0.05)
        return True
    close_window_later(window)
    return True

def tear_menu(context, idname, label):
    """Maya's menu tear-off: a floating window listing the menu's items, as tall as the menu (issue #4)."""
    window = main_window(context.window_manager) or context.window
    side = [a for a in window.screen.areas if a.type in {'PROPERTIES', 'OUTLINER'} and a.height > 200]
    area = max(side, key=lambda a: a.height) if side else _main_view(window.screen)[0]
    if area is None:
        return None
    with context.temp_override(window=window):
        height = content_height(bpy.context, menu_rows(bpy.context, idname), area.height)

    def then(new):
        _torn_menus[new.as_pointer()] = (idname, label)
        target = new.screen.areas[0]
        target.ui_type = 'PROPERTIES'
        set_role_later(target, 'MENU', new)
    with context.temp_override(window=window):
        return True if sized_window(bpy.context, window, area, height, then) else None

def redraw():
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'PROPERTIES':
                    area.tag_redraw()
    except (AttributeError, ReferenceError):
        pass

class ALLSET_OT_dock_handle(bpy.types.Operator):
    """Maya panel handle: click to tear this panel off into a floating window; on a floating panel, dock it back"""
    bl_translation_context = 'MWK:ui/maya_dock.py:546'
    bl_idname = 'allset.dock_handle'
    bl_label = _zh_native('Panel Handle', 'MWK:ui/maya_dock.py:546')
    bl_description = _zh_native('Maya panel handle: click to tear this panel off into a floating window; on a floating panel, dock it back', 'MWK:ui/maya_dock.py:546')
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        if is_floating(context.window, context.window_manager):
            context.window_manager.popup_menu(_draw_float_menu, title=_dcc_display(_float_title(context)))
            return {'FINISHED'}
        return self.execute(context)

    def execute(self, context):
        if tear_off(context) is None:
            self.report({'WARNING'}, _zh("This panel can't be torn off", 'MWK:ui/maya_dock.py:557'))
            return {'CANCELLED'}
        return {'FINISHED'}

def _float_title(context):
    r = area_role(context)
    if r in LABELS:
        return LABELS[r]
    if r == 'MENU':
        return _torn_menus.get(context.window.as_pointer(), ('', _dcc_source('Menu')))[1]
    return LABELS['OUTLINER'] if context.area and context.area.type == 'OUTLINER' else LABELS['TOOL_SETTINGS']

def _draw_float_menu(self, context):
    layout = self.layout
    if area_role(context) != 'MENU':
        layout.operator(ALLSET_OT_dock_back.bl_idname, text=_zh('Dock', 'MWK:ui/maya_dock.py:574'), icon='DOCUMENTS').action = 'DOCK'
    layout.operator(ALLSET_OT_dock_back.bl_idname, text=_zh('Close', 'MWK:ui/maya_dock.py:575'), icon='X').action = 'CLOSE'

class ALLSET_OT_dock_back(bpy.types.Operator):
    """Dock this floating panel again (or close it)"""
    bl_translation_context = 'MWK:ui/maya_dock.py:581'
    bl_idname = 'allset.dock_back'
    bl_label = _zh_native('Dock Panel', 'MWK:ui/maya_dock.py:581')
    bl_description = _zh_native('Dock this floating panel again (or close it)', 'MWK:ui/maya_dock.py:581')
    bl_options = {'INTERNAL'}
    action: EnumProperty(items=_zh_enum((('DOCK', 'Dock', ''), ('CLOSE', 'Close', '')), 'MWK:ui/maya_dock.py:584'), options={'SKIP_SAVE'}, translation_context='MWK:ui/maya_dock.py:584')

    def execute(self, context):
        if self.action == 'CLOSE':
            _torn_menus.pop(context.window.as_pointer(), None)
            close_window_later(context.window)
            return {'FINISHED'}
        return {'FINISHED'} if dock(context) else {'CANCELLED'}

class ALLSET_OT_dock_tab(bpy.types.Operator):
    """Show this panel in the tab stack"""
    bl_translation_context = 'MWK:ui/maya_dock.py:597'
    bl_idname = 'allset.dock_tab'
    bl_label = _zh_native('Dock Tab', 'MWK:ui/maya_dock.py:597')
    bl_description = _zh_native('Show this panel in the tab stack', 'MWK:ui/maya_dock.py:597')
    bl_options = {'INTERNAL'}
    kind: EnumProperty(items=_zh_enum([(k, LABELS[k], '') for k in KINDS], 'MWK:ui/maya_dock.py:600'), translation_context='MWK:ui/maya_dock.py:600')

    def execute(self, context):
        context.window_manager.allset_dock = self.kind
        redraw()
        return {'FINISHED'}

class ALLSET_OT_panel_show(bpy.types.Operator):
    """Show this Maya panel: raise it where it is docked, else open it as a floating window (Maya Windows menu)"""
    bl_translation_context = 'MWK:ui/maya_dock.py:611'
    bl_idname = 'allset.panel_show'
    bl_label = _zh_native('Show Panel', 'MWK:ui/maya_dock.py:611')
    bl_description = _zh_native('Show this Maya panel: raise it where it is docked, else open it as a floating window (Maya Windows menu)', 'MWK:ui/maya_dock.py:611')
    bl_options = {'INTERNAL'}
    panel: EnumProperty(items=_zh_enum([(k, LABELS[k], '') for k in (*KINDS, 'OUTLINER', 'TOOL_SETTINGS')], 'MWK:ui/maya_dock.py:614'), translation_context='MWK:ui/maya_dock.py:614')

    def execute(self, context):
        if self.panel in KINDS:
            return {'FINISHED'} if show(context, self.panel) else {'CANCELLED'}
        wm = context.window_manager
        if self.panel == 'TOOL_SETTINGS':
            from . import tool_dock
            if any((tool_dock.is_dock(a) for w in wm.windows for a in w.screen.areas)):
                return {'FINISHED'}
            tool_dock.toggle(context, show_only=True)
            return {'FINISHED'}
        if any((a.type == 'OUTLINER' for w in wm.windows for a in w.screen.areas)):
            return {'FINISHED'}
        return bpy.ops.allset.open_editor(ui_type='OUTLINER')

class ALLSET_OT_menu_tear_off(bpy.types.Operator):
    """Tear off this menu into a floating window (Maya's dotted line at the top of a menu)"""
    bl_translation_context = 'MWK:ui/maya_dock.py:635'
    bl_idname = 'allset.menu_tear_off'
    bl_label = _zh_native('Tear Off', 'MWK:ui/maya_dock.py:635')
    bl_description = _zh_native("Tear off this menu into a floating window (Maya's dotted line at the top of a menu)", 'MWK:ui/maya_dock.py:635')
    bl_options = {'INTERNAL'}
    menu: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/maya_dock.py:638')

    def execute(self, context):
        cls = getattr(bpy.types, self.menu, None)
        if cls is None:
            return {'CANCELLED'}
        (menu, label) = (self.menu, cls.bl_label)

        def later():
            try:
                tear_menu(bpy.context, menu, label)
            except Exception as ex:
                print(_dcc_source('Maya Workflow Kit: menu tear-off failed:'), ex)
            return None
        bpy.app.timers.register(later, first_interval=0.0)
        return {'FINISHED'}

def draw_tear_line(layout, idname):
    """Maya's dotted first line of a menu (click = tear off)."""
    if _drawing_torn[0]:
        return
    layout.operator(ALLSET_OT_menu_tear_off.bl_idname, text=_zh(TEAR_LINE, 'MWK:ui/maya_dock.py:660'), emboss=False).menu = idname
_drawing_torn = [False]

def draw_handle(layout, context=None, tabs=False):
    """The top row of a Maya panel: Maya's dotted grip (click = tear off / dock) and, in the tab stack, the tabs
    (Maya's title / tab row above the editor's menu bar)."""
    row = layout.row(align=True)
    grip = row.row(align=True)
    grip.alignment = 'LEFT'
    if tabs and context is not None:
        row.alignment = 'LEFT'
        grip.ui_units_x = text_units(context, HANDLE, GRIP_PAD)
    grip.operator(ALLSET_OT_dock_handle.bl_idname, text=_zh(HANDLE, 'MWK:ui/maya_dock.py:680'), emboss=False)
    if tabs and context is not None:
        current = current_tab(context.window_manager)
        for kind in stack_tabs(context.window_manager):
            tab = row.row(align=True)
            tab.ui_units_x = text_units(context, LABELS[kind], TAB_PAD)
            tab.operator(ALLSET_OT_dock_tab.bl_idname, text=_zh(LABELS[kind], 'MWK:ui/maya_dock.py:686'), depress=kind == current).kind = kind
TAB_PAD = 1.0
GRIP_PAD = 1.5

def text_units(context, text, pad):
    """Width of ``text`` in Blender's UI font (11 pt x UI scale) in UI units, plus ``pad`` units."""
    import blf
    system = context.preferences.system
    s = system.ui_scale or 1.0
    u = math.floor(18.0 * s + 0.5) + 2 * system.pixel_size
    blf.size(0, 11.0 * s)
    return blf.dimensions(0, _dcc_display(_zh(text, 'MWK:ui/maya_dock.py:700')))[0] / max(u, 1) + pad
STRIP_PX = 18
STRIP_GAP_PX = 6
STRIP_TOP_PX = 4
TAB_END_PX = 11
TAB_GAP_PX = 2
STRIP_SHADE = 0.63
TAB_SHADE = 0.81
TEXT_LOWERED = 0.62
PANEL_MARGIN_U = 0.4
_drawn = {}
_strip_handle = []

def _ui_unit(scale, pixel_size=1.0):
    from .toolbar_fit import unit
    return unit(scale, pixel_size)

def strip_px(scale):
    return round(STRIP_PX * scale)

def reserved_px(scale):
    """Region px the stack's content leaves free at the right for the strip (strip + gap)."""
    return strip_px(scale) + round(STRIP_GAP_PX * scale)

def area_reserved_px(context):
    """``reserved_px`` in a tab-stack area, else 0 (what a content width rule subtracts from ``region.width``)."""
    if area_role(context) != 'STACK':
        return 0
    return reserved_px(context.preferences.system.ui_scale or 1.0)

def content_factor(width, scale, pixel_size=1.0):
    """Split factor of the stack's content column so it ends ``STRIP_GAP_PX`` left of the strip, for a region
    ``width`` px wide (the panel layout spans the region minus Blender's margin on each side)."""
    margin = PANEL_MARGIN_U * _ui_unit(scale, pixel_size)
    span = width - 2 * margin
    if span <= 1:
        return 1.0
    return max(0.0, min(1.0, (width - reserved_px(scale) - margin) / span))

class StripClear:
    """The stack panel's root layout kept left of the strip: every item drawn into it goes into its own split
    (content | an empty strip column). One split column for everything would move every row: a nested column spaces
    its items by the style's ``buttonspacey``, the panel's root by ``templatespace`` (measured: the Channel Box rows
    came 4 px closer each at UI scale 1.5, and the GUI tests' row offsets missed). Attributes go to the root."""
    __slots__ = ('_root', '_factor')

    def __init__(self, root, factor):
        object.__setattr__(self, '_root', root)
        object.__setattr__(self, '_factor', factor)

    def __getattr__(self, name):
        value = getattr(self._root, name)
        if not callable(value):
            return value

        def call(*args, **kw):
            split = self._root.split(factor=self._factor)
            col = split.column()
            split.column()
            return getattr(col, name)(*args, **kw)
        return call

    def __setattr__(self, name, value):
        setattr(self._root, name, value)

def content_layout(layout, context):
    """The layout the stack's panel draws into: left of the strip."""
    region = context.region
    if region is None or region.width <= 1:
        return layout
    system = context.preferences.system
    f = content_factor(region.width, system.ui_scale or 1.0, system.pixel_size)
    if f <= 0.2 or f >= 1.0:
        return layout
    return StripClear(layout, f)

def strip_tabs(kinds, width, height, scale, measure=None):
    """[(kind, x0, y0, x1, y1)] region rects of the strip's tabs (y up, first tab at the top)."""
    if measure is None:
        from .toolbox import text_px as measure
    x1 = width
    x0 = width - strip_px(scale)
    y = height - round(STRIP_TOP_PX * scale)
    out = []
    for kind in kinds:
        length = math.ceil(measure(LABELS[kind], scale) + 2 * TAB_END_PX * scale)
        out.append((kind, x0, y - length, x1, y))
        y -= length + round(TAB_GAP_PX * scale)
    return out

def strip_hit(kinds, width, height, scale, x, y, measure=None):
    """(inside the strip, kind of the tab at region point (x, y) or None)."""
    if x < width - strip_px(scale) or x > width:
        return (False, None)
    for (kind, _x0, y0, _x1, y1) in strip_tabs(kinds, width, height, scale, measure):
        if y0 <= y <= y1:
            return (True, kind)
    return (True, None)

def tab_drawn(context, kind):
    """Remember the tab a stack area drew; a change resizes the stack Maya's way (toolbox.tab_changed)."""
    area = context.area
    if area is None or kind is None:
        return
    key = area.as_pointer()
    old = _drawn.get(key)
    _drawn[key] = kind
    if old is not None and old != kind and (context.window is not None):
        from . import toolbox
        toolbox.tab_changed(context.window, old, kind)

def _strip_colours(context):
    th = context.preferences.themes[0]
    try:
        back = tuple(th.properties.space.back)[:3]
        text = tuple(th.properties.space.text)[:3]
    except AttributeError:
        (back, text) = ((0.19, 0.19, 0.19), (0.9, 0.9, 0.9))
    lift = dock_lift(context)
    return (tuple((min(1.0, c + lift) for c in back)), text)
MAYA_DOCK_GREY = 68 / 255.0
TINTED_ROLES = {'STACK', 'CHANNEL_BOX', 'ATTRIBUTE_EDITOR', 'MODELING_TOOLKIT'}

def dock_lift(context):
    """The sRGB grey added over a Maya dock (0 when the preference is off or the theme is already as light)."""
    from .. import preferences
    try:
        on = preferences.get().maya_dock_colors
    except Exception:
        on = True
    if not on:
        return 0.0
    th = context.preferences.themes[0]
    try:
        back = tuple(th.properties.space.back)[:3]
    except AttributeError:
        return 0.0
    d = MAYA_DOCK_GREY - max(back)
    return d if 0.0 < d <= 0.2 else 0.0

def draw_tint():
    """Lift a Maya dock area to Maya's grey (``dock_lift``): one additive quad over the WINDOW region."""
    context = bpy.context
    (area, region) = (context.area, context.region)
    if region is None or region.type != 'WINDOW' or role(area) not in TINTED_ROLES:
        return
    d = dock_lift(context)
    if d <= 0.0:
        return
    import gpu
    (w, h) = (region.width, region.height)
    hole = _list_hole(context, region) if shown_kind(context) == 'CHANNEL_BOX' else None
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ADDITIVE')
    try:
        for (x0, y0, x1, y1) in _around(hole, w, h):
            _fill(shader, x0, y0, x1, y1, (d, d, d, 1.0))
    finally:
        gpu.state.blend_set('NONE')

def _around(hole, w, h):
    """Rects covering (0, 0, w, h) except ``hole`` (x0, y0, x1, y1)."""
    if hole is None:
        return [(0, 0, w, h)]
    (x0, y0, x1, y1) = hole
    return [r for r in ((0, 0, w, y0), (0, y1, w, h), (0, y0, x0, y1), (x1, y0, w, y1)) if r[2] > r[0] and r[3] > r[1]]

def dark_span(values, limit):
    """(first, last) index of the values below ``limit`` (0-255), or None."""
    idx = [i for (i, v) in enumerate(values) if v < limit]
    return (idx[0], idx[-1]) if idx else None

def dark_top(values, start, limit, gap):
    """Highest index from ``start`` upward still in the dark block: dark values with no run of more than ``gap``
    lighter ones between them and ``start`` (a selected layer row inside the list doesn't end it)."""
    (top, light) = (start, 0)
    for i in range(start, len(values)):
        if values[i] < limit:
            (top, light) = (i, 0)
        else:
            light += 1
            if light > gap:
                break
    return top
_hole_row = {}

def _list_hole(context, region):
    """The Layer Editor list body (Maya #2a2a2a, Blender's list grey is as dark): left unlifted. Found in the drawn
    pixels — one row near the region bottom for its sides, one column inside its left edge for its top."""
    import gpu
    scale = context.preferences.system.ui_scale or 1.0
    try:
        back = max(tuple(context.preferences.themes[0].properties.space.back)[:3])
    except AttributeError:
        return None
    limit = back * 255.0 - 4.0
    from . import channel_box
    le_top = int(region.height * (1.0 - channel_box.cb_share(region, channel_box._unit(context))))
    fb = gpu.state.active_framebuffer_get()
    key = region.as_pointer()
    first = max(1, round(14 * scale))
    rows = [_hole_row.get(key)] + list(range(first, round(64 * scale), max(1, round(4 * scale))))
    (span, ys) = (None, first)
    for ys in rows:
        if ys is None or le_top <= ys + 10:
            continue
        try:
            row = fb.read_color(0, ys, region.width, 1, 4, 0, 'UBYTE').to_list()
        except ValueError:
            return None
        span = dark_span([px[0] for px in row[0]], limit)
        if span is not None and span[1] - span[0] >= 40 * scale:
            break
        span = None
    if span is None:
        _hole_row.pop(key, None)
        return None
    _hole_row[key] = ys
    (x0, x1) = span
    try:
        col = fb.read_color(x0 + 1, 0, 1, le_top, 4, 0, 'UBYTE').to_list()
    except ValueError:
        return None
    values = [c[0][0] for c in col]
    if values[ys] >= limit:
        return None
    top = dark_top(values, ys, limit, round(30 * scale))
    bottom = ys
    while bottom > 0 and values[bottom - 1] < limit:
        bottom -= 1
    return (x0, bottom, x1 + 1, top + 1)

def draw_strip():
    context = bpy.context
    (area, region) = (context.area, context.region)
    if region is None or region.type != 'WINDOW' or role(area) != 'STACK':
        return
    import blf
    import gpu
    scale = context.preferences.system.ui_scale or 1.0
    current = current_tab(context.window_manager)
    tabs = strip_tabs(stack_tabs(context.window_manager), region.width, region.height, scale)
    (back, text) = _strip_colours(context)
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA')
    x0 = region.width - strip_px(scale)
    _fill(shader, x0, 0, region.width, region.height, (*(c * STRIP_SHADE for c in back), 1.0))
    blf.size(0, 11.0 * scale)
    cap = blf.dimensions(0, _dcc_display(_zh('X', 'MWK:ui/maya_dock.py:989')))[1]
    blf.enable(0, blf.ROTATION)
    blf.rotation(0, -math.pi / 2)
    try:
        for (kind, tx0, ty0, tx1, ty1) in tabs:
            raised = kind == current
            _fill(shader, tx0, ty0, tx1, ty1, (*(back if raised else tuple((c * TAB_SHADE for c in back))), 1.0))
            colour = text if raised else tuple((c * TEXT_LOWERED for c in text))
            blf.color(0, *colour, 1.0)
            blf.position(0, round((tx0 + tx1) / 2 - cap / 2), ty1 - round(TAB_END_PX * scale), 0)
            blf.draw(0, _dcc_display(_zh(LABELS[kind], 'MWK:ui/maya_dock.py:999')))
    finally:
        blf.disable(0, blf.ROTATION)
        gpu.state.blend_set('NONE')

def _fill(shader, x0, y0, x1, y1, rgba):
    from gpu_extras.batch import batch_for_shader
    batch = batch_for_shader(shader, 'TRIS', {'pos': [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]}, indices=[(0, 1, 2), (0, 2, 3)])
    shader.uniform_float('color', rgba)
    batch.draw(shader)

def _strip_callback():
    try:
        draw_tint()
        draw_strip()
    except Exception:
        import traceback
        traceback.print_exc()

class ALLSET_OT_dock_strip_click(bpy.types.Operator):
    """Maya tab strip of the dock: click a tab to raise that panel"""
    bl_translation_context = 'MWK:ui/maya_dock.py:1025'
    bl_idname = 'allset.dock_strip_click'
    bl_label = _zh_native('Dock Tab Strip', 'MWK:ui/maya_dock.py:1025')
    bl_description = _zh_native('Maya tab strip of the dock: click a tab to raise that panel', 'MWK:ui/maya_dock.py:1025')
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.region is not None and context.region.type == 'WINDOW' and (area_role(context) == 'STACK')

    def invoke(self, context, event):
        region = context.region
        wm = context.window_manager
        (inside, kind) = strip_hit(stack_tabs(wm), region.width, region.height, context.preferences.system.ui_scale or 1.0, event.mouse_region_x, event.mouse_region_y)
        if not inside:
            return {'PASS_THROUGH'}
        if kind is not None and kind != current_tab(wm):
            wm.allset_dock = kind
            redraw()
        return {'FINISHED'}

class ALLSET_PT_maya_dock(bpy.types.Panel):
    """A Maya panel in its own dock area or floating window (Channel Box / Layer Editor, Attribute Editor, Modeling
    Toolkit, torn-off menus)"""
    bl_translation_context = 'MWK:ui/maya_dock.py:1052'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _dcc_source('Tool')
    bl_label = _zh_native('Maya Panel', 'MWK:ui/maya_dock.py:1052')
    bl_options = {'HIDE_HEADER'}
    bl_order = -200

    @classmethod
    def poll(cls, context):
        return area_role(context) is not None

    def draw(self, context):
        layout = self.layout
        r = area_role(context)
        if r == 'MENU':
            draw_handle(layout)
            draw_torn_menu(layout, context)
            return
        if r == 'STACK':
            layout = content_layout(layout, context)
        draw_handle(layout, context)
        kind = shown_kind(context)
        if r == 'STACK':
            tab_drawn(context, kind)
        if kind is None:
            layout.label(text=_zh('Every panel of this tab stack is in its own window', 'MWK:ui/maya_dock.py:1076'))
            return
        from . import channel_box
        if kind == 'CHANNEL_BOX':
            units = channel_box.ALLSET_PT_channel_box.body(layout, context)
            channel_box.fill_pane(layout, context, units)
            from . import set_driven_key
            set_driven_key.remember_room(context, units)
            from . import layer_editor
            layer_editor.ALLSET_PT_layer_editor.draw(_Holder(layout), context)
        elif kind == 'ATTRIBUTE_EDITOR':
            from . import attribute_editor
            attribute_editor.draw_panel(layout, context)
        elif kind == 'MODELING_TOOLKIT':
            from . import modeling_toolkit
            modeling_toolkit.draw(layout, context)

def draw_torn_menu(layout, context):
    entry = _torn_menus.get(context.window.as_pointer()) if context.window else None
    if entry is None:
        layout.label(text=_zh('This torn-off menu ended with its session', 'MWK:ui/maya_dock.py:1097'))
        return
    cls = getattr(bpy.types, entry[0], None)
    if cls is None:
        return
    layout.label(text=_zh(entry[1], 'MWK:ui/maya_dock.py:1102'))
    col = layout.column(align=True)
    col.alignment = 'LEFT'
    col.emboss = 'PULLDOWN_MENU'
    _drawing_torn[0] = True
    try:
        cls.draw(_Holder(col), context)
    finally:
        _drawing_torn[0] = False

class _Holder:

    def __init__(self, layout):
        self.layout = layout

def _close_stale_menus():
    """MENU windows restored from a file have no menu to show (the id lives in memory): close them."""
    wm = bpy.context.window_manager
    for window in list(wm.windows):
        if window.as_pointer() in _torn_menus:
            continue
        if len(window.screen.areas) == 1 and role(window.screen.areas[0]) == 'MENU':
            close_window_later(window)
    return None

@bpy.app.handlers.persistent
def _on_load(*_args):
    _torn_menus.clear()
    _drawn.clear()
    if not bpy.app.background:
        bpy.app.timers.register(_close_stale_menus, first_interval=0.2)

def close_floating():
    """Switch to Blender: close windows whose only area is a kit role (they would show Blender's Tool tab)."""
    wm = bpy.context.window_manager
    for window in list(wm.windows):
        if is_floating(window, wm) and role(window.screen.areas[0]) is not None:
            close_window_later(window)
    _torn_menus.clear()
classes = (ALLSET_OT_dock_handle, ALLSET_OT_dock_back, ALLSET_OT_dock_tab, ALLSET_OT_panel_show, ALLSET_OT_menu_tear_off, ALLSET_OT_dock_strip_click, ALLSET_PT_maya_dock)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.app.handlers.load_post.append(_on_load)
    _strip_handle.append(bpy.types.SpaceProperties.draw_handler_add(_strip_callback, (), 'WINDOW', 'POST_PIXEL'))

def unregister():
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    if bpy.app.timers.is_registered(_close_stale_menus):
        bpy.app.timers.unregister(_close_stale_menus)
    while _strip_handle:
        bpy.types.SpaceProperties.draw_handler_remove(_strip_handle.pop(), 'WINDOW')
    _drawn.clear()
    _torn_menus.clear()
    _pending.clear()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
