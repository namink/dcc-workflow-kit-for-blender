# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya Light Linking Editor (Lighting/Shading > Light Linking Editor; Maya Relationship Editor light-centric /
object-centric, Maya 2026): two lists, the left one picks a light (light-centric)
or an object (object-centric), the right one shows what it is linked to — click a row to make / break the link.
A kit popover (keep_open) on ``operators/light_links.py``; Light / Shadow switches between light and shadow links
(Maya's editor has one per kind). Step 179."""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy.props import EnumProperty, StringProperty
from ..operators import light_links as ll
_MODES = [('LIGHT_CENTRIC', _dcc_source('Light Centric'), _dcc_source('Pick a light, link objects to it')), ('OBJECT_CENTRIC', _dcc_source('Object Centric'), _dcc_source('Pick an object, link lights to it'))]

def _current(context):
    wm = context.window_manager
    ob = bpy.data.objects.get(wm.allset_ll_current)
    want_light = wm.allset_ll_mode == 'LIGHT_CENTRIC'
    if ob is not None and ll.is_light(ob) == want_light and (ob.name in context.scene.objects):
        return ob
    for o in context.selected_objects:
        if ll.is_light(o) == want_light and (want_light or ll.linkable(o)):
            return o
    return None

def lists(context):
    """(left objects, right objects) of the editor in its current mode."""
    lights = [o for o in context.scene.objects if ll.is_light(o)]
    objects = [o for o in context.scene.objects if not ll.is_light(o) and ll.linkable(o)]
    if context.window_manager.allset_ll_mode == 'LIGHT_CENTRIC':
        return (lights, objects)
    return (objects, lights)

class ALLSET_PT_light_linking(bpy.types.Panel):
    """Maya Light Linking Editor"""
    bl_translation_context = 'MWK:ui/light_link_editor.py:43'
    bl_idname = 'ALLSET_PT_light_linking'
    bl_label = _zh_native('Light Linking Editor', 'MWK:ui/light_link_editor.py:43')
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 22

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        row = layout.row()
        row.prop(wm, 'allset_ll_mode', expand=True)
        row.prop(wm, 'allset_ll_kind', expand=True)
        (left, right) = lists(context)
        current = _current(context)
        split = layout.split(factor=0.5)
        (col_l, col_r) = (split.column(align=True), split.column(align=True))
        light_centric = wm.allset_ll_mode == 'LIGHT_CENTRIC'
        col_l.label(text=_zh('Light Sources' if light_centric else 'Illuminated Objects', 'MWK:ui/light_link_editor.py:59'))
        col_r.label(text=_zh('Illuminated Objects' if light_centric else 'Light Sources', 'MWK:ui/light_link_editor.py:60'))
        for o in left:
            col_l.operator(ALLSET_OT_light_link_pick.bl_idname, text=_dcc_display(o.name), depress=o == current, icon='LIGHT' if light_centric else 'OBJECT_DATA').name = o.name
        for o in right:
            on = current is not None and (ll.linked(current, o, wm.allset_ll_kind) if light_centric else ll.linked(o, current, wm.allset_ll_kind))
            sub = col_r.row(align=True)
            sub.enabled = current is not None
            op = sub.operator(ll.ALLSET_OT_light_link_toggle.bl_idname, text=_dcc_display(o.name), icon='CHECKBOX_HLT' if on else 'CHECKBOX_DEHLT', depress=on)
            (op.light, op.target) = (current.name, o.name) if light_centric else (o.name, current.name if current else '')
            op.kind = wm.allset_ll_kind
        if not left:
            col_l.label(text=_zh('(none)', 'MWK:ui/light_link_editor.py:74'))

class ALLSET_OT_light_link_pick(bpy.types.Operator):
    """Show this node's links"""
    bl_translation_context = 'MWK:ui/light_link_editor.py:80'
    bl_idname = 'allset.light_link_pick'
    bl_label = _zh_native('Pick', 'MWK:ui/light_link_editor.py:80')
    bl_description = _zh_native("Show this node's links", 'MWK:ui/light_link_editor.py:80')
    bl_options = {'INTERNAL'}
    name: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/light_link_editor.py:83')

    def execute(self, context):
        context.window_manager.allset_ll_current = self.name
        return {'FINISHED'}

class ALLSET_OT_light_linking_editor(bpy.types.Operator):
    """Open the Light Linking Editor (Maya Lighting/Shading > Light Linking Editor)"""
    bl_translation_context = 'MWK:ui/light_link_editor.py:93'
    bl_idname = 'allset.light_linking_editor'
    bl_label = _zh_native('Light Linking Editor', 'MWK:ui/light_link_editor.py:93')
    bl_description = _zh_native('Open the Light Linking Editor (Maya Lighting/Shading > Light Linking Editor)', 'MWK:ui/light_link_editor.py:93')
    bl_options = {'INTERNAL'}
    mode: EnumProperty(items=_zh_enum(_MODES, 'MWK:ui/light_link_editor.py:96'), default='LIGHT_CENTRIC', options={'SKIP_SAVE'}, translation_context='MWK:ui/light_link_editor.py:96')

    def execute(self, context):
        wm = context.window_manager
        wm.allset_ll_mode = self.mode
        cur = _current(context)
        wm.allset_ll_current = cur.name if cur is not None else ''
        bpy.ops.wm.call_panel(name=ALLSET_PT_light_linking.bl_idname, keep_open=True)
        return {'FINISHED'}
classes = (ALLSET_PT_light_linking, ALLSET_OT_light_link_pick, ALLSET_OT_light_linking_editor)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    wm = bpy.types.WindowManager
    wm.allset_ll_mode = EnumProperty(items=_zh_enum(_MODES, 'MWK:ui/light_link_editor.py:114'), name=_zh_native('Mode', 'MWK:ui/light_link_editor.py:114'), default='LIGHT_CENTRIC', translation_context='MWK:ui/light_link_editor.py:114')
    wm.allset_ll_kind = EnumProperty(items=_zh_enum([('LIGHT', 'Light Links', ''), ('SHADOW', 'Shadow Links', '')], 'MWK:ui/light_link_editor.py:115'), name=_zh_native('Links', 'MWK:ui/light_link_editor.py:115'), default='LIGHT', translation_context='MWK:ui/light_link_editor.py:115')
    wm.allset_ll_current = StringProperty(name=_zh_native('Current', 'MWK:ui/light_link_editor.py:117'), translation_context='MWK:ui/light_link_editor.py:117')

def unregister():
    wm = bpy.types.WindowManager
    del wm.allset_ll_current, wm.allset_ll_kind, wm.allset_ll_mode
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
