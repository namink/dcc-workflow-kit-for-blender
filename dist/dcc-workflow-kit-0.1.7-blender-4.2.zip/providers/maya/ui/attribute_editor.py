# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese display integration by namink.
"""Maya Attribute Editor in the 3D View sidebar, sharing the Channel Box dock.

Maya's Attribute Editor; design: docs/steps/step_11.md 「계획」 1, 3.
- Dock mode (``WindowManager.allset_dock``): the sidebar tabs "Channel Box / Layer
  Editor", "Attribute Editor", "Modeling Toolkit" = the tabs of Maya's right dock
  (step 99); Ctrl+A toggles
  (``ShowAttributeEditorOrChannelBox``).
- Node tabs: transform = object, shape = object
  data, one tab per modifier (construction history inputs) and per material.
- Sections and their rows: ``ae_layout`` (Maya template sections, collapse flags
  from Maya's Attribute Editor templates), drawn as ``layout.panel`` sections.
- Joints (step 55): in pose mode the node is the lead pose bone (``channel_box.lead``): a
  ``joint`` tab (ae_layout.JOINT) plus one tab per constraint node, like Maya's
  ``pCube1_parentConstraint1`` (docs/steps/step_55.md 「계획」 5).
- Step 106 (docs/steps/step_106.md 「계획」 3; Maya 2022's Attribute Editor):
  the kit's last extrusion is a ``polyExtrudeFace`` history tab (``H``), modifiers are tabs with Maya node names
  (``MODIFIER_NODES``), and Maya's AE chrome: menu bar List / Selected / Focus / Attributes / Display / Show / Help,
  Focus / Presets / Show / Hide beside the node name, Notes, and Select / Load Attributes / Copy Tab at the bottom.
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import math
import re
import bpy
from bpy.props import EnumProperty, StringProperty
from .. import results
from .. import compat, live_refs
from ..operators import display
from . import ae_layout
from . import cb_entry, channel_box
DOCK_ITEMS = (('CHANNEL_BOX', _dcc_source('Channel Box / Layer Editor'), _dcc_source('Maya Channel Box and Layer Editor')), ('ATTRIBUTE_EDITOR', _dcc_source('Attribute Editor'), _dcc_source('Maya Attribute Editor')), ('MODELING_TOOLKIT', _dcc_source('Modeling Toolkit'), 'Maya Modeling Toolkit (ui/modeling_toolkit.py, step 63)'))

def dock_mode(context):
    return getattr(context.window_manager, 'allset_dock', 'CHANNEL_BOX')

def principled(material):
    if not compat.material_uses_nodes(material):
        return None
    return next((n for n in material.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)

def material_type(material):
    """Maya node type of a material: the type a kit-made material recorded (lambert, blinn,
    phong, standardSurface, surfaceShader; operators/material.py), else standardSurface for a
    Principled material, else "material" (docs/steps/step_38.md 「계획」 4)."""
    if material is None:
        return 'material'
    from ..operators.material import TYPE_PROP
    recorded = material.get(TYPE_PROP)
    if isinstance(recorded, str) and recorded in ae_layout.BY_KIND and principled(material):
        return recorded
    return 'standardSurface' if principled(material) else 'material'

def node_type(ob):
    if ob.type == 'LIGHT':
        return ae_layout.light_type(ob.data)
    return ae_layout.NODE_TYPE.get(ob.type, ob.type.lower())
MODIFIER_NODES = {'SUBSURF': 'polySmoothFace', 'MULTIRES': 'polySmoothFace', 'BEVEL': 'polyBevel3', 'MIRROR': 'polyMirror', 'TRIANGULATE': 'polyTriangulate', 'WELD': 'polyMergeVert', 'DECIMATE': 'polyReduce', 'REMESH': 'polyRemesh', 'SOLIDIFY': 'polyExtrudeFace', 'BOOLEAN': 'polyCBoolOp', 'SMOOTH': 'polyAverageVertex', 'LAPLACIANSMOOTH': 'polyAverageVertex', 'CORRECTIVE_SMOOTH': 'deltaMush', 'ARMATURE': 'skinCluster', 'LATTICE': 'ffd', 'SHRINKWRAP': 'shrinkWrap', 'WIREFRAME': 'polyWireframe', 'ARRAY': 'polyDuplicate', 'CLOTH': 'nCloth', 'COLLISION': 'nRigid', 'PARTICLE_SYSTEM': 'nParticle', 'SOFT_BODY': 'nCloth', 'SIMPLE_DEFORM': 'nonLinear', 'CAST': 'nonLinear', 'WAVE': 'nonLinear', 'DISPLACE': 'textureDeformer', 'SCREW': 'polyRevolve', 'EDGE_SPLIT': 'polySoftEdge', 'WEIGHTED_NORMAL': 'polyNormalPerVertex', 'NODES': 'geometryNodes', 'HOOK': 'cluster', 'SURFACE_DEFORM': 'wrap', 'CURVE': 'curveWarp'}

def modifier_node(ob, md):
    """(Maya node name, Maya node type) of a modifier: a modifier with Blender's automatic name gets Maya's
    (``<type><n>``, numbered per type like Maya: ``polyBevel1``); a named one (kit-made ``polySmoothFace``, the
    user's own) keeps its name."""
    from ..operators import deformers
    kit = deformers.node_type(md)
    if kit is not None:
        return (md.name, kit)
    mtype = MODIFIER_NODES.get(md.type, md.type.lower())
    base = re.sub('\\d+$', '', mtype)
    if not default_name(md):
        return (md.name, mtype)
    same = [m for m in ob.modifiers if MODIFIER_NODES.get(m.type, m.type.lower()) == mtype and (not display.is_preview(m)) and default_name(m)]
    return (f'{base}{same.index(md) + 1}', mtype)

def default_name(md):
    """True for Blender's automatic modifier names ("Bevel", "Subdivision.001", "GeometryNodes")."""
    base = re.sub('\\.\\d+$', '', md.name).replace(' ', '').lower()
    ui = md.bl_rna.properties['type'].enum_items[md.type].name.replace(' ', '').lower()
    return bool(base) and ui.startswith(base)

def history_record(ob):
    """The kit's last extrusion of ``ob`` (Maya polyExtrudeFace node), or None (edit mode only, step 65)."""
    from . import in_view
    try:
        return in_view.cb_record(bpy.context, ob)
    except (AttributeError, ReferenceError):
        return None

def nice_type(mtype):
    """"polyExtrudeFace" -> "Poly Extrude Face" (Maya's history section title is "<Nice Type> History")."""
    return re.sub('(?<!^)(?=[A-Z])', ' ', mtype[:1].upper() + mtype[1:])

def hidden_types(context=None):
    wm = (context or bpy.context).window_manager
    return {t for t in getattr(wm, 'allset_ae_hidden', '').split(',') if t}

def _constraint_tabs(node):
    return [(f'C:{con.name}', channel_box.constraint_node_name(node, con), channel_box.maya_constraint_type(con, con.type.lower())) for con in channel_box.constraints(node)]

def tabs(ob):
    """[(key, label, Maya node type)] in Maya's order: transform, shape, history, materials,
    constraints; a joint (pose bone): joint, constraints."""
    if channel_box.is_bone(ob):
        return [('J', ob.name, 'joint')] + _constraint_tabs(ob)
    out = [('T', ob.name, 'transform')]
    if ob.data is not None:
        out.append(('S', ob.data.name, node_type(ob)))
    rec = history_record(ob)
    if rec is not None:
        out.append(('H', rec.name, rec.spec.node_type))
    from ..operators import skin_tools_199
    for md in ob.modifiers:
        if display.is_preview(md):
            continue
        if skin_tools_199.is_part(md):
            continue
        from ..operators import skin_method
        if skin_method.is_part(md):
            continue
        (name, mtype) = modifier_node(ob, md)
        out.append((f'M:{md.name}', name, mtype))
    from ..operators import prim_history
    (_owner, node) = prim_history.node_of(ob)
    if node is not None:
        out.append(('CH', node['name'], node['type']))
    from ..operators import material as material_ops
    for (i, slot) in enumerate(ob.material_slots):
        if slot.material is not None:
            out.append((f'SG:{i}', material_ops.shading_group_name(slot.material), 'shadingEngine'))
            out.append((f'MAT:{i}', slot.material.name, material_type(slot.material)))
    if has_nucleus(ob):
        out.append(('NUC', 'nucleus1', 'nucleus'))
    out += _constraint_tabs(ob)
    hide = hidden_types()
    return [t for t in out if t[0] in ('T', 'S') or t[2] not in hide]

def has_nucleus(ob):
    """The kit nucleus exists and ``ob`` is simulated by it (cloth, particles, collider, rigid body)."""
    scene = bpy.context.scene
    nuc = getattr(scene, 'allset_nucleus', None)
    if nuc is None or not nuc.exists:
        return False
    return ob.rigid_body is not None or any((md.type in {'CLOTH', 'COLLISION', 'PARTICLE_SYSTEM', 'SOFT_BODY'} for md in ob.modifiers))

def _kind(key):
    return key.split(':', 1)[0]

def current_tab(context, ob):
    """The selected tab key: the stored one, else the first of the stored kind, else
    the shape (Maya's preferred node), else the transform."""
    wm = context.window_manager
    keys = [t[0] for t in tabs(ob)]
    if wm.allset_ae_tab in keys:
        return wm.allset_ae_tab
    for k in keys:
        if _kind(k) == wm.allset_ae_kind:
            return k
    if 'J' in keys:
        return 'J'
    return 'S' if 'S' in keys else 'T'

def tab_target(ob, key):
    """The datablock or modifier a tab shows."""
    kind = _kind(key)
    if kind in ('T', 'J'):
        return ob
    if kind == 'C':
        return ob.constraints.get(key[2:])
    if kind == 'S':
        return ob.data
    if kind == 'M':
        return ob.modifiers.get(key[2:])
    if kind in ('MAT', 'SG'):
        i = int(key.split(':', 1)[1])
        return ob.material_slots[i].material if i < len(ob.material_slots) else None
    if kind == 'NUC':
        return bpy.context.scene.allset_nucleus
    if kind == 'H':
        return history_record(ob)
    if kind == 'CH':
        from ..operators import prim_history
        return prim_history.node_of(ob)[0]
    return None

def sections_for(ob, key):
    """(sections, layout id) for a tab; empty for history tabs (drawn generically)."""
    kind = _kind(key)
    if kind == 'T':
        return (ae_layout.BY_KIND['transform'][0], 'transform')
    if kind == 'J':
        return (ae_layout.BY_KIND['joint'][0], 'joint')
    if kind == 'S':
        sub = ae_layout.light_kind(ob.data) or ob.data.type if ob.type == 'LIGHT' else ob.type
        return (ae_layout.BY_KIND.get(sub, ([], None))[0], sub.lower())
    if kind == 'MAT':
        mat = tab_target(ob, key)
        name = material_type(mat)
        return (ae_layout.BY_KIND[name][0], name)
    if kind == 'NUC':
        return (ae_layout.BY_KIND['nucleus'][0], 'nucleus')
    return ([], None)

def resolve(owner, path):
    """(object, attribute) for a dotted path such as ``overlay.show_face_normals``."""
    (*head, attr) = path.split('.')
    for part in head:
        owner = getattr(owner, part, None)
        if owner is None:
            return (None, attr)
    return (owner, attr)

def _owner(context, ob, target, name):
    if name == 'ob':
        return ob
    if name == 'data':
        return target
    if name == 'view':
        space = context.space_data
        return space if space is not None and space.type == 'VIEW_3D' else None
    if channel_box.is_bone(ob):
        return {'bone': ob.bone, 'arm': ob.id_data.data, 'armob': ob.id_data}.get(name)
    return None

def _length(context, value):
    us = context.scene.unit_settings
    return bpy.utils.units.to_string(us.system, 'LENGTH', value * us.scale_length, precision=3)

def _vector_row(layout, owner, attr, label):
    """Maya AE float3 row: label, then the three fields side by side."""
    split = layout.split(factor=0.3, align=True)
    split.label(text=_zh(label, 'MWK:ui/attribute_editor.py:282'))
    split.row(align=True).prop(owner, attr, text=_dcc_display(''))

def _maya_number_rows(layout, context, ob):
    """Translate / Rotate / Scale as Maya number fields (no unit, never cut to "62 c", #85): the Channel Box text
    proxies, when ``ob`` is the lead and the only selected node (the proxies type into every selected node, the AE
    edits one). False when that doesn't apply."""
    if channel_box.is_bone(ob) or ob is not channel_box.lead(context) or len(channel_box.targets(context)) != 1:
        return False
    if ob.rotation_mode in {'QUATERNION', 'AXIS_ANGLE'}:
        return False
    cb = context.scene.allset_cb
    col = layout.column(align=True)
    for (label, keys) in ((_dcc_source('Translate'), ('tx', 'ty', 'tz')), (_dcc_source('Rotate'), ('rx', 'ry', 'rz')), (_dcc_source('Scale'), ('sx', 'sy', 'sz'))):
        split = col.split(factor=0.3, align=True)
        split.label(text=_zh(label, 'MWK:ui/attribute_editor.py:299'))
        row = split.row(align=True)
        for key in keys:
            row.prop(cb, key + '_text', text=_dcc_display(''))
    return True

def draw_transform_channels(layout, context, ob):
    if _maya_number_rows(layout, context, ob):
        return
    col = layout.column(align=True)
    _vector_row(col, ob, 'location', _dcc_source('Translate'))
    if ob.rotation_mode == 'QUATERNION':
        _vector_row(col, ob, 'rotation_quaternion', _dcc_source('Rotate'))
    elif ob.rotation_mode == 'AXIS_ANGLE':
        _vector_row(col, ob, 'rotation_axis_angle', _dcc_source('Rotate'))
    else:
        _vector_row(col, ob, 'rotation_euler', _dcc_source('Rotate'))
    _vector_row(col, ob, 'scale', _dcc_source('Scale'))

def draw_world_pivot(layout, context, ob):
    col = layout.column(align=True)
    for (axis, value) in zip('XYZ', ob.matrix_world.translation):
        col.label(text=_zh(f'World Rotate Pivot {axis}: {_length(context, value)}', 'MWK:ui/attribute_editor.py:323'))
LIMIT_PROPS = {'LIMIT_LOCATION': ('use_min_{a}', 'min_{a}', 'use_max_{a}', 'max_{a}'), 'LIMIT_SCALE': ('use_min_{a}', 'min_{a}', 'use_max_{a}', 'max_{a}'), 'LIMIT_ROTATION': ('use_limit_{a}', 'min_{a}', 'max_{a}')}

def draw_limit(layout, context, ob, kind):
    con = next((c for c in ob.constraints if c.type == kind), None)
    if con is None:
        layout.operator('allset.ae_add_limit', text=_zh(f"Add {kind.replace('_', ' ').title()}", 'MWK:ui/attribute_editor.py:336')).type = kind
        return
    for a in 'xyz':
        row = layout.row(align=True)
        for pattern in LIMIT_PROPS[kind]:
            row.prop(con, pattern.format(a=a))

def draw_visibility(layout, context, ob):
    if channel_box.is_bone(ob):
        layout.prop(ob.bone, 'hide', text=_zh('Visibility', 'MWK:ui/attribute_editor.py:346'), invert_checkbox=True)
    else:
        layout.prop(ob, 'hide_viewport', text=_zh('Visibility', 'MWK:ui/attribute_editor.py:348'), invert_checkbox=True)
JOINT_AXIS_NOTE = _dcc_source('Bone Y points to the child joint (Maya Primary Axis X)')

def joint_orient(pb):
    """Maya jointOrient (radians, xyz) from the joints' Maya frames (step 244: bone axes turned by
    ``allset_maya_frame``; a top joint against Maya's world axes)."""
    from ..operators import joints
    bone = pb.bone
    frame = joints.maya_bone_frame(bone)
    parent = joints.maya_bone_frame(bone.parent) if bone.parent is not None else joints.armature_world(pb.id_data)
    return (parent.transposed() @ frame).to_euler('XYZ')

def draw_joint_orient(layout, context, pb):
    split = layout.split(factor=0.3, align=True)
    split.label(text=_zh('Joint Orient', 'MWK:ui/attribute_editor.py:366'))
    row = split.row(align=True)
    for v in joint_orient(pb):
        row.label(text=_zh(cb_entry.fmt_number(math.degrees(v)), 'MWK:ui/attribute_editor.py:369'))
    from . import notices
    notices.tip(row, JOINT_AXIS_NOTE)

def draw_joint_stiffness(layout, context, pb):
    split = layout.split(factor=0.3, align=True)
    split.label(text=_zh('Stiffness', 'MWK:ui/attribute_editor.py:376'))
    row = split.row(align=True)
    for a in 'xyz':
        row.prop(pb, f'ik_stiffness_{a}', text=_dcc_display(''))

def draw_shading(layout, context, ob):
    row = layout.row(align=True)
    row.operator('object.shade_smooth', text=_zh('Soften (Smooth)', 'MWK:ui/attribute_editor.py:384'))
    row.operator('object.shade_flat', text=_zh('Harden (Flat)', 'MWK:ui/attribute_editor.py:385'))
    layout.operator('object.shade_auto_smooth', text=_zh('Soften by Angle', 'MWK:ui/attribute_editor.py:386'))

def draw_smooth_mesh(layout, context, ob):
    row = layout.row(align=True)
    for (level, label) in ((1, _dcc_source('1 Off')), (2, _dcc_source('2 Cage')), (3, _dcc_source('3 Smooth'))):
        row.operator('allset.smooth_preview', text=_zh(label, 'MWK:ui/attribute_editor.py:392')).level = level
    sub = display.preview_modifier(ob, create=False)
    if sub is not None:
        layout.prop(sub, 'levels', text=_zh('Division Levels', 'MWK:ui/attribute_editor.py:395'))
        layout.prop(sub, 'render_levels', text=_zh('Render Levels', 'MWK:ui/attribute_editor.py:396'))

def draw_light_decay(layout, context, ob):
    """Maya Decay Rate (operators/lights.py, step 137); where the render can't follow it, the tooltip says why."""
    from ..operators import lights
    from . import notices
    light = getattr(ob, 'data', None)
    if light is None or not hasattr(light, 'allset_decay'):
        return
    row = layout.row(align=True)
    row.prop(light, 'allset_decay', text=_zh(attr_label(context, 'Decay Rate', 'decayRate'), 'MWK:ui/attribute_editor.py:407'))
    notices.tip(row, lights.decay_notice(light))
DRAWERS = {'transform_channels': draw_transform_channels, 'world_pivot': draw_world_pivot, 'visibility': draw_visibility, 'shading': draw_shading, 'smooth_mesh': draw_smooth_mesh, 'joint_orient': draw_joint_orient, 'joint_stiffness': draw_joint_stiffness, 'light_decay': draw_light_decay}

def attr_label(context, label, ident):
    """The row label for Display > Attribute Names: Nice (the label), Long (the property id), Short (its initials)."""
    mode = getattr(context.window_manager, 'allset_ae_names', 'NICE')
    if mode == 'NICE' or not ident:
        return label
    if mode == 'LONG':
        return ident
    parts = [p for p in ident.split('_') if p]
    return ''.join((p[0] for p in parts)) if len(parts) > 1 else ident[:3]

def draw_row(layout, context, ob, target, row):
    kind = row[0]
    if kind == 'prop':
        (_k, owner_name, path, label) = row
        (owner, attr) = resolve(_owner(context, ob, target, owner_name), path)
        if owner is not None and hasattr(owner, attr):
            layout.prop(owner, attr, text=_zh(attr_label(context, label, attr), 'MWK:ui/attribute_editor.py:434'))
    elif kind == 'draw':
        name = row[1]
        if name.startswith('limit:'):
            draw_limit(layout, context, ob, name[6:])
        else:
            DRAWERS[name](layout, context, ob)
    elif kind in {'socket', 'maya'}:
        if kind == 'maya':
            (_k, maya_prop, label, socket) = row
        else:
            (_k, socket, label) = row
            maya_prop = None
        from ..operators import material as _material
        inp = _material.maya_input(target, socket)
        if inp is None:
            if maya_prop is not None and principled(target) is not None and hasattr(target, maya_prop):
                layout.prop(target, maya_prop, text=_zh(label, 'MWK:ui/attribute_editor.py:452'))
            return
        row = layout.row(align=True)
        if inp.is_linked:
            source = inp.links[0].from_node
            row.label(text=_zh(f'{label}: connected ({source.name})', 'MWK:ui/attribute_editor.py:457'))
        elif maya_prop is not None and hasattr(target, maya_prop):
            row.prop(target, maya_prop, text=_zh(label, 'MWK:ui/attribute_editor.py:459'))
        elif hasattr(inp, 'default_value'):
            row.prop(inp, 'default_value', text=_zh(label, 'MWK:ui/attribute_editor.py:461'))
        else:
            row.label(text=_zh(label, 'MWK:ui/attribute_editor.py:463'))
        op = row.operator('allset.ae_map', text=_dcc_display(''), icon='TEXTURE')
        (op.material, op.socket) = (target.name, socket)
        if inp.is_linked and source.type == 'TEX_IMAGE':
            layout.template_ID(source, 'image', new='image.new', open='image.open')
    elif kind == 'missing':
        (_k, label, note) = row
        sub = layout.row()
        sub.enabled = False
        sub.label(text=f'{_dcc_display(label)}: {_dcc_display(note)}')
SECTION_INDENT = 1.2

def section_body(body):
    """The content of an open Attribute Editor section: Maya draws it inset under the section header, in a content
    area of its own shade (Maya 2026 behaviour: 2 px in from each side, one step off the editor's grey;
    #194). The box starts under the section's disclosure arrow, gives the content area its shade and frame; the
    column is what the rows go into."""
    row = body.row()
    row.separator(factor=SECTION_INDENT)
    return row.box().column()

def draw_sections(layout, context, ob, target, sections, layout_id, prefix=''):
    for sec in sections:
        (header, body) = layout.panel(f'allset_ae_{layout_id}_{prefix}{sec.name}', default_closed=not sec.open)
        header.label(text=_dcc_display(sec.name))
        if body is None:
            continue
        col = section_body(body)
        for row in sec.rows:
            draw_row(col, context, ob, target, row)
        if sec.subs:
            draw_sections(col, context, ob, target, sec.subs, layout_id, f'{prefix}{sec.name}/')
_MOD_SKIP = {'rna_type', 'name', 'type', 'show_viewport', 'show_render', 'show_in_editmode', 'show_on_cage', 'show_expanded', 'is_active', 'is_override_data_editable', 'use_apply_on_spline', 'use_pin_to_last', 'persistent_uid', 'execution_time'}

def modifier_props(md):
    out = []
    for p in md.bl_rna.properties:
        ident = p.identifier
        if ident in _MOD_SKIP or p.is_readonly or p.type == 'COLLECTION' or ident.startswith('open_'):
            continue
        out.append(ident)
    return out

def draw_history(layout, context, ob, md):
    (header, body) = layout.panel(f'allset_ae_history_{md.type}', default_closed=False)
    header.label(text=_zh(f'{nice_type(modifier_node(ob, md)[1])} History', 'MWK:ui/attribute_editor.py:522'))
    if body is not None:
        col = section_body(body)
        col.prop(md, 'show_viewport', text=_zh('Enabled (Node State)', 'MWK:ui/attribute_editor.py:525'))
        from ..operators import deformers_205a, deformers_205b
        drawn = deformers_205a.draw_ae(col, md) or deformers_205b.draw_ae(col, md)
        if md.type == 'ARMATURE' and hasattr(ob, 'allset_skinning_method'):
            col.prop(ob, 'allset_skinning_method')
        for ident in [] if drawn else modifier_props(md):
            col.prop(md, ident, text=_zh(attr_label(context, md.bl_rna.properties[ident].name, ident), 'MWK:ui/attribute_editor.py:532'))
    row = layout.row(align=True)
    op = row.operator('allset.ae_modifier', text=_zh('Delete History', 'MWK:ui/attribute_editor.py:534'))
    (op.modifier, op.action) = (md.name, 'APPLY')
    op = row.operator('allset.ae_modifier', text=_zh('Delete', 'MWK:ui/attribute_editor.py:536'), icon='X')
    (op.modifier, op.action) = (md.name, 'REMOVE')
_CON_SKIP = {'rna_type', 'name', 'type', 'show_expanded', 'is_valid', 'active', 'is_override_data_editable', 'is_override_data_local', 'mute', 'enabled', 'influence', 'error_location', 'error_rotation'}

def constraint_props(con):
    return [p.identifier for p in con.bl_rna.properties if p.identifier not in _CON_SKIP and (not p.is_readonly) and (p.type != 'COLLECTION')]

def draw_constraint(layout, context, node, con):
    """A Maya constraint node tab: target weight (= influence), then the constraint's settings."""
    (header, body) = layout.panel(f'allset_ae_constraint_{con.type}', default_closed=False)
    header.label(text=_zh(f'{channel_box.maya_constraint_type(con, con.type.title())} Attributes', 'MWK:ui/attribute_editor.py:553'))
    if body is not None:
        col = section_body(body)
        if hasattr(con, 'enabled'):
            col.prop(con, 'enabled', text=_zh('Enabled (Node State)', 'MWK:ui/attribute_editor.py:557'))
        col.prop(con, 'influence', text=_zh(channel_box.weight_name(con), 'MWK:ui/attribute_editor.py:558'))
        for ident in constraint_props(con):
            col.prop(con, ident, text=_zh(attr_label(context, con.bl_rna.properties[ident].name, ident), 'MWK:ui/attribute_editor.py:560'))

def draw_extra(layout, owner, layout_id):
    keys = [k for k in owner.keys() if not k.startswith(('_', 'allset_', 'cycles'))]
    (header, body) = layout.panel(f'allset_ae_{layout_id}_extra', default_closed=True)
    header.label(text=_zh('Extra Attributes', 'MWK:ui/attribute_editor.py:566'))
    if body is None:
        return
    body = section_body(body)
    if not keys:
        body.label(text=_zh('(none)', 'MWK:ui/attribute_editor.py:571'))
    for k in sorted(keys):
        body.prop(owner, f'["{k}"]', text=_zh(k, 'MWK:ui/attribute_editor.py:573'))

def draw_extrude_history(layout, context, rec):
    """The polyExtrudeFace tab: Maya's "Poly Extrude Face History" with the kit record's values (the same text
    proxies as Channel Box INPUTS, ui/in_view.py); also polyExtrudeEdge / Vertex and polyBevel3 (step 139)."""
    (header, body) = layout.panel('allset_ae_history_extrude', default_closed=False)
    header.label(text=_zh(f'{nice_type(rec.spec.node_type)} History', 'MWK:ui/attribute_editor.py:580'))
    if body is None:
        return
    hist = context.window_manager.allset_history
    col = section_body(body).column(align=True)
    for field in rec.spec.fields:
        split = col.split(factor=0.42, align=True)
        split.label(text=_zh(attr_label(context, rec.spec.labels[field], field), 'MWK:ui/attribute_editor.py:587'))
        split.prop(hist, f'{field}_text', text=_dcc_display(''))

def content_width(context):
    """Px the dock's panel content spans: region minus Blender's panel margins and the Maya tab strip (step 142)."""
    region = getattr(context, 'region', None)
    if region is None or region.width <= 1:
        return None
    from . import maya_dock
    scale = context.preferences.system.ui_scale or 1.0
    unit = maya_dock._ui_unit(scale, context.preferences.system.pixel_size or 1.0)
    return region.width - 2 * maya_dock.PANEL_MARGIN_U * unit - maya_dock.area_reserved_px(context) - 4 * scale

def text_widths(context, labels, extra_units=None):
    """Px a button needs for each label: the text (Blender's UI font size) plus its margins (0.4 widget unit a side)
    and ``extra_units`` widget units (a menu's arrow)."""
    from . import maya_dock
    scale = context.preferences.system.ui_scale or 1.0
    unit = maya_dock._ui_unit(scale, context.preferences.system.pixel_size or 1.0)
    extra_units = extra_units or [0.0] * len(labels)
    try:
        import blf
        blf.size(0, 11 * scale)
        text = [blf.dimensions(0, _dcc_display(_zh(t, 'MWK:ui/attribute_editor.py:612')))[0] for t in labels]
    except Exception:
        text = [len(t) * 7 * scale for t in labels]
    return [w + (1.0 + e) * unit for (w, e) in zip(text, extra_units)]

def wrap_rows(context, labels, equal=True, extra_units=None):
    """``labels`` split into rows that each fit the dock, so no tab / button / menu text is cut ("pCubeS...",
    "Sele...", step 192 dogfood, #104). Maya's AE is wider (460 px) and scrolls its tab bar; the kit dock can be
    narrower (event-simulated sessions don't fit it, users drag it): rows wrap like a narrow Qt bar (delegated).
    ``equal``: an aligned row gives every button the same width, so a row needs n × its widest label; else the
    labels keep their natural widths (left / right aligned rows). Without a region (tests with a fake layout) one
    row."""
    avail = content_width(context) if labels else None
    if avail is None:
        return [list(range(len(labels)))]
    widths = text_widths(context, labels, extra_units)
    (rows, cur) = ([], [])
    for i in range(len(labels)):
        trial = cur + [i]
        need = len(trial) * max((widths[j] for j in trial)) if equal else sum((widths[j] for j in trial))
        if cur and need > avail:
            rows.append(cur)
            trial = [i]
        cur = trial
    rows.append(cur)
    return rows

def tab_window(widths, avail, current, arrows):
    """Maya's AE tab bar is one Qt tab row that scrolls (audit 16 G1): the tabs
    [a, b) shown, ``current`` among them, as many as fit in ``avail`` px; when not all fit, ``arrows`` px are kept
    for the ◀ ▶ buttons. Returns (a, b, overflow). Pure (tests/test_step211_fix_batch.py)."""
    n = len(widths)
    if avail is None or sum(widths) <= avail:
        return (0, n, False)
    room = avail - arrows
    a = b = min(max(current, 0), n - 1)
    used = widths[a]
    b += 1
    while True:
        grew = False
        if b < n and used + widths[b] <= room:
            used += widths[b]
            b += 1
            grew = True
        if a > 0 and used + widths[a - 1] <= room:
            a -= 1
            used += widths[a]
            grew = True
        if not grew:
            return (a, b, True)

def draw_tab_strip(layout, context, ob, current):
    """One row of tabs at their text width, left-aligned like Maya's; a dock too narrow for all of them shows the
    ones around the current tab with ◀ ▶ (previous / next tab, delegated: Qt's arrows only scroll)."""
    items = tabs(ob)
    labels = [label for (_k, label, _t) in items]
    keys = [k for (k, _l, _t) in items]
    cur = keys.index(current) if current in keys else 0
    avail = content_width(context) if labels else None
    if avail is None:
        (a, b, over) = (0, len(items), False)
        widths = None
    else:
        from . import maya_dock
        scale = context.preferences.system.ui_scale or 1.0
        unit = maya_dock._ui_unit(scale, context.preferences.system.pixel_size or 1.0)
        widths = text_widths(context, labels)
        (a, b, over) = tab_window(widths, avail, cur, 2 * unit)
    row = layout.row(align=True)
    if widths is not None:
        row.alignment = 'LEFT'
    if over:
        prev = row.row(align=True)
        prev.enabled = cur > 0
        prev.operator('allset.ae_tab', text=_dcc_display(''), icon='TRIA_LEFT').key = keys[max(cur - 1, 0)]
    for i in range(a, b):
        cell = row.row(align=True)
        if widths is not None:
            cell.ui_units_x = widths[i] / unit
        cell.operator('allset.ae_tab', text=_zh(labels[i], 'MWK:ui/attribute_editor.py:694'), depress=keys[i] == current).key = keys[i]
    if over:
        nxt = row.row(align=True)
        nxt.enabled = cur < len(keys) - 1
        nxt.operator('allset.ae_tab', text=_dcc_display(''), icon='TRIA_RIGHT').key = keys[min(cur + 1, len(keys) - 1)]

def draw(layout, context, ob):
    """The whole Attribute Editor for ``ob`` (also used by tests with a fake layout)."""
    key = current_tab(context, ob)
    draw_tab_strip(layout, context, ob, key)
    target = tab_target(ob, key)
    if target is None:
        return
    entry = next((t for t in tabs(ob) if t[0] == key))
    draw_head(layout, context, ob, key, target, entry)
    kind = _kind(key)
    if kind == 'NUC':
        draw_sections(layout, context, ob, target, ae_layout.NUCLEUS, 'nucleus')
    elif kind == 'SG':
        draw_shading_group(layout, key, target)
    elif kind == 'C':
        draw_constraint(layout, context, ob, target)
    elif kind == 'H':
        draw_extrude_history(layout, context, target)
    elif kind == 'CH':
        from . import creation_inputs
        creation_inputs.draw_ae(layout, context, ob)
    elif kind == 'M':
        draw_history(layout, context, ob, target)
    else:
        (sections, layout_id) = sections_for(ob, key)
        draw_sections(layout, context, ob, target, sections, layout_id or 'data')
        if isinstance(target, (bpy.types.ID, bpy.types.PoseBone)):
            draw_extra(layout, target, layout_id or 'data')
    draw_notes(layout, context, ob, key, entry)
    draw_bottom(layout, context)

def draw_head(layout, context, ob, key, target, entry):
    """Maya's node row: "<type>: [name]" with the in / out arrows, Focus / Presets, Show / Hide
    (tooltips as Maya's)."""
    from . import notices
    kind = _kind(key)
    top = layout.row(align=True)
    head = top.row(align=True)
    head.label(text=f'{_dcc_display(entry[2])}:')
    if kind in ('NUC', 'SG', 'H', 'CH'):
        head.label(text=_zh(entry[1], 'MWK:ui/attribute_editor.py:742'))
        if kind == 'NUC':
            notices.tip(head, ae_layout.NUCLEUS_NOTE)
    elif kind == 'M' and entry[1] != target.name:
        head.label(text=_zh(entry[1], 'MWK:ui/attribute_editor.py:746'))
    else:
        head.prop(target, 'name', text=_dcc_display(''))
    if kind in ('M', 'H', 'CH'):
        sub = head.row(align=True)
        sub.operator('allset.ae_step', text=_dcc_display(''), icon='TRIA_LEFT').forward = False
        sub.operator('allset.ae_step', text=_dcc_display(''), icon='TRIA_RIGHT').forward = True
    buttons = (('op', 'allset.ae_focus', _dcc_source('Focus')), ('menu', 'ALLSET_MT_ae_presets', _dcc_source('Presets')), ('op', 'allset.ae_show_types', _dcc_source('Show')), ('op', 'allset.ae_hide_type', _dcc_source('Hide')))
    for idx in wrap_rows(context, [b[2] for b in buttons], equal=False, extra_units=[1.0 if b[0] == 'menu' else 0.0 for b in buttons]):
        row = layout.row(align=True)
        row.alignment = 'RIGHT'
        for i in idx:
            (kind, ident, text) = buttons[i]
            if kind == 'menu':
                row.menu(ident, text=_zh(text, 'MWK:ui/attribute_editor.py:764'))
            else:
                row.operator(ident, text=_zh(text, 'MWK:ui/attribute_editor.py:766'))
    return head
NOTES_PROP = 'allset_notes'

def notes_owner(ob, key):
    """(ID-property owner, key) where the Notes of a tab live: the node's own datablock / pose bone, or for
    history / constraint nodes (no ID properties in Blender) the object under ``allset_notes:<tab>``."""
    if ob is None:
        return (None, NOTES_PROP)
    target = tab_target(ob, key)
    if isinstance(target, (bpy.types.ID, bpy.types.PoseBone)) and _kind(key) != 'NUC':
        return (target, NOTES_PROP)
    return (ob, f'{NOTES_PROP}:{key}')

def _current_node(context):
    ob = ae_node(context)
    return (ob, current_tab(context, ob)) if ob is not None else (None, '')

def _notes_get(_self):
    try:
        (ob, key) = _current_node(bpy.context)
        (owner, prop) = notes_owner(ob, key)
        value = owner.get(prop, '') if owner is not None else ''
        return value if isinstance(value, str) else ''
    except (AttributeError, ReferenceError, KeyError):
        return ''

def _notes_set(_self, value):
    (ob, key) = _current_node(bpy.context)
    (owner, prop) = notes_owner(ob, key)
    if owner is None:
        return
    if value:
        owner[prop] = value
    elif prop in owner.keys():
        del owner[prop]

def draw_notes(layout, context, ob, key, entry):
    """Maya's Notes box under the sections (Show > Show Notes)."""
    if not context.window_manager.allset_ae_show_notes:
        return
    layout.separator()
    layout.label(text=_zh(f'Notes:  {entry[1]}', 'MWK:ui/attribute_editor.py:815'))
    layout.prop(context.scene, 'allset_ae_notes', text=_dcc_display(''))
BOTTOM = (('allset.ae_select', _dcc_source('Select')), ('allset.ae_load', _dcc_source('Load Attributes')), ('allset.ae_copy_tab', _dcc_source('Copy Tab')))

def draw_bottom(layout, context=None):
    """Maya's bottom buttons: Select, Load Attributes, Copy Tab (wrapped when the dock is too narrow, step 197)."""
    layout.separator()
    col = layout.column(align=True)
    groups = wrap_rows(context, [t for (_o, t) in BOTTOM]) if context is not None else [list(range(len(BOTTOM)))]
    for idx in groups:
        row = col.row(align=True)
        for i in idx:
            row.operator(BOTTOM[i][0], text=_zh(BOTTOM[i][1], 'MWK:ui/attribute_editor.py:830'))

def draw_shading_group(layout, key, mat):
    """Maya's shading group tab (AEshadingEngineTemplate: Shading Group Attributes): the surface material opens
    its own tab; Blender has no volume / displacement slots of their own on a shading group."""
    (header, box) = layout.panel('ae_shading_group', default_closed=False)
    header.label(text=_zh('Shading Group Attributes', 'MWK:ui/attribute_editor.py:837'))
    if box is None:
        return
    box = section_body(box)
    row = box.row(align=True)
    row.label(text=_zh('Surface Material', 'MWK:ui/attribute_editor.py:842'))
    row.operator('allset.ae_tab', text=_dcc_display(mat.name), icon='MATERIAL').key = 'MAT:' + key.split(':', 1)[1]
    for label in (_dcc_source('Volume Material'), _dcc_source('Displacement Mat.')):
        row = box.row(align=True)
        row.active = False
        row.label(text=_zh(label, 'MWK:ui/attribute_editor.py:847'))
        row.label(text=_dcc_display(''))

def set_tab(context, key):
    wm = context.window_manager
    wm.allset_ae_tab = key
    wm.allset_ae_kind = _kind(key)

class ALLSET_OT_ae_tab(bpy.types.Operator):
    """Show this node in the Attribute Editor"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:862'
    bl_idname = 'allset.ae_tab'
    bl_label = _zh_native('Attribute Editor Tab', 'MWK:ui/attribute_editor.py:862')
    bl_description = _zh_native('Show this node in the Attribute Editor', 'MWK:ui/attribute_editor.py:862')
    bl_options = {'INTERNAL'}
    key: StringProperty(translation_context='MWK:ui/attribute_editor.py:865')

    def execute(self, context):
        set_tab(context, self.key)
        _redraw(context)
        return {'FINISHED'}

class ALLSET_OT_ae_step(bpy.types.Operator):
    """Go to the next input (left) or output (right) node in the history (Maya in/out arrows)"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:876'
    bl_idname = 'allset.ae_step'
    bl_label = _zh_native('Input / Output Node', 'MWK:ui/attribute_editor.py:876')
    bl_description = _zh_native('Go to the next input (left) or output (right) node in the history (Maya in/out arrows)', 'MWK:ui/attribute_editor.py:876')
    bl_options = {'INTERNAL'}
    forward: bpy.props.BoolProperty(translation_context='MWK:ui/attribute_editor.py:879')

    def execute(self, context):
        ob = ae_node(context)
        if ob is None:
            return {'CANCELLED'}
        keys = [t[0] for t in tabs(ob) if _kind(t[0]) in ('H', 'M', 'CH')]
        cur = current_tab(context, ob)
        if cur not in keys:
            return {'CANCELLED'}
        i = keys.index(cur) + (1 if self.forward else -1)
        if 0 <= i < len(keys):
            set_tab(context, keys[i])
        _redraw(context)
        return {'FINISHED'}

class ALLSET_OT_ae_modifier(bpy.types.Operator):
    """Delete History: apply this modifier (keep its effect, drop the node); Delete: remove it"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:899'
    bl_idname = 'allset.ae_modifier'
    bl_label = _zh_native('History Node', 'MWK:ui/attribute_editor.py:899')
    bl_description = _zh_native('Delete History: apply this modifier (keep its effect, drop the node); Delete: remove it', 'MWK:ui/attribute_editor.py:899')
    bl_options = {'REGISTER', 'UNDO'}
    modifier: StringProperty(translation_context='MWK:ui/attribute_editor.py:902')
    action: EnumProperty(items=_zh_enum((('APPLY', 'Apply', ''), ('REMOVE', 'Remove', '')), 'MWK:ui/attribute_editor.py:903'), translation_context='MWK:ui/attribute_editor.py:903')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object is not None

    def execute(self, context):
        ob = context.active_object
        md = ob.modifiers.get(self.modifier)
        if md is None:
            return {'CANCELLED'}
        if self.action == 'REMOVE':
            ob.modifiers.remove(md)
            return {'FINISHED'}
        with context.temp_override(object=ob, active_object=ob):
            return bpy.ops.object.modifier_apply(modifier=self.modifier)

class ALLSET_OT_ae_add_limit(bpy.types.Operator):
    """Add a limit constraint (Maya Limit Information)"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:924'
    bl_idname = 'allset.ae_add_limit'
    bl_label = _zh_native('Add Limit', 'MWK:ui/attribute_editor.py:924')
    bl_description = _zh_native('Add a limit constraint (Maya Limit Information)', 'MWK:ui/attribute_editor.py:924')
    bl_options = {'REGISTER', 'UNDO'}
    type: EnumProperty(items=_zh_enum([(k, k.replace('_', ' ').title(), '') for k in LIMIT_PROPS], 'MWK:ui/attribute_editor.py:927'), translation_context='MWK:ui/attribute_editor.py:927')

    @classmethod
    def poll(cls, context):
        return channel_box.lead(context) is not None

    def execute(self, context):
        con = channel_box.lead(context).constraints.new(self.type)
        con.owner_space = 'LOCAL'
        return {'FINISHED'}

class ALLSET_OT_ae_select(bpy.types.Operator):
    """Select only the node shown in the Attribute Editor"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:942'
    bl_idname = 'allset.ae_select'
    bl_label = _zh_native('Select', 'MWK:ui/attribute_editor.py:942')
    bl_description = _zh_native('Select only the node shown in the Attribute Editor', 'MWK:ui/attribute_editor.py:942')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and ae_node(context) is not None

    def execute(self, context):
        ob = ae_node(context)
        if channel_box.is_bone(ob):
            return {'CANCELLED'}
        for o in context.selected_objects:
            o.select_set(False)
        try:
            ob.select_set(True)
        except RuntimeError:
            return {'CANCELLED'}
        context.view_layer.objects.active = ob
        return {'FINISHED'}

def show_dock(context, dock):
    """Raise ``dock`` in the Maya tab stack, or open it as a floating window (ui/maya_dock.py, step 116)."""
    from . import maya_dock
    return maya_dock.show(context, dock)

class ALLSET_OT_ae_toggle(bpy.types.Operator):
    """Switch the dock between Channel Box / Layer Editor and Attribute Editor
    (Maya Ctrl+A)"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:973'
    bl_idname = 'allset.ae_toggle'
    bl_label = _zh_native('Attribute Editor / Channel Box', 'MWK:ui/attribute_editor.py:973')
    bl_description = _zh_native('Switch the dock between Channel Box / Layer Editor and Attribute Editor\n(Maya Ctrl+A)', 'MWK:ui/attribute_editor.py:973')

    def execute(self, context):
        wm = context.window_manager
        show_dock(context, 'CHANNEL_BOX' if wm.allset_dock == 'ATTRIBUTE_EDITOR' else 'ATTRIBUTE_EDITOR')
        return {'FINISHED'}

class ALLSET_OT_dock_show(bpy.types.Operator):
    """Show the Attribute Editor, the Channel Box / Layer Editor or the Modeling Toolkit: the tab stack's tab, or a
    floating window when the layout has no tab stack (Maya Windows > General Editors)"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:985'
    bl_idname = 'allset.dock_show'
    bl_label = _zh_native('Show Dock Editor', 'MWK:ui/attribute_editor.py:985')
    bl_description = _zh_native("Show the Attribute Editor, the Channel Box / Layer Editor or the Modeling Toolkit: the tab stack's tab, or a\nfloating window when the layout has no tab stack (Maya Windows > General Editors)", 'MWK:ui/attribute_editor.py:985')
    dock: EnumProperty(items=_zh_enum(DOCK_ITEMS, 'MWK:ui/attribute_editor.py:987'), name=_zh_native('Editor', 'MWK:ui/attribute_editor.py:987'), translation_context='MWK:ui/attribute_editor.py:987')
    le_tab: bpy.props.StringProperty(name=_zh_native('Layer Editor Tab', 'MWK:ui/attribute_editor.py:988'), options={'SKIP_SAVE', 'HIDDEN'}, description=_zh_native('DISPLAY / ANIM: the Layer Editor tab to raise (step 188)', 'MWK:ui/attribute_editor.py:988'), translation_context='MWK:ui/attribute_editor.py:988')

    def execute(self, context):
        show_dock(context, self.dock)
        if self.le_tab in ('DISPLAY', 'ANIM'):
            context.window_manager.allset_le_tab = self.le_tab
        return {'FINISHED'}

class ALLSET_OT_object_attributes(bpy.types.Operator):
    """Show this object in the Attribute Editor (Maya RMB marking menu row
    "<object>...")"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:1002'
    bl_idname = 'allset.object_attributes'
    bl_label = _zh_native('Object Attributes', 'MWK:ui/attribute_editor.py:1002')
    bl_description = _zh_native('Show this object in the Attribute Editor (Maya RMB marking menu row\n"<object>...")', 'MWK:ui/attribute_editor.py:1002')
    rmb: bpy.props.BoolProperty(options={'HIDDEN', 'SKIP_SAVE'}, description=_zh_native('The object the RMB menu was opened on', 'MWK:ui/attribute_editor.py:1004'), translation_context='MWK:ui/attribute_editor.py:1004')

    @staticmethod
    def _object(context, rmb):
        if rmb:
            ob = bpy.data.objects.get(getattr(context.window_manager, 'allset_mm_target', ''))
            if ob is not None:
                return ob
        return context.active_object

    @classmethod
    def poll(cls, context):
        return cls._object(context, True) is not None

    def execute(self, context):
        ob = self._object(context, self.rmb)
        if ob is None:
            return {'CANCELLED'}
        if context.active_object is not ob:
            try:
                ob.select_get(view_layer=context.view_layer)
                context.view_layer.objects.active = ob
            except RuntimeError:
                return {'CANCELLED'}
        return bpy.ops.allset.dock_show(dock='ATTRIBUTE_EDITOR')

def _redraw(context):
    """The dock areas (Properties editors, any window, step 116) and the 3D Views."""
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type in {'VIEW_3D', 'PROPERTIES'}:
                area.tag_redraw()

def _dock_update(self, context):
    from . import maya_dock
    maya_dock.redraw()

def draw_panel(layout, context):
    """The Attribute Editor body of the dock (``channel_box.ALLSET_PT_dock_attribute_editor``)."""
    if channel_box.placing_joints(context):
        from . import chrome
        chrome.wrapped(layout, channel_box.PLACING_TEXT)
        return
    from . import chrome
    for idx in wrap_rows(context, [label for (label, _m) in MENU_BAR], equal=False):
        chrome.menu_bar(layout, [MENU_BAR[i] for i in idx])
    ob = ae_node(context)
    if ob is None:
        layout.label(text=_zh('make a selection', 'MWK:ui/attribute_editor.py:1065'))
        return
    _remember(ob)
    draw(layout, context, ob)
ATTRIBUTE_NAMES = (('NICE', _dcc_source('Nice'), _dcc_source('Readable names (Translate X)')), ('LONG', _dcc_source('Long'), _dcc_source('Property names (location)')), ('SHORT', _dcc_source('Short'), _dcc_source('Abbreviated property names')))
AE = _dcc_source('Attribute Editor')
AE_NOTICES = {f'{AE}/Presets': (_dcc_source('Blender presets per tool'), _dcc_source("Attribute presets of a node aren't kept by Blender")), f'{AE}/List/Selected Items': (_dcc_source('Selected menu'), _dcc_source('The Selected menu lists the selection')), f'{AE}/List/Dynamics': (_dcc_source('Outliner'), _dcc_source('Node lists by type: use the Outliner filter (Maya greys these too while Auto Load is on)')), f'{AE}/Show/Filters': (_dcc_source('Hide button'), _dcc_source('Hide a node type with the Hide button, bring them back with Show')), f'{AE}/Show/Views': (_dcc_source('one view'), _dcc_source('Blender has no alternative AE layouts (views / templates)')), f'{AE}/Help': (_dcc_source('Blender manual'), _dcc_source("Help > Manual in Blender's menus; hover a field for its tooltip"))}
_recent = []
RECENT = 8

def fits(context, entries):
    """True when a flat menu bar of ``entries`` fits the region (about 7 px a character + 14 px a menu at UI
    scale 1; region width unknown -> True)."""
    region = getattr(context, 'region', None)
    if region is None or region.width <= 1:
        return True
    scale = context.preferences.system.ui_scale or 1.0
    need = sum((len(label) * 7 + 14 for (label, _m) in entries)) * scale
    from . import maya_dock
    return need <= region.width - 20 * scale - maya_dock.area_reserved_px(context)

def ae_node(context):
    """The object (or pose bone) the AE shows: the lead, or the focused node while Auto Load is off."""
    wm = context.window_manager
    if not getattr(wm, 'allset_ae_auto_load', True):
        ob = bpy.data.objects.get(getattr(wm, 'allset_ae_node', ''))
        if ob is not None:
            return ob
    return channel_box.lead(context)

def _remember(ob):
    name = getattr(ob, 'name', None)
    if not name or (_recent and _recent[0] == name):
        return
    if name in _recent:
        _recent.remove(name)
    _recent.insert(0, name)
    del _recent[RECENT:]

def _greyed(layout, path, text):
    layout.operator('allset.menu_unavailable', text=_zh(text, 'MWK:ui/attribute_editor.py:1124')).item = f'{AE}/{path}'

class ALLSET_MT_ae_list(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1128'
    bl_label = _zh_native('List', 'MWK:ui/attribute_editor.py:1128')

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        layout.prop(wm, 'allset_ae_auto_load')
        row = layout.row()
        row.enabled = not wm.allset_ae_auto_load
        row.operator('allset.ae_load', text=_zh('Load Selected Attributes', 'MWK:ui/attribute_editor.py:1136'))
        _greyed(layout, 'List/Selected Items', _dcc_source('Selected Items'))
        layout.separator()
        for name in (_dcc_source('Dynamics'), _dcc_source('Kinematics'), _dcc_source('Deformers'), _dcc_source('Lights'), _dcc_source('Shading')):
            _greyed(layout, 'List/Dynamics', name)

class ALLSET_MT_ae_selected(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1144'
    bl_label = _zh_native('Selected', 'MWK:ui/attribute_editor.py:1144')

    def draw(self, context):
        obs = list(getattr(context, 'selected_objects', ()) or ())
        if not obs:
            self.layout.label(text=_zh('Nothing selected', 'MWK:ui/attribute_editor.py:1149'))
        for ob in obs:
            self.layout.operator('allset.ae_show_node', text=_dcc_display(ob.name)).name = ob.name

class ALLSET_MT_ae_focus(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1155'
    bl_label = _zh_native('Focus', 'MWK:ui/attribute_editor.py:1155')

    def draw(self, context):
        names = [n for n in _recent if n in bpy.data.objects]
        if not names:
            self.layout.label(text=_zh('No nodes yet', 'MWK:ui/attribute_editor.py:1160'))
        for name in names:
            self.layout.operator('allset.ae_show_node', text=str('|' + name), translate=False).name = name

class ALLSET_MT_ae_attributes(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1166'
    bl_label = _zh_native('Attributes', 'MWK:ui/attribute_editor.py:1166')

    def draw(self, context):
        layout = self.layout
        layout.operator('allset.add_attribute', text=_zh('Add Attributes...', 'MWK:ui/attribute_editor.py:1170'))
        layout.operator('allset.delete_attribute', text=_zh('Delete Attributes...', 'MWK:ui/attribute_editor.py:1171'))
        layout.operator('allset.edit_attribute', text=_zh('Edit Attributes...', 'MWK:ui/attribute_editor.py:1172'))

class ALLSET_MT_ae_attribute_names(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1176'
    bl_label = _zh_native('Attribute Names', 'MWK:ui/attribute_editor.py:1176')

    def draw(self, context):
        self.layout.props_enum(context.window_manager, 'allset_ae_names')

class ALLSET_MT_ae_display(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1183'
    bl_label = _zh_native('Display', 'MWK:ui/attribute_editor.py:1183')

    def draw(self, context):
        self.layout.menu(ALLSET_MT_ae_attribute_names.__name__)

class ALLSET_MT_ae_node_types(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1190'
    bl_label = _zh_native('By Node Type', 'MWK:ui/attribute_editor.py:1190')

    def draw(self, context):
        layout = self.layout
        layout.operator('allset.ae_show_types', text=_zh('Enable All', 'MWK:ui/attribute_editor.py:1194'))
        hidden = sorted(hidden_types(context))
        if hidden:
            layout.separator()
        for t in hidden:
            op = layout.operator('allset.ae_show_types', text=_zh(t, 'MWK:ui/attribute_editor.py:1199'), icon='CHECKBOX_DEHLT')
            op.node_type = t

class ALLSET_MT_ae_show(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1204'
    bl_label = _zh_native('Show', 'MWK:ui/attribute_editor.py:1204')

    def draw(self, context):
        layout = self.layout
        layout.menu(ALLSET_MT_ae_node_types.__name__)
        layout.separator()
        for text in (_dcc_source('Add New Filter Type...'), _dcc_source('Add Filter Types for Selected'), _dcc_source('Save Show Preset')):
            _greyed(layout, 'Show/Filters', text)
        layout.separator()
        for text in (_dcc_source('Set Current View'), _dcc_source('Set Global View')):
            _greyed(layout, 'Show/Views', text)
        layout.prop(context.window_manager, 'allset_ae_show_notes')

class ALLSET_MT_ae_help(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1219'
    bl_label = _zh_native('Help', 'MWK:ui/attribute_editor.py:1219')

    def draw(self, context):
        layout = self.layout
        _greyed(layout, _dcc_source('Help'), _dcc_source('Help on Attribute Editor'))
        ob = ae_node(context)
        if ob is not None:
            layout.separator()
            for t in sorted({t[2] for t in tabs(ob)}):
                _greyed(layout, _dcc_source('Help'), f'Help on "{t}"')
        layout.separator()
        _greyed(layout, _dcc_source('Help'), _dcc_source('Node and Attribute Reference'))

class ALLSET_MT_ae_presets(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/attribute_editor.py:1234'
    bl_label = _zh_native('Presets', 'MWK:ui/attribute_editor.py:1234')

    def draw(self, context):
        for text in (_dcc_source('Save attribute preset...'), _dcc_source('Edit Presets...')):
            _greyed(self.layout, _dcc_source('Presets'), text)
MENU_BAR = ((_dcc_source('List'), 'ALLSET_MT_ae_list'), (_dcc_source('Selected'), 'ALLSET_MT_ae_selected'), (_dcc_source('Focus'), 'ALLSET_MT_ae_focus'), (_dcc_source('Attributes'), 'ALLSET_MT_ae_attributes'), (_dcc_source('Display'), 'ALLSET_MT_ae_display'), (_dcc_source('Show'), 'ALLSET_MT_ae_show'), (_dcc_source('Help'), 'ALLSET_MT_ae_help'))
MENUS = (ALLSET_MT_ae_list, ALLSET_MT_ae_selected, ALLSET_MT_ae_focus, ALLSET_MT_ae_attributes, ALLSET_MT_ae_attribute_names, ALLSET_MT_ae_display, ALLSET_MT_ae_node_types, ALLSET_MT_ae_show, ALLSET_MT_ae_help, ALLSET_MT_ae_presets)

class ALLSET_OT_ae_focus(bpy.types.Operator):
    """Set Attribute Editor focus to this node (it stays on this node and tab; List > Auto Load Selected
    Attributes follows the selection again)"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:1253'
    bl_idname = 'allset.ae_focus'
    bl_label = _zh_native('Focus', 'MWK:ui/attribute_editor.py:1253')
    bl_description = _zh_native('Set Attribute Editor focus to this node (it stays on this node and tab; List > Auto Load Selected\nAttributes follows the selection again)', 'MWK:ui/attribute_editor.py:1253')
    bl_options = {'INTERNAL'}

    def execute(self, context):
        ob = ae_node(context)
        if ob is None or channel_box.is_bone(ob):
            return {'CANCELLED'}
        wm = context.window_manager
        set_tab(context, current_tab(context, ob))
        wm.allset_ae_node = ob.name
        wm.allset_ae_auto_load = False
        _remember(ob)
        _redraw(context)
        return {'FINISHED'}

class ALLSET_OT_ae_show_types(bpy.types.Operator):
    """Show all the related nodes in the attribute editor"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:1272'
    bl_idname = 'allset.ae_show_types'
    bl_label = _zh_native('Show', 'MWK:ui/attribute_editor.py:1272')
    bl_description = _zh_native('Show all the related nodes in the attribute editor', 'MWK:ui/attribute_editor.py:1272')
    bl_options = {'INTERNAL'}
    node_type: StringProperty(options={'SKIP_SAVE'}, description=_zh_native('Only this node type (empty: all)', 'MWK:ui/attribute_editor.py:1275'), translation_context='MWK:ui/attribute_editor.py:1275')

    def execute(self, context):
        wm = context.window_manager
        wm.allset_ae_hidden = ','.join(sorted(hidden_types(context) - {self.node_type})) if self.node_type else ''
        _redraw(context)
        return {'FINISHED'}

class ALLSET_OT_ae_hide_type(bpy.types.Operator):
    """Hide nodes of this type in the attribute editor"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:1287'
    bl_idname = 'allset.ae_hide_type'
    bl_label = _zh_native('Hide', 'MWK:ui/attribute_editor.py:1287')
    bl_description = _zh_native('Hide nodes of this type in the attribute editor', 'MWK:ui/attribute_editor.py:1287')
    bl_options = {'INTERNAL'}

    def execute(self, context):
        ob = ae_node(context)
        if ob is None:
            return {'CANCELLED'}
        key = current_tab(context, ob)
        if _kind(key) in ('T', 'S', 'J'):
            results.result(self, _zh('The transform and shape tabs stay', 'MWK:ui/attribute_editor.py:1296'))
            return {'CANCELLED'}
        mtype = next((t[2] for t in tabs(ob) if t[0] == key), None)
        wm = context.window_manager
        wm.allset_ae_hidden = ','.join(sorted(hidden_types(context) | {mtype}))
        set_tab(context, 'S' if ob.data is not None else 'T')
        _redraw(context)
        return {'FINISHED'}

class ALLSET_OT_ae_load(bpy.types.Operator):
    """Load current selection into the Attribute Editor"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:1309'
    bl_idname = 'allset.ae_load'
    bl_label = _zh_native('Load Attributes', 'MWK:ui/attribute_editor.py:1309')
    bl_description = _zh_native('Load current selection into the Attribute Editor', 'MWK:ui/attribute_editor.py:1309')
    bl_options = {'INTERNAL'}

    def execute(self, context):
        lead = channel_box.lead(context)
        wm = context.window_manager
        wm.allset_ae_node = getattr(lead, 'name', '') if lead is not None and (not channel_box.is_bone(lead)) else ''
        if lead is not None:
            _remember(lead)
        _redraw(context)
        return {'FINISHED'}

class ALLSET_OT_ae_show_node(bpy.types.Operator):
    """Show this node in the Attribute Editor"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:1325'
    bl_idname = 'allset.ae_show_node'
    bl_label = _zh_native('Show Node', 'MWK:ui/attribute_editor.py:1325')
    bl_description = _zh_native('Show this node in the Attribute Editor', 'MWK:ui/attribute_editor.py:1325')
    bl_options = {'INTERNAL'}
    name: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/attribute_editor.py:1328')

    def execute(self, context):
        ob = bpy.data.objects.get(self.name)
        if ob is None:
            return {'CANCELLED'}
        wm = context.window_manager
        if wm.allset_ae_auto_load:
            try:
                ob.select_get(view_layer=context.view_layer)
                context.view_layer.objects.active = ob
            except RuntimeError:
                return {'CANCELLED'}
        else:
            wm.allset_ae_node = ob.name
        _remember(ob)
        _redraw(context)
        return {'FINISHED'}
COPY_TABS = {'T': 'OBJECT', 'S': 'DATA', 'M': 'MODIFIER', 'H': 'DATA', 'CH': 'DATA', 'C': 'CONSTRAINT', 'MAT': 'MATERIAL', 'SG': 'MATERIAL', 'J': 'BONE', 'NUC': 'PHYSICS'}

def copy_tab_target(ob, key):
    """(Properties tab, ID to pin) for Copy Tab."""
    kind = _kind(key)
    tab = COPY_TABS.get(kind, 'OBJECT')
    if channel_box.is_bone(ob):
        return (tab, ob.id_data)
    if kind == 'S' and ob.data is not None:
        return (tab, ob.data)
    if kind in ('MAT', 'SG'):
        return (tab, ob)
    return (tab, ob)

class ALLSET_OT_ae_copy_tab(bpy.types.Operator):
    """Copy the contents of the current tab into a new floating window (a Properties editor pinned to it)"""
    bl_translation_context = 'MWK:ui/attribute_editor.py:1369'
    bl_idname = 'allset.ae_copy_tab'
    bl_label = _zh_native('Copy Tab', 'MWK:ui/attribute_editor.py:1369')
    bl_description = _zh_native('Copy the contents of the current tab into a new floating window (a Properties editor pinned to it)', 'MWK:ui/attribute_editor.py:1369')
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return ae_node(context) is not None and context.window is not None

    def execute(self, context):
        from ..operators.menu_extras import open_window
        ob = ae_node(context)
        (tab, pin) = copy_tab_target(ob, current_tab(context, ob))
        area = max(context.window.screen.areas, key=lambda a: a.width * a.height, default=None)
        new = open_window(context, area) if area is not None else None
        if new is None:
            self.report({'ERROR'}, _zh('Could not open a new window', 'MWK:ui/attribute_editor.py:1383'))
            return {'CANCELLED'}
        target = new.screen.areas[0]
        target.ui_type = 'PROPERTIES'
        state = {'n': 40}
        (win_ptr, area_ptr) = (new.as_pointer(), target.as_pointer())

        def tick():
            target = live_refs.area(area_ptr, win_ptr)
            if target is None:
                return None
            try:
                space = target.spaces.active
                space.pin_id = pin
                space.use_pin_id = True
                space.context = tab
            except (TypeError, ReferenceError, AttributeError):
                state['n'] -= 1
                return 0.05 if state['n'] > 0 else None
            target.tag_redraw()
            return None
        bpy.app.timers.register(tick, first_interval=0.0)
        return {'FINISHED'}
classes = (ALLSET_OT_ae_tab, ALLSET_OT_ae_step, ALLSET_OT_ae_modifier, ALLSET_OT_ae_add_limit, ALLSET_OT_ae_select, ALLSET_OT_ae_toggle, ALLSET_OT_dock_show, ALLSET_OT_object_attributes, ALLSET_OT_ae_focus, ALLSET_OT_ae_show_types, ALLSET_OT_ae_hide_type, ALLSET_OT_ae_load, ALLSET_OT_ae_copy_tab, ALLSET_OT_ae_show_node) + MENUS

def register():
    wm = bpy.types.WindowManager
    wm.allset_dock = EnumProperty(name=_zh_native('Dock', 'MWK:ui/attribute_editor.py:1416'), items=_zh_enum(DOCK_ITEMS, 'MWK:ui/attribute_editor.py:1416'), options={'SKIP_SAVE'}, update=_dock_update, translation_context='MWK:ui/attribute_editor.py:1416')
    wm.allset_ae_tab = StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/attribute_editor.py:1417')
    wm.allset_ae_kind = StringProperty(default='S', options={'SKIP_SAVE'}, translation_context='MWK:ui/attribute_editor.py:1418')
    wm.allset_ae_auto_load = bpy.props.BoolProperty(name=_zh_native('Auto Load Selected Attributes', 'MWK:ui/attribute_editor.py:1419'), default=True, options={'SKIP_SAVE'}, description=_zh_native('The Attribute Editor follows the selection (off: it keeps showing its node)', 'MWK:ui/attribute_editor.py:1419'), translation_context='MWK:ui/attribute_editor.py:1419')
    wm.allset_ae_node = StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/attribute_editor.py:1422')
    wm.allset_ae_hidden = StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/attribute_editor.py:1423')
    wm.allset_ae_show_notes = bpy.props.BoolProperty(name=_zh_native('Show Notes', 'MWK:ui/attribute_editor.py:1424'), default=True, options={'SKIP_SAVE'}, translation_context='MWK:ui/attribute_editor.py:1424')
    wm.allset_ae_names = EnumProperty(name=_zh_native('Attribute Names', 'MWK:ui/attribute_editor.py:1425'), items=_zh_enum(ATTRIBUTE_NAMES, 'MWK:ui/attribute_editor.py:1425'), default='NICE', options={'SKIP_SAVE'}, translation_context='MWK:ui/attribute_editor.py:1425')
    bpy.types.Scene.allset_ae_notes = StringProperty(name=_zh_native('Notes', 'MWK:ui/attribute_editor.py:1427'), get=_notes_get, set=_notes_set, options={'SKIP_SAVE'}, description=_zh_native("Notes of the node shown (Maya's notes attribute; kept in the file)", 'MWK:ui/attribute_editor.py:1427'), translation_context='MWK:ui/attribute_editor.py:1427')
    from . import notices
    notices.PANEL_NOTICES.update(AE_NOTICES)
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    from . import notices
    for k in AE_NOTICES:
        notices.PANEL_NOTICES.pop(k, None)
    _recent.clear()
    del bpy.types.Scene.allset_ae_notes
    wm = bpy.types.WindowManager
    for name in ('allset_ae_names', 'allset_ae_show_notes', 'allset_ae_hidden', 'allset_ae_node', 'allset_ae_auto_load'):
        delattr(wm, name)
    del wm.allset_ae_kind
    del wm.allset_ae_tab
    del wm.allset_dock
