# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya's Connection Editor window (step 213, Issue #119).

Maya 2022: Reload Left / Reload Right, the mode buttons
Outputs / from -> to / Inputs, two attribute lists (the node, then its attributes; compounds such as translate open
to translateX / Y / Z), the node names under the lists with < > to swap them, and Clear All / Remove / Break / Make /
Close. With Auto-connect on (factory) a click on a left attribute then on a right one connects them: the right one
follows the left (``connectAttr``); a click on a connected right attribute breaks it, the value stays.

Blender has no dependency graph connections between properties: a connection is a driver on the right property with
one variable ``cn`` reading the left property (the step 62 SDK uses ``sdk`` the same way). Maya copies the number
across attribute types through unit conversion (translateX 3 cm -> rotateX 3 degrees), so the driver expression scales
by the same Maya-number factors (lengths / ``maya_unit()``, angles in degrees). Only attributes with a Blender
counterpart are listed (transform channels, visibility, custom attributes): Maya's caching / nodeState / ... have none
(delegated).
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import math
import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from . import marked_window
KIND = 'CONNECTION_EDITOR'
EDITOR = _dcc_source('Connection Editor')
VAR = 'cn'
SIDES = (('LEFT', _dcc_source('Left'), ''), ('RIGHT', _dcc_source('Right'), ''))
MODES = (('OUTPUTS', _dcc_source('Outputs'), _dcc_source('Both lists show outputs: connect left to right')), ('FROM_TO', 'from -> to', _dcc_source('Connect a left output to a right input')), (_dcc_source('INPUTS'), _dcc_source('Inputs'), _dcc_source('Both lists show inputs: connect right to left')))
SIMPLE = {}
COMPOUNDS = {}
for (_maya, _path, _kind) in (('translate', 'location', 'LOC'), ('rotate', 'rotation_euler', 'ROT'), ('scale', 'scale', 'SCALE')):
    COMPOUNDS[_maya] = [f'{_maya}{axis}' for axis in 'XYZ']
    for (_i, _axis) in enumerate('XYZ'):
        SIMPLE[f'{_maya}{_axis}'] = (_path, _i, _kind)
SIMPLE['visibility'] = ('hide_viewport', -1, 'VIS')
ORDER = ('visibility', 'translate', 'rotate', 'scale')

def custom_attrs(ob):
    """Custom (user) attributes: numeric ID properties that aren't the kit's bookkeeping."""
    out = []
    for key in ob.keys():
        if key.startswith(('_', 'allset', 'cycles')):
            continue
        if isinstance(ob[key], (int, float)) and (not isinstance(ob[key], bool)):
            out.append(key)
    return out

def attributes(ob):
    """[(name, depth, is_compound)] in Maya's list order: visibility, translate ▸ X Y Z, rotate ▸, scale ▸, custom."""
    rows = []
    for name in ORDER:
        if name in COMPOUNDS:
            rows.append((name, 0, True))
            rows.extend(((child, 1, False) for child in COMPOUNDS[name]))
        else:
            rows.append((name, 0, False))
    rows.extend(((key, 0, False) for key in custom_attrs(ob)))
    return rows

def resolve(ob, attr):
    """(data path, index, kind) of a simple attribute of ``ob`` (custom ones are ``["key"]``)."""
    if attr in SIMPLE:
        return SIMPLE[attr]
    if ob is not None and attr in ob.keys():
        return (f'["{attr}"]', -1, 'CUSTOM')
    return None

def leaves(attr):
    return COMPOUNDS.get(attr, [attr])

def maya_factor(kind, unit):
    """Blender value x factor = the Maya number (lengths in Maya units, angles in degrees)."""
    if kind == 'LOC':
        return 1.0 / unit
    if kind == 'ROT':
        return 180.0 / math.pi
    return 1.0

def expression(src_kind, dst_kind, unit):
    """The driver expression: Maya's unit conversion between the two attribute kinds."""
    k = maya_factor(src_kind, unit) / maya_factor(dst_kind, unit)
    return VAR if abs(k - 1.0) < 1e-12 else f'{VAR} * {k!r}'

def _unit(scene):
    from ..operators import units
    return units.maya_unit(scene)

def _fcurve(ob, path, index):
    ad = ob.animation_data
    if ad is None:
        return None
    for fc in ad.drivers:
        if fc.data_path == path and (index < 0 or fc.array_index == index):
            return fc
    return None

def source_of(ob, attr):
    """(source object, source attribute) feeding ``ob.attr`` through a kit connection, else None."""
    res = resolve(ob, attr)
    if res is None:
        return None
    fc = _fcurve(ob, res[0], res[1])
    if fc is None:
        return None
    var = next((v for v in fc.driver.variables if v.name == VAR), None)
    if var is None or not var.targets or var.targets[0].id is None:
        return None
    (src, path) = (var.targets[0].id, var.targets[0].data_path)
    for (name, (p, i, _k)) in SIMPLE.items():
        if path == (f'{p}[{i}]' if i >= 0 else p):
            return (src, name)
    if path.startswith('["') and path.endswith('"]'):
        return (src, path[2:-2])
    return None

def connected(src, src_attr, dst, dst_attr):
    """True when every leaf of ``dst_attr`` is fed by the matching leaf of ``src.src_attr``."""
    pairs = list(zip(leaves(src_attr), leaves(dst_attr)))
    return bool(pairs) and all((source_of(dst, d) == (src, s) for (s, d) in pairs))

def connect(scene, src, src_attr, dst, dst_attr):
    """Maya connectAttr src.attr -> dst.attr (compounds connect child by child). Returns the connected leaf count;
    raises ValueError when the attributes don't match (Maya: compound to simple / different sizes)."""
    (sl, dl) = (leaves(src_attr), leaves(dst_attr))
    if len(sl) != len(dl):
        raise ValueError(f'The attributes {src.name}.{src_attr} and {dst.name}.{dst_attr} are not compatible')
    if src == dst and src_attr == dst_attr:
        raise ValueError(_dcc_source('Cannot connect an attribute to itself'))
    unit = _unit(scene)
    n = 0
    for (s, d) in zip(sl, dl):
        (sres, dres) = (resolve(src, s), resolve(dst, d))
        if sres is None or dres is None:
            raise ValueError(f'No such attribute: {(s if sres is None else d)}')
        (path, index, kind) = dres
        old = _fcurve(dst, path, index)
        if old is not None:
            dst.driver_remove(path, index) if index >= 0 else dst.driver_remove(path)
        fc = dst.driver_add(path, index) if index >= 0 else dst.driver_add(path)
        drv = fc.driver
        drv.type = 'SCRIPTED'
        var = drv.variables.new()
        var.name = VAR
        var.type = 'SINGLE_PROP'
        var.targets[0].id_type = 'OBJECT'
        var.targets[0].id = src
        var.targets[0].data_path = f'{sres[0]}[{sres[1]}]' if sres[1] >= 0 else sres[0]
        drv.expression = expression(sres[2], kind, unit)
        n += 1
    src.update_tag()
    dst.update_tag()
    return n

def disconnect(dst, dst_attr):
    """Maya disconnectAttr: the driver goes, the attribute keeps its last value (CN3). Returns the leaf count."""
    n = 0
    for d in leaves(dst_attr):
        res = resolve(dst, d)
        if res is None or source_of(dst, d) is None:
            continue
        (path, index, _kind) = res
        value = getattr(dst, path) if not path.startswith('[') else dst[path[2:-2]]
        keep = value[index] if index >= 0 else value
        if index >= 0:
            dst.driver_remove(path, index)
            getattr(dst, path)[index] = keep
        elif path.startswith('['):
            dst.driver_remove(path)
            dst[path[2:-2]] = keep
        else:
            dst.driver_remove(path)
            setattr(dst, path, keep)
        n += 1
    return n

def _wm(context):
    return context.window_manager

def node(context, side):
    name = getattr(_wm(context), f'allset_cn_{side.lower()}')
    return bpy.data.objects.get(name) if name else None

def _open_key(side, attr):
    return f'{side}:{attr}'

def is_open(context, side, attr):
    return _open_key(side, attr) in _wm(context).allset_cn_open.split(',')

def direction(context):
    """(source side, target side) for the current mode (Inputs connects right to left; delegated)."""
    return ('RIGHT', 'LEFT') if _wm(context).allset_cn_mode == _dcc_source('INPUTS') else ('LEFT', 'RIGHT')

def _redraw(context):
    marked_window.redraw(context, KIND)

class ALLSET_OT_connection_editor(bpy.types.Operator):
    """Open the Connection Editor: connect an attribute of the left node to one of the right node (Maya Windows >
    General Editors > Connection Editor; Blender: a driver)"""
    bl_translation_context = 'MWK:ui/connection_editor.py:234'
    bl_idname = 'allset.connection_editor'
    bl_label = _zh_native('Connection Editor', 'MWK:ui/connection_editor.py:234')
    bl_description = _zh_native('Open the Connection Editor: connect an attribute of the left node to one of the right node (Maya Windows >\nGeneral Editors > Connection Editor; Blender: a driver)', 'MWK:ui/connection_editor.py:234')

    def execute(self, context):
        if context.window is None:
            return {'CANCELLED'}
        wm = _wm(context)
        sel = [o for o in context.selected_objects]
        if sel and (not wm.allset_cn_left):
            wm.allset_cn_left = sel[0].name
        if len(sel) > 1 and (not wm.allset_cn_right):
            wm.allset_cn_right = sel[-1].name
        if marked_window.open_window(context, KIND) is None:
            self.report({'ERROR'}, _zh('Could not open the Connection Editor window', 'MWK:ui/connection_editor.py:247'))
            return {'CANCELLED'}
        return {'FINISHED'}

class ALLSET_OT_cn_reload(bpy.types.Operator):
    """Load the selected object into this side (Maya Reload Left / Reload Right)"""
    bl_translation_context = 'MWK:ui/connection_editor.py:255'
    bl_idname = 'allset.cn_reload'
    bl_label = _zh_native('Reload', 'MWK:ui/connection_editor.py:255')
    bl_description = _zh_native('Load the selected object into this side (Maya Reload Left / Reload Right)', 'MWK:ui/connection_editor.py:255')
    bl_options = {'INTERNAL'}
    side: EnumProperty(items=_zh_enum(SIDES, 'MWK:ui/connection_editor.py:258'), options={'SKIP_SAVE'}, translation_context='MWK:ui/connection_editor.py:258')

    def execute(self, context):
        ob = context.active_object or next(iter(context.selected_objects), None)
        if ob is None:
            self.report({'WARNING'}, _zh('Select an object to load', 'MWK:ui/connection_editor.py:263'))
            return {'CANCELLED'}
        setattr(_wm(context), f'allset_cn_{self.side.lower()}', ob.name)
        setattr(_wm(context), f'allset_cn_{self.side.lower()}_attr', '')
        _redraw(context)
        return {'FINISHED'}

class ALLSET_OT_cn_pick(bpy.types.Operator):
    """Pick this attribute; with Auto-connect a pick on the other side connects (or, if connected, breaks) the pair"""
    bl_translation_context = 'MWK:ui/connection_editor.py:274'
    bl_idname = 'allset.cn_pick'
    bl_label = _zh_native('Pick Attribute', 'MWK:ui/connection_editor.py:274')
    bl_description = _zh_native('Pick this attribute; with Auto-connect a pick on the other side connects (or, if connected, breaks) the pair', 'MWK:ui/connection_editor.py:274')
    bl_options = {'INTERNAL', 'UNDO'}
    side: EnumProperty(items=_zh_enum(SIDES, 'MWK:ui/connection_editor.py:277'), options={'SKIP_SAVE'}, translation_context='MWK:ui/connection_editor.py:277')
    attr: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/connection_editor.py:278')

    def execute(self, context):
        wm = _wm(context)
        setattr(wm, f'allset_cn_{self.side.lower()}_attr', self.attr)
        (src_side, dst_side) = direction(context)
        if wm.allset_cn_auto and self.side == dst_side:
            src_attr = getattr(wm, f'allset_cn_{src_side.lower()}_attr')
            (src, dst) = (node(context, src_side), node(context, dst_side))
            if src is not None and dst is not None and src_attr:
                try:
                    if connected(src, src_attr, dst, self.attr):
                        disconnect(dst, self.attr)
                    else:
                        connect(context.scene, src, src_attr, dst, self.attr)
                except ValueError as ex:
                    self.report({'WARNING'}, _zh(str(ex), 'MWK:ui/connection_editor.py:294'))
        _redraw(context)
        return {'FINISHED'}

class ALLSET_OT_cn_toggle(bpy.types.Operator):
    """Open / close this compound attribute"""
    bl_translation_context = 'MWK:ui/connection_editor.py:302'
    bl_idname = 'allset.cn_toggle'
    bl_label = _zh_native('Expand', 'MWK:ui/connection_editor.py:302')
    bl_description = _zh_native('Open / close this compound attribute', 'MWK:ui/connection_editor.py:302')
    bl_options = {'INTERNAL'}
    side: EnumProperty(items=_zh_enum(SIDES, 'MWK:ui/connection_editor.py:305'), options={'SKIP_SAVE'}, translation_context='MWK:ui/connection_editor.py:305')
    attr: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/connection_editor.py:306')

    def execute(self, context):
        wm = _wm(context)
        keys = [k for k in wm.allset_cn_open.split(',') if k]
        key = _open_key(self.side, self.attr)
        keys = [k for k in keys if k != key] if key in keys else keys + [key]
        wm.allset_cn_open = ','.join(keys)
        _redraw(context)
        return {'FINISHED'}

class ALLSET_OT_cn_command(bpy.types.Operator):
    """Connection Editor buttons: Make, Break, swap sides, Clear All, Remove"""
    bl_translation_context = 'MWK:ui/connection_editor.py:321'
    bl_idname = 'allset.cn_command'
    bl_label = _zh_native('Connection Editor', 'MWK:ui/connection_editor.py:321')
    bl_description = _zh_native('Connection Editor buttons: Make, Break, swap sides, Clear All, Remove', 'MWK:ui/connection_editor.py:321')
    bl_options = {'INTERNAL', 'UNDO'}
    action: EnumProperty(items=_zh_enum((('MAKE', 'Make', 'Connect the picked attributes'), ('BREAK', 'Break', 'Disconnect the picked right attribute'), ('SWAP', 'Swap', 'Swap the left and right nodes'), ('CLEAR', 'Clear All', 'Empty both lists'), ('REMOVE', 'Remove', 'Empty the right list')), 'MWK:ui/connection_editor.py:324'), options={'SKIP_SAVE'}, translation_context='MWK:ui/connection_editor.py:324')

    def execute(self, context):
        wm = _wm(context)
        (src_side, dst_side) = direction(context)
        (src, dst) = (node(context, src_side), node(context, dst_side))
        src_attr = getattr(wm, f'allset_cn_{src_side.lower()}_attr')
        dst_attr = getattr(wm, f'allset_cn_{dst_side.lower()}_attr')
        if self.action == 'MAKE':
            if src is None or dst is None or (not src_attr) or (not dst_attr):
                self.report({'WARNING'}, _zh('Pick an attribute on each side', 'MWK:ui/connection_editor.py:338'))
                return {'CANCELLED'}
            try:
                connect(context.scene, src, src_attr, dst, dst_attr)
            except ValueError as ex:
                self.report({'WARNING'}, _zh(str(ex), 'MWK:ui/connection_editor.py:343'))
                return {'CANCELLED'}
        elif self.action == 'BREAK':
            if dst is None or not dst_attr or (not disconnect(dst, dst_attr)):
                self.report({'WARNING'}, _zh('No connection to break', 'MWK:ui/connection_editor.py:347'))
                return {'CANCELLED'}
        elif self.action == 'SWAP':
            (wm.allset_cn_left, wm.allset_cn_right) = (wm.allset_cn_right, wm.allset_cn_left)
            (wm.allset_cn_left_attr, wm.allset_cn_right_attr) = (wm.allset_cn_right_attr, wm.allset_cn_left_attr)
        elif self.action == 'CLEAR':
            wm.allset_cn_left = wm.allset_cn_right = wm.allset_cn_left_attr = wm.allset_cn_right_attr = ''
        elif self.action == 'REMOVE':
            wm.allset_cn_right = wm.allset_cn_right_attr = ''
        _redraw(context)
        return {'FINISHED'}

def _nice(name):
    """Maya Channel Names > Nice: translateX -> Translate X."""
    out = name[0].upper()
    for ch in name[1:]:
        out += ' ' + ch if ch.isupper() else ch
    return out

def draw_list(layout, context, side):
    wm = _wm(context)
    ob = node(context, side)
    col = layout.column(align=True)
    if ob is None:
        col.label(text=_zh('(empty)', 'MWK:ui/connection_editor.py:375'))
        return
    col.label(text=_dcc_display(ob.name), icon='OBJECT_DATA')
    picked = getattr(wm, f'allset_cn_{side.lower()}_attr')
    (_src_side, dst_side) = direction(context)
    for (name, depth, compound) in attributes(ob):
        if depth and (not any((is_open(context, side, c) for (c, kids) in COMPOUNDS.items() if name in kids))):
            continue
        row = col.row(align=True)
        if depth:
            row.separator(factor=2.0)
        if compound:
            op = row.operator(ALLSET_OT_cn_toggle.bl_idname, text=_dcc_display(''), emboss=False, icon='DISCLOSURE_TRI_DOWN' if is_open(context, side, name) else 'DISCLOSURE_TRI_RIGHT')
            (op.side, op.attr) = (side, name)
        linked = side == dst_side and all((source_of(ob, leaf) is not None for leaf in leaves(name)))
        label = _nice(name) if wm.allset_cn_names == 'NICE' else name
        cell = row.row(align=True)
        cell.alignment = 'LEFT'
        op = cell.operator(ALLSET_OT_cn_pick.bl_idname, text=_zh(label, 'MWK:ui/connection_editor.py:395'), depress=name == picked, icon='DRIVER' if linked else 'NONE', emboss=name == picked)
        (op.side, op.attr) = (side, name)

class ALLSET_PT_connection_editor(bpy.types.Panel):
    """Maya's Connection Editor (a marked Properties Tool tab in its own window)"""
    bl_translation_context = 'MWK:ui/connection_editor.py:405'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = _dcc_source('Tool')
    bl_label = _zh_native('Connection Editor', 'MWK:ui/connection_editor.py:405')
    bl_options = {'HIDE_HEADER'}
    bl_order = -300

    @classmethod
    def poll(cls, context):
        return marked_window.context_kind(context) == KIND

    def draw(self, context):
        wm = _wm(context)
        layout = self.layout
        marked_window.draw_menu_bar(layout, context, EDITOR)
        row = layout.row(align=True)
        for (side, text) in (('LEFT', _dcc_source('Reload Left')), ('RIGHT', _dcc_source('Reload Right'))):
            row.operator(ALLSET_OT_cn_reload.bl_idname, text=_zh(text, 'MWK:ui/connection_editor.py:419')).side = side
        layout.row(align=True).prop(wm, 'allset_cn_mode', expand=True)
        split = layout.split(factor=0.5)
        draw_list(split.box(), context, 'LEFT')
        draw_list(split.box(), context, 'RIGHT')
        names = layout.row(align=True)
        names.label(text=_zh(wm.allset_cn_left or ' ', 'MWK:ui/connection_editor.py:425'))
        sw = names.row(align=True)
        sw.operator(ALLSET_OT_cn_command.bl_idname, text=_dcc_display(''), icon='TRIA_LEFT').action = 'SWAP'
        sw.operator(ALLSET_OT_cn_command.bl_idname, text=_dcc_display(''), icon='TRIA_RIGHT').action = 'SWAP'
        names.label(text=_zh(wm.allset_cn_right or ' ', 'MWK:ui/connection_editor.py:429'))
        bottom = layout.row(align=True)
        for (action, text) in (('CLEAR', _dcc_source('Clear All')), ('REMOVE', _dcc_source('Remove')), ('BREAK', _dcc_source('Break')), ('MAKE', _dcc_source('Make'))):
            bottom.operator(ALLSET_OT_cn_command.bl_idname, text=_zh(text, 'MWK:ui/connection_editor.py:432')).action = action
        bottom.operator('allset.marked_window_close', text=_zh('Close', 'MWK:ui/connection_editor.py:433'))
classes = (ALLSET_OT_connection_editor, ALLSET_OT_cn_reload, ALLSET_OT_cn_pick, ALLSET_OT_cn_toggle, ALLSET_OT_cn_command, ALLSET_PT_connection_editor)
_WM_PROPS = ('allset_cn_left', 'allset_cn_right', 'allset_cn_left_attr', 'allset_cn_right_attr', 'allset_cn_open', 'allset_cn_mode', 'allset_cn_auto', 'allset_cn_names')

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    wm = bpy.types.WindowManager
    wm.allset_cn_left = StringProperty(name=_zh_native('Left Node', 'MWK:ui/connection_editor.py:447'), translation_context='MWK:ui/connection_editor.py:447')
    wm.allset_cn_right = StringProperty(name=_zh_native('Right Node', 'MWK:ui/connection_editor.py:448'), translation_context='MWK:ui/connection_editor.py:448')
    wm.allset_cn_left_attr = StringProperty(name=_zh_native('Left Attribute', 'MWK:ui/connection_editor.py:449'), translation_context='MWK:ui/connection_editor.py:449')
    wm.allset_cn_right_attr = StringProperty(name=_zh_native('Right Attribute', 'MWK:ui/connection_editor.py:450'), translation_context='MWK:ui/connection_editor.py:450')
    wm.allset_cn_open = StringProperty(name=_zh_native('Open Compounds', 'MWK:ui/connection_editor.py:451'), translation_context='MWK:ui/connection_editor.py:451')
    wm.allset_cn_mode = EnumProperty(name=_zh_native('Mode', 'MWK:ui/connection_editor.py:452'), items=_zh_enum(MODES, 'MWK:ui/connection_editor.py:452'), default='FROM_TO', translation_context='MWK:ui/connection_editor.py:452')
    wm.allset_cn_auto = BoolProperty(name=_zh_native('Auto-connect', 'MWK:ui/connection_editor.py:453'), default=True, description=_zh_native('A pick on the right connects / breaks at once (Maya factory: on)', 'MWK:ui/connection_editor.py:453'), translation_context='MWK:ui/connection_editor.py:453')
    wm.allset_cn_names = EnumProperty(name=_zh_native('Channel Names', 'MWK:ui/connection_editor.py:455'), default='LONG', items=_zh_enum((('NICE', 'Nice', ''), ('LONG', 'Long', ''), ('SHORT', 'Short', '')), 'MWK:ui/connection_editor.py:455'), translation_context='MWK:ui/connection_editor.py:455')

def unregister():
    for name in _WM_PROPS:
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
