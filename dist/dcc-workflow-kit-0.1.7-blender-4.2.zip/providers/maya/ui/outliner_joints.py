# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese display integration by namink.
"""Maya Outliner: a kit skeleton's row reads its root joint's name (step 258, Issue #155 H1-6).

Maya 2026: a new skeleton is ``joint1`` in the Outliner and in the Channel Box — a joint is one DAG node, there is no
skeleton node above it. The kit's skeleton is an
armature object ``skeleton<N>`` holding the joints as bones (operators/joints.py), and Blender's C Outliner shows the
object name. Renaming the object after its root joint would put an object and a bone of the same name in the scene
(the kit's ``maya.cmds`` look-up, FBX nodes and many rig tools find nodes by name; 100+ test references), so the kit
draws the label instead (delegated, step 258): a WINDOW POST_PIXEL handler finds the rows whose text is the armature
object's name and paints the root joint's name over it. Python can't ask Blender where a row is (rows of expanded
objects move the rest), so a row is recognised by its pixels: Blender's text of the object name is rendered offscreen
with the same font and compared with the row's ink; a row that doesn't match keeps Blender's text. Clicks still
reach Blender's rows; Blender's own rename field (double-click / F2) still shows the object name.

Which objects: armatures the kit named (``skeleton<N>``, ``joints.SKELETON_BASE``) with at least one root bone —
a user-named armature or a Rigify rig keeps its own name. With several root joints the first one names the row.
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
_handle = [None]
_refs = {}
INK = 48
MATCH = 0.72
DX = 4
DY = 3
SEEN = {}

def label(ob):
    """The name the Maya Outliner row of ``ob`` shows instead of the object's: its first root joint, or None."""
    from ..operators import joints
    if ob is None or ob.type != 'ARMATURE' or (not ob.name.startswith(joints.SKELETON_BASE)):
        return None
    tail = ob.name[len(joints.SKELETON_BASE):].split('.')[0]
    if tail and (not tail.isdigit()):
        return None
    roots = [b for b in ob.data.bones if b.parent is None]
    if not roots:
        return None
    return min(roots, key=joints.child_order_key).name

def _unit(prefs):
    return int(int(18.0 * prefs.system.ui_scale + 0.5) + 2 * prefs.system.pixel_size)

def _font_size(prefs):
    styles = prefs.ui_styles
    points = getattr(styles[0].widget, 'points', 11.0) if len(styles) else 11.0
    return points * prefs.system.ui_scale

def _ref(text, size, height):
    """``text`` drawn with the UI font at ``size`` in a ``height`` px row: (width, baseline, ink mask)."""
    key = (text, round(size, 2), height)
    got = _refs.get(key)
    if got is not None:
        return got
    import blf
    import gpu
    import numpy as np
    from mathutils import Matrix
    blf.size(0, size)
    w = int(blf.dimensions(0, _dcc_display(_zh(text, 'MWK:ui/outliner_joints.py:67')))[0]) + 4
    base = int(round((height - blf.dimensions(0, _dcc_display(_zh('x', 'MWK:ui/outliner_joints.py:68')))[1]) / 2.0))
    off = gpu.types.GPUOffScreen(w, height)
    try:
        with off.bind():
            fb = gpu.state.active_framebuffer_get()
            fb.clear(color=(0.0, 0.0, 0.0, 1.0))
            gpu.matrix.push_projection()
            gpu.matrix.push()
            try:
                gpu.matrix.load_identity()
                gpu.matrix.load_projection_matrix(Matrix(((2.0 / w, 0, 0, -1.0), (0, 2.0 / height, 0, -1.0), (0, 0, 1.0, 0), (0, 0, 0, 1.0))))
                gpu.state.blend_set('ALPHA')
                blf.color(0, 1.0, 1.0, 1.0, 1.0)
                blf.position(0, 1, base, 0)
                blf.draw(0, _dcc_display(_zh(text, 'MWK:ui/outliner_joints.py:83')))
            finally:
                gpu.matrix.pop()
                gpu.matrix.pop_projection()
            px = np.array(fb.read_color(0, 0, w, height, 4, 0, 'UBYTE').to_list(), dtype=np.int16)
    finally:
        off.free()
    got = (w, base, px.reshape(height, w, 4)[..., 0] > 90)
    _refs[key] = got
    return got

def _ink(lines, bg):
    """Ink mask of pixel lines (numpy int16 (h, w, 4)) against the background colour ``bg``."""
    import numpy as np
    return np.abs(lines[..., :3] - np.asarray(bg[:3], dtype=np.int16)).max(axis=-1) > INK

def _extent(cols, x0, x1):
    """(first, last) column with ink in [x0, x1), or None."""
    import numpy as np
    (x0, x1) = (max(0, x0), min(len(cols), x1))
    if x1 <= x0:
        return None
    xs = np.flatnonzero(cols[x0:x1])
    return (x0 + int(xs[0]), x0 + int(xs[-1])) if len(xs) else None

def match(ink, ref, x):
    """(score, dx, dy) of the reference mask placed at column ``x`` (± DX) and baseline ± DY in the row mask."""
    import numpy as np
    (h, w) = ref.shape
    best = (0.0, 0, 0)
    for dx in range(-DX, DX + 1):
        x0 = x + dx
        if x0 < 0 or x0 + w > ink.shape[1]:
            continue
        win = ink[:, x0:x0 + w]
        for dy in range(-DY, DY + 1):
            r = np.zeros_like(win)
            if dy > 0:
                r[dy:, :] = ref[:h - dy, :]
            elif dy < 0:
                r[:h + dy, :] = ref[-dy:, :]
            else:
                r[:, :] = ref
            union = np.count_nonzero(win | r)
            if union:
                s = np.count_nonzero(win & r) / union
                if s > best[0]:
                    best = (s, dx, dy)
    return best

def find_rows(rows, width, u, lead, names, size):
    """[(row k, depth, dx, dy, name)] of the rows (``rows`` = {k: numpy int16 (u, width, 4), bottom line first})
    whose text is one of ``names``: the same ink as Blender's text of that name (the best of the names: skeleton1
    and skeleton2 differ in one glyph), nothing right after it."""
    found = []
    for (k, lines) in rows.items():
        bg = tuple((int(c) for c in lines[u // 2, width - 2, :3]))
        ink = _ink(lines, bg)
        cols = ink.any(axis=0)
        best = None
        for name in names:
            (w, _base, ref) = _ref(name, size, u)
            ref_ext = _extent(ref.any(axis=0), 0, w)
            if ref_ext is None:
                continue
            for depth in range(0, 8):
                x = int(lead + (depth + 2.25) * u)
                if x + w > width:
                    break
                ext = _extent(cols, x + ref_ext[0] - DX - 1, x + ref_ext[1] + DX + 2)
                if ext is None or abs(ext[0] - (x + ref_ext[0])) > DX or abs(ext[1] - (x + ref_ext[1])) > DX:
                    continue
                (s, dx, dy) = match(ink, ref, x)
                if s < MATCH or (best is not None and s <= best[0]):
                    continue
                end = x + dx + ref_ext[1]
                if _extent(cols, end + 2, end + 2 + int(0.5 * u)) is not None:
                    continue
                best = (s, (k, depth, dx, dy, name))
        if best is not None:
            found.append(best[1])
    return found

def draw():
    context = bpy.context
    (space, region) = (context.space_data, context.region)
    if region is None or space is None:
        return
    from .maya_outliner import is_maya_outliner
    if not is_maya_outliner(space):
        return
    named = {}
    for ob in context.view_layer.objects:
        lab = label(ob) if ob is not None else None
        if lab is not None and lab != ob.name:
            named[ob.name] = lab
    if not named:
        return
    import math
    import blf
    import gpu
    import numpy as np
    from gpu_extras.batch import batch_for_shader
    prefs = context.preferences
    u = _unit(prefs)
    lead = 0.0 if not getattr(space, 'show_mode_column', True) else u
    size = _font_size(prefs)
    v2d = region.view2d
    fb = gpu.state.active_framebuffer_get()
    width = region.width

    def bottom_of(k):
        return int(round(v2d.view_to_region(0, -(k + 1) * u, clip=False)[1]))
    k_lo = max(0, int(math.floor(-v2d.region_to_view(0, region.height - 1)[1] / u)))
    k_hi = int(math.floor(-v2d.region_to_view(0, 0)[1] / u))
    spans = []
    for name in named:
        (w, _base, ref) = _ref(name, size, u)
        ext = _extent(ref.any(axis=0), 0, w)
        if ext is None:
            continue
        for depth in range(0, 8):
            x = int(lead + (depth + 2.25) * u)
            if x + w <= width:
                spans.append((x + ext[0], x + ext[1]))
    reach = DX + 3
    rows = {}
    for k in range(k_lo, k_hi + 1):
        y0 = bottom_of(k)
        if y0 < 0 or y0 + u > region.height:
            continue
        try:
            mid = np.array(fb.read_color(0, y0 + u // 2, width, 1, 4, 0, 'UBYTE').to_list(), dtype=np.int16).reshape(1, width, 4)
        except ValueError:
            continue
        cols = _ink(mid, tuple((int(c) for c in mid[0, width - 2, :3])))[0]
        text = _extent(cols, int(lead + 2 * u) - reach, width - 2)
        if text is None or not any((abs(text[1] - b) <= reach for (_a, b) in spans)):
            continue
        try:
            rows[k] = np.array(fb.read_color(0, y0, width, u, 4, 0, 'UBYTE').to_list(), dtype=np.int16).reshape(u, width, 4)
        except ValueError:
            continue
    hits = find_rows(rows, width, u, lead, list(named), size)
    SEEN[region.as_pointer()] = [(h[4], named[h[4]]) for h in hits]
    if not hits:
        return
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    for (k, depth, dx, dy, name) in hits:
        lines = rows[k]
        bg = tuple((int(c) for c in lines[u // 2, width - 2, :3]))
        (w, base, _mask) = _ref(name, size, u)
        x = int(lead + (depth + 2.25) * u) + dx
        y0 = bottom_of(k)
        band = lines[:, max(0, x):min(width, x + w), :3]
        diff = np.abs(band - np.asarray(bg, dtype=np.int16)).sum(axis=-1)
        if diff.size and diff.max() > INK:
            (iy, ix) = np.unravel_index(int(diff.argmax()), diff.shape)
            text_rgb = tuple((int(c) for c in band[iy, ix]))
        else:
            text_rgb = (220, 220, 220)
        gpu.state.blend_set('NONE')
        (x0, x1) = (x - 1, x + w + 2)
        batch = batch_for_shader(shader, 'TRIS', {'pos': [(x0, y0 + 1), (x1, y0 + 1), (x1, y0 + u - 1), (x0, y0 + u - 1)]}, indices=[(0, 1, 2), (0, 2, 3)])
        shader.uniform_float('color', (bg[0] / 255.0, bg[1] / 255.0, bg[2] / 255.0, 1.0))
        batch.draw(shader)
        gpu.state.blend_set('ALPHA')
        blf.size(0, size)
        blf.color(0, text_rgb[0] / 255.0, text_rgb[1] / 255.0, text_rgb[2] / 255.0, 1.0)
        blf.position(0, x + 1, y0 + base + dy, 0)
        blf.draw(0, _dcc_display(str(named[name])))
    gpu.state.blend_set('NONE')

def register():
    _handle[0] = bpy.types.SpaceOutliner.draw_handler_add(draw, (), 'WINDOW', 'POST_PIXEL')

def unregister():
    if _handle[0] is not None:
        bpy.types.SpaceOutliner.draw_handler_remove(_handle[0], 'WINDOW')
        _handle[0] = None
    _refs.clear()
    SEEN.clear()
