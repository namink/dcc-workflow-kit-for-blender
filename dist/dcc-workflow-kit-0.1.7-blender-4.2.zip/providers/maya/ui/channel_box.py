# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese display integration by namink.
"""Maya Channel Box in the 3D View sidebar (category "Channel Box / Layer Editor", step 99).

Maya's Channel Box; design: docs/steps/step_6.md 「계획」.
- Translate/Rotate/Scale/Visibility rows are getter/setter proxies on
  ``Scene.allset_cb``: they read the lead (active) object and write every
  selected object, like Maya.
- Channel names are buttons that select channels; selected channels drive
  the MMB virtual slider in the viewport and the
  Channels menu (§2.4).
- Value fields are text (step 38): Maya numbers in display units and relative entry
  (``+=5``, ``*=2``; ui/cb_entry.py), applied to every selected object that has the
  channel and to every selected channel when the edited row is one of them.
- Custom properties, SHAPES (object data) and INPUTS (modifiers = construction history,
  §4) are rows in ``Scene.allset_cb.rows`` (rebuilt from handlers), so their edits reach
  the same-named channel of the other selected objects too; stale rows fall back to the
  lead object's real properties.
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import math
import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from .. import results
from ..operators import auto_key, display
from .. import compat
from . import cb_entry, cb_points, chrome
CATEGORY = _dcc_source('Channel Box / Layer Editor')
AE_CATEGORY = _dcc_source('Attribute Editor')
MTK_CATEGORY = _dcc_source('Modeling Toolkit')
CB_SHARE = 0.5
CB_SHARE_MAX = 0.62
CB_LINES = 14

def cb_share(region, u):
    """Share of the dock height above the Layer Editor: Maya's 0.48 (CB_SHARE), more on a short
    dock so a selected primitive's collapsed Channel Box (CB_LINES) still fits
    without scrolling — fixed for a given dock height, like Maya's split (step 135, delegated)."""
    if region is None or region.height <= 0 or u <= 0:
        return CB_SHARE
    need = (PANE_TOP + 3.0 + 0.3 + CB_LINES * ROW_SCALE) * u
    return min(CB_SHARE_MAX, max(CB_SHARE, need / region.height))
MAIN = (('tx', _dcc_source('Translate X'), 'location', 0, 'LOC'), ('ty', _dcc_source('Translate Y'), 'location', 1, 'LOC'), ('tz', _dcc_source('Translate Z'), 'location', 2, 'LOC'), ('rx', _dcc_source('Rotate X'), 'rotation_euler', 0, 'ROT'), ('ry', _dcc_source('Rotate Y'), 'rotation_euler', 1, 'ROT'), ('rz', _dcc_source('Rotate Z'), 'rotation_euler', 2, 'ROT'), ('sx', _dcc_source('Scale X'), 'scale', 0, 'SCALE'), ('sy', _dcc_source('Scale Y'), 'scale', 1, 'SCALE'), ('sz', _dcc_source('Scale Z'), 'scale', 2, 'SCALE'), ('v', _dcc_source('Visibility'), 'hide_viewport', -1, 'VIS'))
MAIN_BY_KEY = {c[0]: c for c in MAIN}
_LOCK_PROP = {'LOC': 'lock_location', 'ROT': 'lock_rotation', 'SCALE': 'lock_scale'}
HIDDEN_PROP = 'allset_cb_hidden'
NONKEYABLE_PROP = 'allset_cb_nonkeyable'
CUSTOM_PREFIX = 'cp:'
SHAPE_PREFIX = 'sh:'
SLIDER_STEP = {'LOC': 0.01, 'ROT': math.radians(0.5), 'SCALE': 0.01, 'CUSTOM': 0.01}
SPEEDS = (('SLOWEST', _dcc_source('Slowest'), 'x0.01', 0.01), ('SLOW', _dcc_source('Slow'), 'x0.1', 0.1), ('MEDIUM', _dcc_source('Medium'), 'x1', 1.0), ('FAST', _dcc_source('Fast'), 'x10', 10.0))
SPEED_FACTOR = {s[0]: s[3] for s in SPEEDS}

def is_bone(node):
    return isinstance(node, bpy.types.PoseBone)

def is_root_joint(node):
    """A joint without a parent joint: a Maya root joint (its parent is the world)."""
    return is_bone(node) and node.parent is None

def root_translate(pb):
    """Translate X / Y / Z of a root joint = its position (Maya 2026: a root joint at (3, 2, 1) shows Translate
    3 / 2 / 1): rest head + pose offset, armature space, in the kit's Z-up axes
    like every object Translate (decision 2, step 239; operators/joint_edit.joint_translate shows the same in Edit
    mode). Blender keeps a pose bone's offset in the bone's rest axes."""
    b = pb.bone
    return b.head_local + b.matrix_local.to_3x3().normalized() @ pb.location

def set_root_translate(pb, t):
    """Move root joint ``pb`` so ``root_translate`` reads ``t`` (Blender length)."""
    from mathutils import Vector
    b = pb.bone
    pb.location = b.matrix_local.to_3x3().normalized().transposed() @ (Vector(t) - b.head_local)

def bone_selected(pb):
    sel = getattr(pb, 'select', None)
    return pb.bone.select if sel is None else sel

def set_bone_selected(pb, state):
    if hasattr(pb, 'select'):
        pb.select = state
    else:
        pb.bone.select = state

def active_object(context=None):
    """``context.active_object``, else the view layer's: a depsgraph handler running while a File Browser or
    Preferences window has the context gets no ``active_object`` member (step 98)."""
    context = context or bpy.context
    if hasattr(context, 'active_object'):
        return context.active_object
    view_layer = getattr(context, 'view_layer', None)
    return view_layer.objects.active if view_layer is not None else None

def pose_armature(context=None):
    """The active armature when it is in pose mode (= Maya: joints are being picked)."""
    ob = active_object(context)
    return ob if ob is not None and ob.type == 'ARMATURE' and (ob.mode == 'POSE') else None

def placing_joints(context=None):
    ob = active_object(context)
    return ob is not None and ob.type == 'ARMATURE' and (ob.mode == 'EDIT')

def pose_objects(context=None):
    context = context or bpy.context
    arm = pose_armature(context)
    if arm is None:
        return []
    others = [o for o in context.view_layer.objects if o is not arm and o.type == 'ARMATURE' and (o.mode == 'POSE')]
    return [arm] + others

def selected_bones(context=None):
    return [pb for arm in pose_objects(context) for pb in arm.pose.bones if bone_selected(pb) and (not compat.bone_hidden(pb))]

def lead(context=None):
    """The Maya lead: the active object, or in pose mode the active (selected) pose bone."""
    context = context or bpy.context
    arm = pose_armature(context)
    if arm is None:
        return active_object(context)
    act = arm.data.bones.active
    pb = arm.pose.bones.get(act.name) if act is not None else None
    if pb is not None and bone_selected(pb) and (not compat.bone_hidden(pb)):
        return pb
    sel = selected_bones(context)
    return sel[0] if sel else None

def targets(context=None):
    """Lead + selected objects / pose bones (lead first), like Maya's selection list."""
    context = context or bpy.context
    nodes = selected_bones(context) if pose_armature(context) else list(context.selected_objects)
    ld = lead(context)
    if ld is not None:
        nodes = [ld] + [n for n in nodes if n != ld]
    return nodes

def full_path(node, path):
    """Animation data path of ``path`` on the node's ID (the armature object for a bone)."""
    if not is_bone(node):
        return path
    return None if path == 'hide_viewport' else node.path_from_id(path)

def _flag_list(ob, prop):
    raw = ob.get(prop, '')
    return [s for s in raw.split(',') if s] if isinstance(raw, str) else []

def _set_flag_list(ob, prop, keys):
    if keys:
        ob[prop] = ','.join(sorted(set(keys)))
    elif prop in ob:
        del ob[prop]

def is_hidden(ob, key):
    return key in _flag_list(ob, HIDDEN_PROP)

def is_keyable(ob, key):
    if key == 'v' and is_bone(ob):
        return False
    return key not in _flag_list(ob, NONKEYABLE_PROP)

def is_locked(ob, key):
    c = MAIN_BY_KEY.get(key)
    if c is None or c[4] not in _LOCK_PROP:
        return False
    return bool(getattr(ob, _LOCK_PROP[c[4]])[c[3]])

def set_locked(ob, key, locked):
    c = MAIN_BY_KEY.get(key)
    if c is None or c[4] not in _LOCK_PROP:
        return False
    arr = getattr(ob, _LOCK_PROP[c[4]])
    arr[c[3]] = locked
    return True

def custom_keys(ob):
    """Numeric custom properties = Maya extra (user-defined) attributes."""
    out = []
    for k in ob.keys():
        if k.startswith('_') or k.startswith('allset_'):
            continue
        if isinstance(ob[k], (int, float)):
            out.append(k)
    return sorted(out)

def is_shape_key(key):
    return key.startswith(SHAPE_PREFIX)

def shape_owner(ob, key):
    """The object data holding SHAPES channel ``key`` (None: ``ob`` has no such row)."""
    if not is_shape_key(key) or is_bone(ob):
        return None
    name = key[len(SHAPE_PREFIX):]
    if name not in SHAPE_PROPS.get(getattr(ob, 'type', ''), ()):
        return None
    return row_owner(ob, 'SHAPE', name)

def shape_paths(owner, key):
    """[(Blender data path, index)] a key / mute / delete on a SHAPES channel acts on (step 158): a Maya attribute
    kept differently in Blender keys its Blender properties (Light Intensity = power, Color R = color[0], spot Cone /
    Penumbra = spot_size + spot_blend)."""
    name = key[len(SHAPE_PREFIX):]
    v = _virtual(owner, name)
    if v is not None:
        return list(getattr(v, 'paths', ()))
    if isinstance(owner, bpy.types.Light):
        from ..operators import lights
        if name in lights.KEY_PATHS:
            return lights.key_paths(owner, name)
    rna = owner.bl_rna.properties.get(name)
    return [(name, -1)] if rna is not None and rna.is_animatable else []

def curve_owner(ob, key):
    """The ID whose animation holds channel ``key``'s curves."""
    return shape_owner(ob, key) if is_shape_key(key) else ob.id_data

def channel_path(key):
    """(data path, index, kind) for a channel key."""
    if key.startswith(CUSTOM_PREFIX):
        return (f'["{key[len(CUSTOM_PREFIX):]}"]', -1, 'CUSTOM')
    if is_shape_key(key):
        return (key[len(SHAPE_PREFIX):], -1, 'SHAPE')
    c = MAIN_BY_KEY[key]
    return (c[2], c[3], c[4])

def nice_name(name):
    """Maya's nice attribute name (Channel Names > Nice, the default):
    ``fingerCurl`` -> "Finger Curl", ``curl`` -> "Curl", ``ik_blend2`` -> "Ik Blend 2"."""
    import re
    words = re.sub('(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Za-z])(?=[0-9])', ' ', name.replace('_', ' ')).split()
    return ' '.join((w[:1].upper() + w[1:] for w in words)) or name

def channel_label(key):
    if key.startswith(CUSTOM_PREFIX):
        return nice_name(key[len(CUSTOM_PREFIX):])
    if is_shape_key(key):
        ob = lead()
        name = key[len(SHAPE_PREFIX):]
        return shape_label(ob, name) if ob is not None and shape_owner(ob, key) is not None else nice_name(name)
    return MAIN_BY_KEY[key][1]

def has_channel(ob, key):
    if key.startswith(CUSTOM_PREFIX):
        return key[len(CUSTOM_PREFIX):] in ob.keys()
    if is_shape_key(key):
        return shape_owner(ob, key) is not None
    return MAIN_BY_KEY[key][4] != 'ROT' or hasattr(ob, 'rotation_mode')

def _non_euler_rot(ob, kind):
    return kind == 'ROT' and getattr(ob, 'rotation_mode', 'XYZ') in ('QUATERNION', 'AXIS_ANGLE')

def get_value(ob, key):
    (path, idx, kind) = channel_path(key)
    if kind == 'SHAPE':
        return _row_read(shape_owner(ob, key), 'SHAPE', path)
    if kind == 'CUSTOM':
        return ob[key[len(CUSTOM_PREFIX):]]
    if kind == 'VIS':
        return not (compat.bone_hidden(ob) if is_bone(ob) else ob.hide_viewport)
    if _non_euler_rot(ob, kind):
        from .. import rotation_display
        return rotation_display.shown_euler(ob)[idx]
    if kind == 'LOC' and is_root_joint(ob):
        return root_translate(ob)[idx]
    return getattr(ob, path)[idx]
WRITE_HOOKS = []

def set_value(ob, key, value):
    for hook in WRITE_HOOKS:
        hook(ob, key)
    (path, idx, kind) = channel_path(key)
    if kind == 'SHAPE':
        _row_write(shape_owner(ob, key), 'SHAPE', path, value)
        return
    if kind == 'CUSTOM':
        name = key[len(CUSTOM_PREFIX):]
        cur = ob[name]
        if isinstance(cur, (int, float)) and (not isinstance(cur, bool)):
            try:
                ui = ob.id_properties_ui(name).as_dict()
                value = max(ui.get('min', value), min(ui.get('max', value), value))
            except TypeError:
                pass
        ob[name] = type(cur)(value)
        ob.id_data.update_tag()
    elif kind == 'VIS':
        if is_bone(ob):
            compat.set_bone_hidden(ob, not value)
        else:
            ob.hide_viewport = not value
    elif _non_euler_rot(ob, kind):
        from .. import rotation_display
        rotation_display.set_component(ob, idx, value)
    elif kind == 'LOC' and is_root_joint(ob):
        t = root_translate(ob)
        t[idx] = value
        set_root_translate(ob, t)
    else:
        getattr(ob, path)[idx] = value

def keyframe(ob, key, keytype='KEYFRAME'):
    (path, idx, kind) = channel_path(key)
    if kind == 'VIS' and is_bone(ob):
        return False
    if _non_euler_rot(ob, kind):
        from .. import rotation_display
        (path, idx) = (rotation_display.curve_path(ob), -1)
    elif kind == 'LOC' and is_root_joint(ob):
        idx = -1
    if kind == 'SHAPE':
        owner = shape_owner(ob, key)
        if owner is None:
            return False
        from ..operators import graph_key_menu
        done = False
        for (p, i) in shape_paths(owner, key):
            try:
                if owner.keyframe_insert(p, index=i, keytype=keytype):
                    graph_key_menu.after_insert(owner, p, i, bpy.context.scene.frame_current)
                    done = True
            except (TypeError, RuntimeError):
                pass
        return done
    from ..operators import anim_layers
    if isinstance(ob, bpy.types.Object) and anim_layers.has_layers(ob):
        return anim_layers.key(ob, path, idx)
    if is_bone(ob) and anim_layers.has_layers(ob.id_data):
        return anim_layers.key_pose_bone(ob, path, idx)
    ok = ob.keyframe_insert(path, index=idx, keytype=keytype)
    if ok:
        from ..operators import graph_key_menu
        graph_key_menu.after_insert(ob, path, idx, bpy.context.scene.frame_current)
    return ok

def _fcurves(ob):
    from .. import compat
    return compat.id_fcurve_collection(ob.id_data)

def shape_fcurves(ob, key):
    owner = shape_owner(ob, key)
    if owner is None:
        return []
    fcs = compat.id_fcurve_collection(owner)
    if fcs is None:
        return []
    out = []
    for (p, i) in shape_paths(owner, key):
        fc = fcs.find(p, index=max(i, 0))
        if fc is not None:
            out.append(fc)
    return out

def fcurve(ob, key):
    if is_shape_key(key):
        fcs = shape_fcurves(ob, key)
        return fcs[0] if fcs else None
    fcs = _fcurves(ob)
    if fcs is None:
        return None
    (path, idx, kind) = channel_path(key)
    if _non_euler_rot(ob, kind):
        from .. import rotation_display
        path = full_path(ob, rotation_display.curve_path(ob))
        return None if path is None else next((fc for i in range(4) for fc in [fcs.find(path, index=i)] if fc), None)
    path = full_path(ob, path)
    return None if path is None else fcs.find(path, index=max(idx, 0))

def channel_fcurves(ob, key):
    """Every F-curve behind a channel (a SHAPES channel can have several: spot Cone Angle = size + blend)."""
    if is_shape_key(key):
        return shape_fcurves(ob, key)
    if _non_euler_rot(ob, MAIN_BY_KEY.get(key, ('', '', '', 0, ''))[4]):
        from .. import rotation_display
        (fcs, path) = (_fcurves(ob), full_path(ob, rotation_display.curve_path(ob)))
        return [fc for i in range(4) for fc in [fcs.find(path, index=i) if fcs is not None and path else None] if fc]
    fc = fcurve(ob, key)
    return [fc] if fc is not None else []

def remove_channel_curves(ob, key):
    """Delete the channel's animation curves (Maya cutKey -clear on the whole curve). True if any."""
    owner = curve_owner(ob, key)
    fcs = compat.id_fcurve_collection(owner) if owner is not None else None
    curves = channel_fcurves(ob, key)
    for fc in curves:
        fcs.remove(fc)
    return bool(curves)

def driver(ob, key):
    if is_shape_key(key):
        return None
    ad = ob.id_data.animation_data
    if ad is None:
        return None
    (path, idx, _kind) = channel_path(key)
    path = full_path(ob, path)
    return None if path is None else ad.drivers.find(path, index=max(idx, 0))

def channel_state(ob, key, frame=None):
    """'DRIVEN', 'MUTED', 'LAYERED', 'KEYED' (key on this frame), 'ANIMATED' or None (Maya
    muted = brown, step 158: Blender's UI has no brown, the mute icon marks it). Step 194: a channel in an animation
    layer above BaseAnimation is Maya's teal #4db6ac in every layer state, keyed or not
    (Maya); the other channels of a layered object show their BaseAnimation keys."""
    if driver(ob, key) is not None:
        return 'DRIVEN'
    fc = fcurve(ob, key)
    if not is_shape_key(key) and (isinstance(ob, bpy.types.Object) or is_bone(ob)):
        from ..operators import anim_layers
        id_ob = ob.id_data
        if anim_layers.has_layers(id_ob):
            (path, idx, _kind) = channel_path(key)
            path = full_path(ob, path) if path is not None else None
            if path is not None:
                if anim_layers.member_of_layer(id_ob, path, idx):
                    return 'LAYERED'
                fc = anim_layers.base_curve(id_ob, path, idx)
    if fc is None:
        return None
    if fc.mute:
        return 'MUTED'
    frame = bpy.context.scene.frame_current if frame is None else frame
    if any((abs(kp.co[0] - frame) < 0.5 for kp in fc.keyframe_points)):
        return 'KEYED'
    return 'ANIMATED'

def selected_channels(context=None):
    wm = (context or bpy.context).window_manager
    return [s for s in wm.allset_cb_selected.split(',') if s]

def set_selected_channels(keys, context=None):
    wm = (context or bpy.context).window_manager
    wm.allset_cb_selected = ','.join(dict.fromkeys(keys))
    from . import cb_channels
    cb_channels.after_selection(context or bpy.context)

def select_channel(key, mode='SET', context=None):
    """mode: SET (click), TOGGLE (Ctrl), EXTEND (Shift)."""
    sel = selected_channels(context)
    if mode == 'SET':
        sel = [key]
    elif mode == 'TOGGLE':
        sel = [k for k in sel if k != key] if key in sel else sel + [key]
    else:
        sel = sel + [key]
    set_selected_channels(sel, context)
    return sel

def drawn_keys(ob):
    """Channel keys in the order the Channel Box draws them (main channels, custom attributes, SHAPES rows)."""
    keys = [c[0] for c in MAIN if not is_hidden(ob, c[0]) and has_channel(ob, c[0])]
    keys += [CUSTOM_PREFIX + n for n in custom_keys(ob) if not is_hidden(ob, CUSTOM_PREFIX + n)]
    keys += [SHAPE_PREFIX + n for n in SHAPE_PROPS.get(getattr(ob, 'type', ''), ()) if has_channel(ob, SHAPE_PREFIX + n) and (not is_hidden(ob, SHAPE_PREFIX + n))]
    return keys

def channel_range(ob, first, last):
    """The drawn channels from ``first`` to ``last`` (either order), top to bottom."""
    keys = drawn_keys(ob)
    if first not in keys or last not in keys:
        return [k for k in (first, last) if k in keys]
    (i, j) = sorted((keys.index(first), keys.index(last)))
    return keys[i:j + 1]

def select_range(ob, first, last, mode='SET', base=None, context=None):
    """Select the rows ``first``..``last``: SET replaces the selection, ADD adds to ``base`` (default: the current
    selection). Maya: drag over channel names / fields selects a range, Ctrl+drag adds."""
    rng = channel_range(ob, first, last)
    if mode == 'SET':
        sel = rng
    else:
        sel = list(selected_channels(context) if base is None else base) + rng
    set_selected_channels(sel, context)
    return selected_channels(context)

def _sel_get(key):

    def get(_self):
        return key in selected_channels()
    return get

def _sel_set(key):

    def set_(_self, value):
        sel = [k for k in selected_channels() if k != key]
        set_selected_channels(sel + [key] if value else sel)
    return set_

def cell_key(path, scene=None):
    """(channel key, "NAME" / "VALUE") of a Channel Box cell from its data path (``context.property``), or None."""
    import re
    m = re.match('^allset_cb\\.([a-z]+)_(text|sel)$', path or '')
    if m and m.group(1) in MAIN_BY_KEY:
        return (m.group(1), 'VALUE' if m.group(2) == 'text' else 'NAME')
    m = re.match('^allset_cb\\.rows\\[(\\d+)\\]\\.(text|sel)$', path or '')
    if m and scene is not None:
        rows = scene.allset_cb.rows
        i = int(m.group(1))
        if i < len(rows) and rows[i].kind in ('CUSTOM', 'SHAPE'):
            prefix = CUSTOM_PREFIX if rows[i].kind == 'CUSTOM' else SHAPE_PREFIX
            return (prefix + rows[i].name, 'VALUE' if m.group(2) == 'text' else 'NAME')
    return None

def _proxy_get(key):

    def get(_self):
        ob = lead()
        if ob is None or not has_channel(ob, key):
            return False if MAIN_BY_KEY[key][4] == 'VIS' else 0.0
        return get_value(ob, key)
    return get

def _proxy_set(key):

    def set_(_self, value):
        context = bpy.context
        autokey = auto_key.enabled(context.scene)
        for ob in targets(context):
            if not has_channel(ob, key) or is_locked(ob, key):
                continue
            set_value(ob, key, value)
            if autokey and auto_keys(ob, key, context):
                keyframe(ob, key)
    return set_

def auto_keys(ob, key, context=None):
    """Auto Key keys this channel: keyable and (Maya) already keyed (step 70; the kit's own Auto Key since step 130,
    operators/auto_key.py)."""
    if not is_keyable(ob, key):
        return False
    return fcurve(ob, key) is not None
_KIND_ENTRY = {'LOC': 'LENGTH', 'ROT': 'ROTATION', 'SCALE': 'NONE', 'VIS': 'BOOL'}

def entry_kind(ob, key):
    if key.startswith(CUSTOM_PREFIX):
        return cb_entry.kind_of_value(ob.get(key[len(CUSTOM_PREFIX):]))
    if is_shape_key(key):
        return _row_kind(shape_owner(ob, key), 'SHAPE', key[len(SHAPE_PREFIX):])
    return _KIND_ENTRY[MAIN_BY_KEY[key][4]]

def entry_keys(key, context=None):
    """The edited channel, or every selected channel when it is one of them."""
    sel = selected_channels(context)
    return sel if key in sel else [key]

def apply_entry(key, text, context=None):
    """Typed text on channel ``key``: absolute or relative (``+=``...) per object, on every
    selected object that has the channel; returns how many values changed."""
    context = context or bpy.context
    scene = context.scene
    autokey = auto_key.enabled(scene)
    count = 0
    for k in entry_keys(key, context):
        for ob in targets(context):
            if not has_channel(ob, k) or is_locked(ob, k):
                continue
            kind = entry_kind(ob, k)
            if kind is None:
                continue
            try:
                value = cb_entry.parse_entry(text, get_value(ob, k), kind, scene)
            except (ValueError, TypeError, SyntaxError):
                return count
            set_value(ob, k, value)
            count += 1
            if autokey and auto_keys(ob, k, context):
                keyframe(ob, k)
    return count

def _text_get(key):

    def get(_self):
        ob = lead()
        if ob is None or not has_channel(ob, key):
            return ''
        return cb_entry.format_value(get_value(ob, key), entry_kind(ob, key), bpy.context.scene)
    return get

def _text_set(key):

    def set_(_self, text):
        apply_entry(key, text)
    return set_

def _inputs(ob):
    from ..operators import deformers, skin_method, skin_tools_199
    return [m for m in getattr(ob, 'modifiers', ()) if not display.is_preview(m) and (not deformers.is_base(m)) and (not skin_tools_199.is_part(m)) and (not skin_method.is_part(m))] + deformers.driven_modifiers(ob)

def _virtual(owner, name):
    """The Maya attribute behind an INPUTS row ``maya:<key>`` of a kit deformer (operators/deformers.ATTRS), or a
    SHAPES row of a light (Color R / G / B, operators/lights.channel_attrs, step 148)."""
    if not name.startswith('maya:'):
        return None
    if isinstance(owner, bpy.types.Light):
        from ..operators import lights
        return lights.channel_attr(name, owner)
    if not isinstance(owner, bpy.types.Modifier):
        return None
    from ..operators import deformers
    return deformers.attr(owner, name)

def input_label(mod, name):
    """Channel Box label of INPUTS row ``name`` of modifier ``mod`` (a Maya attribute, else the RNA name)."""
    v = _virtual(mod, name)
    if v is not None:
        return v.label
    rna = mod.bl_rna.properties.get(name)
    return rna.name if rna is not None else name
SHAPE_LABELS = {('LATTICE', 'points_u'): _dcc_source('S Divisions'), ('LATTICE', 'points_w'): _dcc_source('T Divisions'), ('LATTICE', 'points_v'): _dcc_source('U Divisions')}

def shape_label(ob, prop):
    label = SHAPE_LABELS.get((ob.type, prop))
    v = _virtual(ob.data, prop)
    if label is None and v is not None:
        label = v.label
    if label is None:
        rna = ob.data.bl_rna.properties.get(prop)
        label = rna.name if rna is not None else prop
    return label
_open = {'lead': None, 'nodes': set()}

def lead_key(ob):
    if ob is None:
        return None
    if is_bone(ob):
        return ('BONE', ob.id_data.name, ob.name)
    return ('OB', ob.name)

def open_nodes(ob):
    """The expanded INPUTS node keys of lead ``ob`` (emptied when the lead changed, Maya's behaviour)."""
    key = lead_key(ob)
    if key != _open['lead']:
        _open['lead'] = key
        _open['nodes'] = set()
        _scroll.clear()
    return _open['nodes']

def is_open(ob, node):
    return node in open_nodes(ob)

def set_open(ob, node, state=True):
    nodes = open_nodes(ob)
    if state:
        nodes.add(node)
    else:
        nodes.discard(node)

def mod_node(mod):
    return 'mod:' + mod.name

def history_node(name):
    """A Maya history node drawn by the kit (creation node polyCube1, extrusion polyExtrudeFace1)."""
    return 'node:' + name

def con_node(node, con):
    return 'con:' + constraint_node_name(node, con)

def reset_open():
    _open['lead'] = None
    _open['nodes'] = set()
    _scroll.clear()
MAYA_CONSTRAINT = {'CHILD_OF': 'parentConstraint', 'COPY_TRANSFORMS': 'parentConstraint', 'COPY_LOCATION': 'pointConstraint', 'COPY_ROTATION': 'orientConstraint', 'COPY_SCALE': 'scaleConstraint', 'TRACK_TO': 'aimConstraint', 'DAMPED_TRACK': 'aimConstraint', 'LOCKED_TRACK': 'aimConstraint'}
_AIM = ('TRACK_TO', 'DAMPED_TRACK', 'LOCKED_TRACK')

def constraints(node):
    """Constraints shown as INPUTS nodes (Limit constraints are Maya transform limits: AE only)."""
    from ..operators import constrain_interp, rig_tools
    return [c for c in getattr(node, 'constraints', ()) if not c.type.startswith('LIMIT_') and (not constrain_interp.is_blend(c)) and (not rig_tools.is_up_companion(c))]

def constraint_enabled(con):
    en = getattr(con, 'enabled', None)
    return not con.mute if en is None else bool(en)

def _nth_constraint(node, con):
    return [c for c in constraints(node) if c.type == con.type].index(con)

def maya_constraint_type(con, default=None):
    """Maya node type of a kit constraint: normal / tangent constraints are a Track To on a helper (step 199,
    operators/constrain_199.maya_type), UV / Proximity Pins a Copy Transforms on a helper (step 205,
    operators/pins_205.pin_type), a kit multi-target group its own type (a parent group's Copy Location / Rotation,
    step 226, operators/constrain_multi.py), the rest by Blender type."""
    from ..operators import constrain_multi
    grouped = constrain_multi.group_type(con)
    if grouped is not None:
        return grouped
    if con.type == 'COPY_TRANSFORMS':
        from ..operators import pins_205
        kind = pins_205.pin_type(con)
        if kind is not None:
            return kind
    if con.type in _AIM:
        from ..operators import constrain_199
        kind = constrain_199.maya_type(con)
        if kind in ('normal', 'tangent'):
            return f'{kind}Constraint'
    return MAYA_CONSTRAINT.get(con.type, default)

def constraint_node_name(node, con):
    """Maya's name for the constraint node: ``<node>_<type><n>`` (pCube1_parentConstraint1)."""
    from ..operators import constrain_multi
    con = constrain_multi.head_of(con, node)
    mtype = maya_constraint_type(con)
    if mtype is None:
        return con.name
    from ..operators import pins_205
    pin = pins_205.node_name(con)
    if pin is not None:
        return pin
    from ..operators import constrain_multi
    head = constrain_multi.head_of(con, node)
    same = [c for c in constraints(node) if constrain_multi.is_head(c, node) and maya_constraint_type(c) == mtype]
    return f'{node.name}_{mtype}{same.index(head) + 1}'

def weight_name(con):
    """Maya target weight attribute: ``<target>W0`` (one target per Blender constraint; normal / tangent
    constraints name their surface / curve, step 199; a member of a kit multi-target group = ``<target>W<i>``,
    step 226)."""
    from ..operators import constrain_199, constrain_multi, pins_205
    mb = constrain_multi.member(con)
    if mb is not None:
        return f'{mb.label}W{mb.index}'
    geometry = pins_205.geometry_of(con)
    if geometry is not None:
        return f'{geometry.name}W0'
    (surface, _sub) = constrain_199.maya_target(con)
    if surface is not None and surface is not getattr(con, 'target', None):
        return f'{surface.name}W0'
    target = getattr(con, 'target', None)
    if target is None:
        return 'W0'
    sub = getattr(con, 'subtarget', '')
    return f"{(sub if target.type == 'ARMATURE' and sub else target.name)}W0"

def _axes(con, pattern):
    return [a for a in 'xyz' if getattr(con, pattern.format(a), True)]

def constrained_keys(node):
    """Channel keys an enabled constraint drives (Maya draws them blue)."""
    out = set()
    for con in constraints(node):
        if not constraint_enabled(con):
            continue
        t = con.type
        if t == 'CHILD_OF':
            for (k, pattern) in (('t', 'use_location_{}'), ('r', 'use_rotation_{}'), ('s', 'use_scale_{}')):
                out.update((k + a for a in _axes(con, pattern)))
        elif t in ('COPY_TRANSFORMS', 'ARMATURE'):
            out.update((k for k in MAIN_BY_KEY if k != 'v'))
        elif t == 'COPY_LOCATION':
            out.update(('t' + a for a in _axes(con, 'use_{}')))
        elif t == 'COPY_ROTATION':
            out.update(('r' + a for a in _axes(con, 'use_{}')))
        elif t == 'COPY_SCALE':
            out.update(('s' + a for a in _axes(con, 'use_{}')))
        elif t in _AIM:
            out.update(('rx', 'ry', 'rz'))
    return out

def _nth_of_type(ob, mod):
    return [m for m in _inputs(ob) if m.type == mod.type].index(mod)

def row_owner(ob, kind, name, mod_type='', nth=0, lead_ob=None):
    """The struct holding row ``name`` on ``ob`` (None: ob has no such channel).

    Same-named channel (docs/steps/step_38.md 「계획」 3): custom = same property name,
    SHAPE = same object type and data property, INPUT = same modifier type at the same
    position among that type."""
    if kind == 'CUSTOM':
        return ob if name in ob.keys() else None
    if kind == 'SHAPE':
        data = getattr(ob, 'data', None)
        if data is None or (lead_ob is not None and ob.type != lead_ob.type):
            return None
        return data if name in data.bl_rna.properties or _virtual(data, name) is not None else None
    if kind == 'INPUT':
        mods = [m for m in _inputs(ob) if m.type == mod_type]
        if nth < len(mods) and (name in mods[nth].bl_rna.properties or _virtual(mods[nth], name) is not None):
            return mods[nth]
    if kind == 'CONSTRAINT':
        cons = [c for c in constraints(ob) if c.type == mod_type]
        if nth < len(cons) and name in cons[nth].bl_rna.properties:
            return cons[nth]
    return None

def _row_kind(owner, kind, name):
    if kind == 'CUSTOM':
        return cb_entry.kind_of_value(owner.get(name))
    v = _virtual(owner, name)
    if v is not None:
        return v.kind
    return cb_entry.kind_of_rna(owner.bl_rna.properties[name])

def _row_read(owner, kind, name):
    if kind == 'CUSTOM':
        return owner[name]
    v = _virtual(owner, name)
    return v.get(owner) if v is not None else getattr(owner, name)

def _row_write(owner, kind, name, value):
    if kind == 'CUSTOM':
        owner[name] = type(owner[name])(value)
        return
    v = _virtual(owner, name)
    if v is not None:
        v.set(owner, value)
    else:
        setattr(owner, name, value)

def _row_get(self):
    ob = lead()
    if ob is None:
        return ''
    owner = row_owner(ob, self.kind, self.name, self.mod_type, self.nth)
    if owner is None:
        return ''
    entry = _row_kind(owner, self.kind, self.name)
    return cb_entry.format_value(_row_read(owner, self.kind, self.name), entry, bpy.context.scene)

def apply_row_entry(row, text, context=None):
    """Typed text on a custom / SHAPES / INPUTS row: every selected object with that channel."""
    context = context or bpy.context
    if row.kind == 'CUSTOM':
        return apply_entry(CUSTOM_PREFIX + row.name, text, context)
    ld = lead(context)
    count = 0
    for ob in targets(context):
        owner = row_owner(ob, row.kind, row.name, row.mod_type, row.nth, ld)
        if owner is None:
            continue
        entry = _row_kind(owner, row.kind, row.name)
        try:
            value = cb_entry.parse_entry(text, _row_read(owner, row.kind, row.name), entry, context.scene)
        except (ValueError, TypeError, SyntaxError):
            return count
        try:
            _row_write(owner, row.kind, row.name, value)
        except (TypeError, ValueError, AttributeError):
            continue
        count += 1
    return count

def _row_set(self, text):
    apply_row_entry(self, text)
_ROW_PREFIX = {'CUSTOM': CUSTOM_PREFIX, 'SHAPE': SHAPE_PREFIX}

def _row_sel_get(self):
    prefix = _ROW_PREFIX.get(self.kind)
    return prefix is not None and prefix + self.name in selected_channels()

def _row_sel_set(self, value):
    prefix = _ROW_PREFIX.get(self.kind)
    if prefix is not None:
        _sel_set(prefix + self.name)(self, value)

class ALLSET_PG_cb_row(bpy.types.PropertyGroup):
    kind: StringProperty(translation_context='MWK:ui/channel_box.py:1027')
    name: StringProperty(translation_context='MWK:ui/channel_box.py:1028')
    mod_type: StringProperty(translation_context='MWK:ui/channel_box.py:1029')
    nth: IntProperty(translation_context='MWK:ui/channel_box.py:1030')
    text: StringProperty(get=_row_get, set=_row_set, translation_context='MWK:ui/channel_box.py:1031')
    sel: BoolProperty(name=_zh_native('Selected', 'MWK:ui/channel_box.py:1032'), get=_row_sel_get, set=_row_sel_set, description=_zh_native('Select this channel: click, Ctrl toggle, Shift range, drag over the rows', 'MWK:ui/channel_box.py:1032'), translation_context='MWK:ui/channel_box.py:1032')

def _make_proxy_annotations():
    ann = {}
    for (key, label, _path, _idx, kind) in MAIN:
        if kind == 'VIS':
            ann[key] = BoolProperty(name=_zh_native(label, 'MWK:ui/channel_box.py:1040'), get=_proxy_get(key), set=_proxy_set(key), translation_context='MWK:ui/channel_box.py:1040')
        elif kind == 'LOC':
            ann[key] = FloatProperty(name=_zh_native(label, 'MWK:ui/channel_box.py:1042'), get=_proxy_get(key), set=_proxy_set(key), subtype='DISTANCE', unit='LENGTH', precision=3, step=10, translation_context='MWK:ui/channel_box.py:1042')
        elif kind == 'ROT':
            ann[key] = FloatProperty(name=_zh_native(label, 'MWK:ui/channel_box.py:1045'), get=_proxy_get(key), set=_proxy_set(key), subtype='ANGLE', unit='ROTATION', precision=3, translation_context='MWK:ui/channel_box.py:1045')
        else:
            ann[key] = FloatProperty(name=_zh_native(label, 'MWK:ui/channel_box.py:1048'), get=_proxy_get(key), set=_proxy_set(key), precision=3, step=10, translation_context='MWK:ui/channel_box.py:1048')
        ann[key + '_text'] = StringProperty(name=_zh_native(label, 'MWK:ui/channel_box.py:1050'), get=_text_get(key), set=_text_set(key), translation_context='MWK:ui/channel_box.py:1050')
        ann[key + '_sel'] = BoolProperty(name=_zh_native(label, 'MWK:ui/channel_box.py:1051'), get=_sel_get(key), set=_sel_set(key), description=_zh_native('Select this channel: click, Ctrl toggle, Shift range, drag over the rows', 'MWK:ui/channel_box.py:1051'), translation_context='MWK:ui/channel_box.py:1051')
    ann['rows'] = CollectionProperty(type=ALLSET_PG_cb_row, translation_context='MWK:ui/channel_box.py:1054')
    ann['rows_sig'] = StringProperty(options={'HIDDEN'}, translation_context='MWK:ui/channel_box.py:1055')
    return ann
ALLSET_PG_channel_box = type('ALLSET_PG_channel_box', (bpy.types.PropertyGroup,), {'__annotations__': _make_proxy_annotations()})

def slider_delta(dx, kind, speed=1.0, ctrl=False, shift=False, hyperbolic=False):
    d = float(dx)
    if hyperbolic:
        d = d * abs(d) / 50.0
    factor = speed * (0.1 if ctrl else 1.0) * (10.0 if shift else 1.0)
    return d * SLIDER_STEP[kind] * factor

def slider_targets(context):
    """[(object, key)] the slider would change: selected numeric channels on targets."""
    out = []
    for key in selected_channels(context):
        if key in MAIN_BY_KEY and MAIN_BY_KEY[key][4] == 'VIS':
            continue
        for ob in targets(context):
            if has_channel(ob, key) and (not is_locked(ob, key)) and (not is_hidden(ob, key)):
                if key.startswith(CUSTOM_PREFIX) and isinstance(get_value(ob, key), bool):
                    continue
                out.append((ob, key))
    return out

def slider_apply(starts, dx, speed=1.0, ctrl=False, shift=False, hyperbolic=False):
    """starts: {(ob, key): start value}. Sets each to start + delta."""
    for ((ob, key), start) in starts.items():
        kind = channel_path(key)[2]
        set_value(ob, key, start + slider_delta(dx, kind, speed, ctrl, shift, hyperbolic))

class ALLSET_OT_cb_virtual_slider(bpy.types.Operator):
    """MMB-drag in the viewport changes the channels selected in the Channel Box"""
    bl_translation_context = 'MWK:ui/channel_box.py:1097'
    bl_idname = 'allset.cb_virtual_slider'
    bl_label = _zh_native('Channel Box Virtual Slider', 'MWK:ui/channel_box.py:1097')
    bl_description = _zh_native('MMB-drag in the viewport changes the channels selected in the Channel Box', 'MWK:ui/channel_box.py:1097')
    bl_options = {'REGISTER', 'UNDO', 'GRAB_CURSOR_X', 'BLOCKING'}

    def invoke(self, context, event):
        if context.mode not in {'OBJECT', 'POSE'}:
            return {'PASS_THROUGH'}
        pairs = slider_targets(context)
        if not pairs:
            return {'PASS_THROUGH'}
        self._starts = {(ob, key): get_value(ob, key) for (ob, key) in pairs}
        self._dx = 0
        self._last_x = event.mouse_x
        from .. import preferences
        prefs = preferences.get(context)
        self._speed = SPEED_FACTOR[prefs.cb_speed]
        self._hyper = prefs.cb_hyperbolic
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _header(self, context, text):
        if context.area:
            context.area.header_text_set(_zh(text, 'MWK:ui/channel_box.py:1118'))

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            step = event.mouse_x - self._last_x
            self._last_x = event.mouse_x
            if context.region and abs(step) > context.region.width // 2:
                step = 0
            self._dx += step
            slider_apply(self._starts, self._dx, self._speed, event.ctrl, event.shift, self._hyper)
            (ob, key) = next(iter(self._starts))
            self._header(context, f'{channel_label(key)}: {get_value(ob, key):.3f}  (Ctrl slower, Shift faster, Esc cancel)')
            return {'RUNNING_MODAL'}
        if event.type == 'MIDDLEMOUSE' and event.value == 'RELEASE':
            self._header(context, None)
            return {'FINISHED'}
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            for ((ob, key), start) in self._starts.items():
                set_value(ob, key, start)
            self._header(context, None)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

class ALLSET_OT_cb_select_channel(bpy.types.Operator):
    """Select this channel (Ctrl: toggle, Shift: add). Selected channels follow MMB-drag in the viewport"""
    bl_translation_context = 'MWK:ui/channel_box.py:1148'
    bl_idname = 'allset.cb_select_channel'
    bl_label = _zh_native('Select Channel', 'MWK:ui/channel_box.py:1148')
    bl_description = _zh_native('Select this channel (Ctrl: toggle, Shift: add). Selected channels follow MMB-drag in the viewport', 'MWK:ui/channel_box.py:1148')
    bl_options = {'INTERNAL'}
    key: StringProperty(translation_context='MWK:ui/channel_box.py:1151')
    mode: EnumProperty(items=_zh_enum((('SET', 'Set', ''), ('TOGGLE', 'Toggle', ''), ('EXTEND', 'Extend', '')), 'MWK:ui/channel_box.py:1152'), translation_context='MWK:ui/channel_box.py:1152')

    def invoke(self, context, event):
        self.mode = 'TOGGLE' if event.ctrl else 'EXTEND' if event.shift else 'SET'
        return self.execute(context)

    def execute(self, context):
        select_channel(self.key, self.mode, context)
        for area in context.screen.areas if context.screen else ():
            area.tag_redraw()
        return {'FINISHED'}

class ALLSET_OT_cb_deselect_channels(bpy.types.Operator):
    """Clear the Channel Box channel selection"""
    bl_translation_context = 'MWK:ui/channel_box.py:1168'
    bl_idname = 'allset.cb_deselect_channels'
    bl_label = _zh_native('Deselect Channels', 'MWK:ui/channel_box.py:1168')
    bl_description = _zh_native('Clear the Channel Box channel selection', 'MWK:ui/channel_box.py:1168')
    bl_options = {'INTERNAL'}

    def execute(self, context):
        set_selected_channels([], context)
        return {'FINISHED'}
_hover = {}
_watching = set()
_anchor = {'key': None}

def _round_half_up(x):
    """C roundf for UI sizes (UI_UNIT_Y = roundf(18 x scale) + 2 x pixel size): Python's round(22.5) is 22, Blender's 23,
    so at UI 1.25 the unit was 24 px instead of 25 and every 0.8 U row 0.8 px short (step 148, #83)."""
    return int(x + 0.5)

def row_pitch(context):
    """Channel row height in px (ROW_SCALE x Blender's widget unit)."""
    system = context.preferences.system
    unit = _round_half_up(18.0 * system.ui_scale) + 2 * system.pixel_size
    return max(1.0, unit * ROW_SCALE)

def _redraw(window):
    for area in window.screen.areas if window is not None and window.screen else ():
        area.tag_redraw()

def _hovered_cell(context):
    prop = getattr(context, 'property', None)
    if not prop or not isinstance(prop[0], bpy.types.Scene):
        return None
    return cell_key(prop[1], prop[0])

class ALLSET_OT_cb_hover(bpy.types.Operator):
    """Channel Box: remember the channel under the mouse and watch for a drag over the rows"""
    bl_translation_context = 'MWK:ui/channel_box.py:1215'
    bl_idname = 'allset.cb_hover'
    bl_label = _zh_native('Channel Box Hover', 'MWK:ui/channel_box.py:1215')
    bl_description = _zh_native('Channel Box: remember the channel under the mouse and watch for a drag over the rows', 'MWK:ui/channel_box.py:1215')
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        window = context.window
        if window is None:
            return {'PASS_THROUGH'}
        hit = _hovered_cell(context)
        _hover[window.as_pointer()] = hit
        if (hit is not None or in_channel_part(context, event)) and window.as_pointer() not in _watching and (context.region is not None):
            bpy.ops.allset.cb_channel_drag('INVOKE_DEFAULT')
        return {'PASS_THROUGH'}

class ALLSET_OT_cb_channel_drag(bpy.types.Operator):
    """Maya Channel Box selection: click a channel name or field, drag over the rows to select a range
    (Ctrl toggles / adds, Shift selects from the last clicked channel)"""
    bl_translation_context = 'MWK:ui/channel_box.py:1235'
    bl_idname = 'allset.cb_channel_drag'
    bl_label = _zh_native('Select Channels', 'MWK:ui/channel_box.py:1235')
    bl_description = _zh_native('Maya Channel Box selection: click a channel name or field, drag over the rows to select a range\n(Ctrl toggles / adds, Shift selects from the last clicked channel)', 'MWK:ui/channel_box.py:1235')
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        region = context.region
        if region is None or context.window is None:
            return {'CANCELLED'}
        self._win = context.window.as_pointer()
        self._window = context.window
        self._rect = (region.x, region.y, region.x + region.width, region.y + region.height)
        self._pitch = row_pitch(context)
        self._press = None
        self._cb_bottom = None
        if _is_cb_dock(context):
            self._cb_bottom = region.y + region.height - cb_share(region, _unit(context)) * region.height
        _watching.add(self._win)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _inside(self, event):
        (x0, y0, x1, y1) = self._rect
        return x0 <= event.mouse_x < x1 and y0 <= event.mouse_y < y1

    def _finish(self, cancel=False):
        _watching.discard(self._win)
        return {'CANCELLED' if cancel else 'FINISHED', 'PASS_THROUGH'}

    def modal(self, context, event):
        try:
            self._window.screen
        except ReferenceError:
            _watching.discard(self._win)
            return {'CANCELLED', 'PASS_THROUGH'}
        if self._press is None:
            if event.type == 'MOUSEMOVE' and (not self._inside(event)):
                return self._finish()
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and self._inside(event):
                hit = _hover.get(self._win)
                if hit is not None:
                    return self._on_press(context, event, hit)
            if event.type == 'RIGHTMOUSE' and event.value == 'PRESS' and self._inside(event):
                hit = _hover.get(self._win)
                in_part = hit is not None or (self._cb_bottom is not None and event.mouse_y >= self._cb_bottom)
                if in_part and (not (event.shift or event.alt)):
                    return self._on_rmb(context, hit, edit=event.ctrl)
            return {'PASS_THROUGH'}
        if event.type == 'MOUSEMOVE':
            self._on_move(context, event)
            return {'PASS_THROUGH'}
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            return self._on_release(context, event)
        if event.type == 'ESC' and event.value == 'PRESS':
            set_selected_channels(self._base)
            self._press = None
            _redraw(self._window)
            return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}

    def _on_rmb(self, context, hit, edit=False):
        """Maya: RMB in the Channel Box = the Channels menu. Blender's button
        context menu draws its C items first and a Python menu only after them (step 148, #87: the Channels items
        sat under 15 Blender rows), so the press is taken here, before the region's button handler. A channel
        that isn't selected becomes the selection first (delegated), so Key Selected keys the clicked channel."""
        if edit:
            bpy.ops.wm.call_menu(name=ALLSET_MT_cb_edit.__name__)
            return {'RUNNING_MODAL'}
        if hit is not None:
            (key, _part) = hit
            if key not in selected_channels(context):
                set_selected_channels([key], context)
                _anchor['key'] = key
                _redraw(self._window)
        bpy.ops.wm.call_menu(name=ALLSET_MT_cb_channels.__name__)
        return {'RUNNING_MODAL'}

    def _on_press(self, context, event, hit):
        ob = lead(context)
        if ob is None:
            return {'PASS_THROUGH'}
        (key, part) = hit
        self._ob = ob
        self._y0 = event.mouse_y
        self._dragging = False
        self._ctrl = event.ctrl
        self._base = selected_channels(context)
        self._anchor = key
        self._part = part
        self._key = key
        if event.shift and _anchor['key'] is not None:
            select_range(ob, _anchor['key'], key, 'SET', context=context)
            self._anchor = _anchor['key']
        elif event.ctrl:
            select_channel(key, 'TOGGLE', context)
            _anchor['key'] = key
        elif not (part == 'VALUE' and key in self._base and (len(self._base) > 1)):
            set_selected_channels([key], context)
            _anchor['key'] = key
        self._press = part
        _redraw(self._window)
        return {'RUNNING_MODAL'}

    def _key_at_offset(self, event):
        keys = drawn_keys(self._ob)
        if self._anchor not in keys:
            return None
        rows = round((self._y0 - event.mouse_y) / self._pitch)
        i = max(0, min(len(keys) - 1, keys.index(self._anchor) + rows))
        return keys[i]

    def _current(self, event):
        hit = _hover.get(self._win)
        return hit[0] if hit is not None else self._key_at_offset(event)

    def _extend(self, context, cur):
        if cur is None or (cur == self._anchor and (not self._dragging)):
            return
        self._dragging = True
        base = self._base if self._ctrl else None
        select_range(self._ob, self._anchor, cur, 'ADD' if self._ctrl else 'SET', base=base, context=context)
        _redraw(self._window)

    def _on_move(self, context, event):
        if not self._dragging and abs(event.mouse_y - self._y0) < 0.5 * self._pitch:
            return
        self._extend(context, self._current(event))

    def _on_release(self, context, event):
        (part, self._press) = (self._press, None)
        if self._dragging:
            self._extend(context, self._current(event))
        elif part == 'VALUE' and (not (event.ctrl or event.shift)):
            try:
                edit_field(context, self._key)
            except RuntimeError:
                pass
        _redraw(self._window)
        return {'RUNNING_MODAL'}

def field_owner(context, key):
    """(owner, property) of the Channel Box text field of channel ``key``."""
    cb = context.scene.allset_cb
    if key in MAIN_BY_KEY:
        return (cb, key + '_text')
    if key.startswith(CUSTOM_PREFIX):
        name = key[len(CUSTOM_PREFIX):]
        for r in cb.rows:
            if r.kind == 'CUSTOM' and r.name == name:
                return (r, 'text')
    return (None, None)
_edit = {'key': None}

def edit_field(context, key):
    """Edit channel ``key``'s field in a popover at the mouse with the text active at once (Maya: a click into a
    field edits it); Enter writes the text into every selected channel (apply_entry) and closes it, like F2."""
    if field_owner(context, key)[0] is None:
        return False
    _edit['key'] = key
    bpy.ops.wm.call_panel(name=ALLSET_PT_cb_field.__name__, keep_open=False)
    return True

class ALLSET_PT_cb_field(bpy.types.Panel):
    """The Channel Box field editor popover (called by edit_field only)"""
    bl_translation_context = 'MWK:ui/channel_box.py:1409'
    bl_space_type = 'TOPBAR'
    bl_region_type = 'HEADER'
    bl_label = _zh_native('Channel Value', 'MWK:ui/channel_box.py:1409')
    bl_ui_units_x = 6

    def draw(self, context):
        (owner, prop) = field_owner(context, _edit['key'] or '')
        if owner is None:
            return
        row = self.layout.row()
        row.activate_init = True
        row.prop(owner, prop, text=_dcc_display(''))

def _visible_channels(ob):
    keys = [c[0] for c in MAIN if has_channel(ob, c[0])] + [CUSTOM_PREFIX + k for k in custom_keys(ob)]
    return [k for k in keys if not is_hidden(ob, k)]

class _ChannelAction:
    """Base: acts on selected channels of all target objects."""
    bl_options = {'REGISTER', 'UNDO'}
    use_all = False

    @classmethod
    def poll(cls, context):
        return lead(context) is not None

    def channel_keys(self, context, ob):
        sel = selected_channels(context)
        if not sel and self.use_all:
            return _visible_channels(ob)
        return [k for k in sel if has_channel(ob, k)]

    def execute(self, context):
        count = 0
        for ob in targets(context):
            for key in self.channel_keys(context, ob):
                count += bool(self.act(context, ob, key))
        results.result(self, _zh(f'{self.bl_label}: {count} channel(s)', 'MWK:ui/channel_box.py:1447'))
        return {'FINISHED'}

def _op(idname, label, doc, act, use_all=False, **props):
    cls = type(f'ALLSET_OT_{idname}', (_ChannelAction, bpy.types.Operator), {'bl_description': _zh_native(doc, 'MWK:ui/channel_box.py:1452'), 'bl_translation_context': 'MWK:ui/channel_box.py:1452', 'bl_idname': f'allset.{idname}', 'bl_label': _zh_native(label, 'MWK:ui/channel_box.py:1452'), '__doc__': doc, 'act': act, 'use_all': use_all, '__annotations__': props})
    return cls

def _act_key(self, context, ob, key):
    return is_keyable(ob, key) and keyframe(ob, key)

def _act_breakdown(self, context, ob, key):
    return is_keyable(ob, key) and keyframe(ob, key, 'BREAKDOWN')

def _act_mute(self, context, ob, key):
    curves = channel_fcurves(ob, key)
    for fc in curves:
        fc.mute = self.mute
    return bool(curves)

def _act_delete(self, context, ob, key):
    return remove_channel_curves(ob, key)

def _act_break(self, context, ob, key):
    done = _act_delete(self, context, ob, key)
    dr = driver(ob, key)
    if dr is not None:
        ob.id_data.animation_data.drivers.remove(dr)
        done = True
    return done

def _act_lock(self, context, ob, key):
    return set_locked(ob, key, self.lock)

def _act_hide(self, context, ob, key):
    if self.lock:
        set_locked(ob, key, True)
    _set_flag_list(ob, HIDDEN_PROP, _flag_list(ob, HIDDEN_PROP) + [key])
    return True

def _act_keyable(self, context, ob, key):
    keys = [k for k in _flag_list(ob, NONKEYABLE_PROP) if k != key]
    if not self.keyable:
        keys.append(key)
    _set_flag_list(ob, NONKEYABLE_PROP, keys)
    return True

def _act_duplicate(self, context, ob, key):
    ld = lead(context)
    if ob == ld or not has_channel(ld, key) or is_locked(ob, key):
        return False
    set_value(ob, key, get_value(ld, key))
    return True
CHANNEL_OPS = (_op('cb_key_selected', _dcc_source('Key Selected'), _dcc_source('Set a key on the selected channels'), _act_key), _op('cb_key_all', _dcc_source('Key All Keyable'), _dcc_source('Set a key on every keyable channel'), _act_key, use_all=True), _op('cb_breakdown_selected', _dcc_source('Breakdown Selected'), _dcc_source('Set a breakdown key on the selected channels'), _act_breakdown), _op('cb_mute', _dcc_source('Mute Selected'), _dcc_source('Mute or unmute the animation of the selected channels'), _act_mute, mute=BoolProperty(default=True, translation_context='MWK:ui/channel_box.py:1519')), _op('cb_delete_keys', _dcc_source('Delete Selected'), _dcc_source('Delete the animation curves of the selected channels'), _act_delete), _op('cb_break_connections', _dcc_source('Break Connections'), _dcc_source('Remove the animation curve or driver feeding the selected channels'), _act_break), _op('cb_lock', _dcc_source('Lock Selected'), _dcc_source('Lock or unlock the selected channels'), _act_lock, lock=BoolProperty(default=True, translation_context='MWK:ui/channel_box.py:1525')), _op('cb_hide', _dcc_source('Hide Selected'), _dcc_source('Hide the selected channels from the Channel Box'), _act_hide, lock=BoolProperty(default=False, translation_context='MWK:ui/channel_box.py:1527')), _op('cb_keyable', _dcc_source('Make Selected Keyable'), _dcc_source('Make the selected channels keyable or nonkeyable'), _act_keyable, keyable=BoolProperty(default=True, translation_context='MWK:ui/channel_box.py:1529')), _op('cb_duplicate_values', _dcc_source('Duplicate Values'), _dcc_source("Copy the lead object's values of the selected channels to the other selected objects"), _act_duplicate))

class ALLSET_OT_cb_show_all(bpy.types.Operator):
    """Show every hidden channel again"""
    bl_translation_context = 'MWK:ui/channel_box.py:1539'
    bl_idname = 'allset.cb_show_all'
    bl_label = _zh_native('Show All Channels', 'MWK:ui/channel_box.py:1539')
    bl_description = _zh_native('Show every hidden channel again', 'MWK:ui/channel_box.py:1539')
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for ob in targets(context):
            _set_flag_list(ob, HIDDEN_PROP, [])
        return {'FINISHED'}

class ALLSET_MT_cb_channels(bpy.types.Menu):
    """Maya Channel Box Channels menu (RMB anywhere in the Channel Box;
    step 158 completes it)"""
    bl_translation_context = 'MWK:ui/channel_box.py:1553'
    bl_label = _zh_native('Channels', 'MWK:ui/channel_box.py:1553')

    def draw(self, context):
        from .. import preferences
        from . import cb_channels, menu_sets
        lay = self.layout
        lay.operator('allset.cb_key_selected')
        lay.operator('allset.cb_key_all')
        lay.operator('allset.cb_breakdown_selected')
        lay.operator('allset.cb_breakdown_all')
        lay.operator('allset.cb_mute', text=_zh('Mute Selected', 'MWK:ui/channel_box.py:1563')).mute = True
        lay.operator('allset.cb_mute_all', text=_zh('Mute All', 'MWK:ui/channel_box.py:1564')).mute = True
        lay.operator('allset.cb_mute', text=_zh('Unmute Selected', 'MWK:ui/channel_box.py:1565')).mute = False
        lay.operator('allset.cb_mute_all', text=_zh('Unmute All', 'MWK:ui/channel_box.py:1566')).mute = False
        lay.separator()
        prefs = preferences.get(context)
        lay.prop(prefs, 'cb_sync_graph', text=_zh('Sync Selection in Graph Editor', 'MWK:ui/channel_box.py:1569'))
        lay.prop(prefs, 'cb_sync_timeline', text=_zh('Sync Timeline Display', 'MWK:ui/channel_box.py:1570'))
        lay.separator()
        lay.operator('allset.cb_clipboard', text=_zh('Cut Selected', 'MWK:ui/channel_box.py:1572')).action = 'CUT'
        lay.operator('allset.cb_clipboard', text=_zh('Copy Selected', 'MWK:ui/channel_box.py:1573')).action = 'COPY'
        lay.operator('allset.cb_clipboard', text=_zh('Paste Selected', 'MWK:ui/channel_box.py:1574')).action = 'PASTE'
        lay.operator('allset.cb_delete_keys')
        lay.separator()
        lay.operator('allset.cb_duplicate_values')
        lay.menu(ALLSET_MT_cb_freeze.__name__)
        lay.separator()
        lay.operator('allset.cb_break_connections')
        lay.operator('allset.cb_select_connection')
        lay.separator()
        lay.operator('allset.cb_lock', text=_zh('Lock Selected', 'MWK:ui/channel_box.py:1583')).lock = True
        lay.operator('allset.cb_lock', text=_zh('Unlock Selected', 'MWK:ui/channel_box.py:1584')).lock = False
        lay.operator('allset.cb_hide', text=_zh('Hide Selected', 'MWK:ui/channel_box.py:1585')).lock = False
        lay.operator('allset.cb_hide', text=_zh('Lock and Hide Selected', 'MWK:ui/channel_box.py:1586')).lock = True
        lay.operator('allset.cb_show_all')
        lay.operator('allset.cb_keyable', text=_zh('Make Selected Nonkeyable', 'MWK:ui/channel_box.py:1588')).keyable = False
        lay.operator('allset.cb_keyable', text=_zh('Make Selected Keyable', 'MWK:ui/channel_box.py:1589')).keyable = True
        lay.separator()
        lay.operator('allset.anim_layer_attrs', text=_zh('Add to Selected Layers', 'MWK:ui/channel_box.py:1592')).add = True
        lay.operator('allset.anim_layer_attrs', text=_zh('Remove From Selected Layers', 'MWK:ui/channel_box.py:1593')).add = False
        lay.separator()
        lay.operator('allset.cb_deselect_channels')

class ALLSET_MT_cb_freeze(bpy.types.Menu):
    """Maya Channels > Freeze (makeIdentity -apply on the chosen channels)"""
    bl_translation_context = 'MWK:ui/channel_box.py:1600'
    bl_label = _zh_native('Freeze', 'MWK:ui/channel_box.py:1600')

    def draw(self, context):
        lay = self.layout
        for (text, t, r, sc) in ((_dcc_source('Translate'), True, False, False), (_dcc_source('Rotate'), False, True, False), (_dcc_source('Scale'), False, False, True), (_dcc_source('All'), True, True, True)):
            op = lay.operator('allset.freeze_transform', text=_zh(text, 'MWK:ui/channel_box.py:1606'))
            (op.translate, op.rotate, op.scale) = (t, r, sc)

def is_cb_button(context):
    """The button under the mouse is a Channel Box channel name or value (for its RMB menu)."""
    op = getattr(context, 'button_operator', None)
    if op is not None and op.bl_rna.identifier == ALLSET_OT_cb_select_channel.__name__:
        return True
    ptr = getattr(context, 'button_pointer', None)
    return isinstance(ptr, (ALLSET_PG_channel_box, ALLSET_PG_cb_row))
RMB_ITEMS = (('allset.cb_key_selected', _dcc_source('Key Selected'), {}), ('allset.cb_breakdown_selected', _dcc_source('Breakdown Selected'), {}), ('allset.cb_mute', _dcc_source('Mute Selected'), {'mute': True}), ('allset.cb_mute', _dcc_source('Unmute Selected'), {'mute': False}), ('allset.cb_delete_keys', _dcc_source('Delete Selected'), {}), ('allset.cb_break_connections', _dcc_source('Break Connections'), {}), ('allset.cb_lock', _dcc_source('Lock Selected'), {'lock': True}), ('allset.cb_lock', _dcc_source('Unlock Selected'), {'lock': False}), ('allset.cb_hide', _dcc_source('Hide Selected'), {'lock': False}), ('allset.cb_keyable', _dcc_source('Make Selected Nonkeyable'), {'keyable': False}))

def draw_button_menu(self, context):
    if not is_cb_button(context):
        return
    lay = self.layout
    for (idname, text, props) in RMB_ITEMS:
        op = lay.operator(idname, text=_zh(text, 'MWK:ui/channel_box.py:1638'))
        for (k, v) in props.items():
            setattr(op, k, v)
    lay.separator()

class ALLSET_MT_cb_settings(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/channel_box.py:1645'
    bl_label = _zh_native('Settings', 'MWK:ui/channel_box.py:1645')

    def draw(self, context):
        from .. import preferences
        prefs = preferences.get(context)
        lay = self.layout
        lay.label(text=_zh('Virtual slider speed', 'MWK:ui/channel_box.py:1651'))
        lay.prop(prefs, 'cb_speed', expand=True)
        lay.prop(prefs, 'cb_hyperbolic')

class ALLSET_MT_cb_edit(bpy.types.Menu):
    """Maya Channel Box Edit menu"""
    bl_translation_context = 'MWK:ui/channel_box.py:1658'
    bl_label = _zh_native('Edit', 'MWK:ui/channel_box.py:1658')

    def draw(self, context):
        lay = self.layout
        chrome.grey(lay, _dcc_source('Expressions...'))
        lay.operator('allset.sdk_window', text=_zh('Set Driven Key...', 'MWK:ui/channel_box.py:1663'))
        lay.operator('allset.open_editor', text=_zh('Graph Editor', 'MWK:ui/channel_box.py:1664')).ui_type = 'FCURVES'
        chrome.grey(lay, _dcc_source('Channel Control...'))
        chrome.grey(lay, _dcc_source('Connection Editor'))
        lay.operator('allset.dock_show', text=_zh('Attribute Editor', 'MWK:ui/channel_box.py:1667')).dock = 'ATTRIBUTE_EDITOR'
        lay.operator('allset.material_attributes', text=_zh('Material Attributes...', 'MWK:ui/channel_box.py:1668'))
        lay.separator()
        lay.operator('allset.add_attribute', text=_zh('Add Attribute...', 'MWK:ui/channel_box.py:1670'))
        lay.operator('allset.edit_attribute', text=_zh('Edit Attribute...', 'MWK:ui/channel_box.py:1671'))
        chrome.grey(lay, _dcc_source('Duplicate Attribute'))
        lay.operator('allset.delete_attribute', text=_zh('Delete Attributes', 'MWK:ui/channel_box.py:1673'))
        lay.separator()
        lay.operator(ALLSET_OT_cb_make_lead.bl_idname, text=_zh('Select Node', 'MWK:ui/channel_box.py:1675')).only = True
        lay.operator('allset.delete', text=_zh('Delete Node', 'MWK:ui/channel_box.py:1676'))
        lay.operator('allset.delete_history', text=_zh('Delete History', 'MWK:ui/channel_box.py:1677'))
        lay.separator()
        lay.menu('ALLSET_MT_cb_settings', text=_zh('Settings', 'MWK:ui/channel_box.py:1679'))
        chrome.grey(lay, _dcc_source('Channel Names'))

class ALLSET_OT_cb_make_lead(bpy.types.Operator):
    """Make this object the lead (Maya Channel Box Object menu: select -add)"""
    bl_translation_context = 'MWK:ui/channel_box.py:1686'
    bl_idname = 'allset.cb_make_lead'
    bl_label = _zh_native('Lead Object', 'MWK:ui/channel_box.py:1686')
    bl_description = _zh_native('Make this object the lead (Maya Channel Box Object menu: select -add)', 'MWK:ui/channel_box.py:1686')
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}
    name: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/channel_box.py:1689')
    only: BoolProperty(name=_zh_native('Only', 'MWK:ui/channel_box.py:1690'), description=_zh_native('Select only this object', 'MWK:ui/channel_box.py:1690'), options={'SKIP_SAVE'}, translation_context='MWK:ui/channel_box.py:1690')

    def execute(self, context):
        if pose_armature(context):
            return self._bone(context)
        ob = context.scene.objects.get(self.name) if self.name else context.active_object
        if ob is None:
            return {'CANCELLED'}
        if self.only:
            for other in context.selected_objects:
                other.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        return {'FINISHED'}

    def _bone(self, context):
        bones = [pb for arm in pose_objects(context) for pb in arm.pose.bones]
        pb = next((b for b in bones if b.name == self.name), None) if self.name else lead(context)
        if pb is None:
            return {'CANCELLED'}
        if self.only:
            for other in bones:
                set_bone_selected(other, False)
        set_bone_selected(pb, True)
        pb.id_data.data.bones.active = pb.bone
        return {'FINISHED'}

class ALLSET_OT_cb_rotate_order(bpy.types.Operator):
    """Set the rotate order (Blender converts the rotation, the pose stays): Maya channels need Euler"""
    bl_translation_context = 'MWK:ui/channel_box.py:1721'
    bl_idname = 'allset.cb_rotate_order'
    bl_label = _zh_native('Rotate Order', 'MWK:ui/channel_box.py:1721')
    bl_description = _zh_native('Set the rotate order (Blender converts the rotation, the pose stays): Maya channels need Euler', 'MWK:ui/channel_box.py:1721')
    bl_options = {'REGISTER', 'UNDO'}
    order: EnumProperty(name=_zh_native('Rotate Order', 'MWK:ui/channel_box.py:1724'), items=_zh_enum([(m, m, '') for m in ('XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX')], 'MWK:ui/channel_box.py:1724'), translation_context='MWK:ui/channel_box.py:1724')

    @classmethod
    def poll(cls, context):
        return lead(context) is not None

    def execute(self, context):
        for node in targets(context):
            node.rotation_mode = self.order
        return {'FINISHED'}

class ALLSET_MT_cb_object(bpy.types.Menu):
    """Maya Channel Box Object menu: the selected objects (joints in pose mode), picking one makes it
    the lead"""
    bl_translation_context = 'MWK:ui/channel_box.py:1740'
    bl_label = _zh_native('Object', 'MWK:ui/channel_box.py:1740')

    def draw(self, context):
        lay = self.layout
        obs = targets(context)
        if not obs:
            chrome.grey(lay, _dcc_source('Nothing selected'))
        ld = lead(context)
        for ob in obs[:10]:
            lay.operator(ALLSET_OT_cb_make_lead.bl_idname, text=_dcc_display(ob.name), icon='LAYER_ACTIVE' if ob == ld else 'BLANK1').name = ob.name

class ALLSET_MT_cb_show(bpy.types.Menu):
    """Maya Channel Box Show menu"""
    bl_translation_context = 'MWK:ui/channel_box.py:1755'
    bl_label = _zh_native('Show', 'MWK:ui/channel_box.py:1755')

    def draw(self, context):
        lay = self.layout
        lay.operator('allset.cb_show_all', text=_zh('All', 'MWK:ui/channel_box.py:1759'))
        lay.separator()
        for label in (_dcc_source('Assets'), _dcc_source('Attribute Type Filters')):
            chrome.grey(lay, label)
MENU_BAR = ((_dcc_source('Channels'), 'ALLSET_MT_cb_channels'), (_dcc_source('Edit'), 'ALLSET_MT_cb_edit'), (_dcc_source('Object'), 'ALLSET_MT_cb_object'), (_dcc_source('Show'), 'ALLSET_MT_cb_show'))
EMPTY_TEXT = (_dcc_source('Select objects in the scene to view,'), 'edit and set keyframes on channels', '(attributes)')
PLACING_TEXT = (_dcc_source('Editing joints: W / E / R move them,'), _dcc_source('F8 = pose mode (channels and keys)'))
POSE_HINT = _dcc_source('Ctrl+Tab: joint channels')

def draw_joint_translate(layout, context):
    """Edit-mode joints (step 243): the lead joint's name + Translate X / Y / Z text fields (``+=`` entry, display
    units; typing moves the joint, its children follow unless Preserve Children, every Maya frame stays —
    operators/joint_edit.py). Returns the UI units drawn."""
    from ..operators import joint_edit
    (_ob, eb) = joint_edit.lead_joint(context)
    if eb is None:
        return 0
    layout.label(text=_dcc_display(eb.name))
    for a in joint_edit.AXES:
        row = layout.row(align=True)
        split = row.split(factor=0.5, align=True)
        split.label(text=_zh(f'Translate {a.upper()}', 'MWK:ui/channel_box.py:1791'))
        split.prop(context.scene, f'allset_joint_t{a}', text=_dcc_display(''))
        row.label(text=_dcc_display(''), icon='BLANK1')
    return 1 + len(joint_edit.AXES)

def draw_empty(layout):
    layout.separator(factor=6)
    chrome.wrapped(layout, EMPTY_TEXT)
    layout.separator(factor=6)
_STATE_ICON = {'KEYED': 'DECORATE_KEYFRAME', 'ANIMATED': 'DECORATE_ANIMATE', 'DRIVEN': 'DECORATE_DRIVER', 'MUTED': 'MUTE_IPO_ON', 'LAYERED': 'NLA'}
_ALERT_STATES = {'KEYED', 'ANIMATED', 'DRIVEN', 'MUTED'}

def _row_label(row, key, selected, sel_owner=None, sel_prop=None):
    sub = row.row(align=True)
    if sel_owner is not None:
        sub.prop(sel_owner, sel_prop, text=_zh(channel_label(key), 'MWK:ui/channel_box.py:1816'), toggle=True, emboss=selected)
        return
    op = sub.operator('allset.cb_select_channel', text=_zh(channel_label(key), 'MWK:ui/channel_box.py:1818'), depress=selected, emboss=selected)
    op.key = key
ROW_SCALE = 0.8

def draw_channel_row(layout, ob, key, value_owner, value_prop, selected, constrained=False, sel_owner=None, sel_prop=None):
    row = layout.row(align=True)
    split = row.split(factor=0.5, align=True)
    _row_label(split, key, selected, sel_owner, sel_prop)
    right = split.row(align=True)
    state = channel_state(ob, key)
    right.enabled = not is_locked(ob, key)
    if constrained:
        text = cb_entry.format_value(get_value(ob, key), entry_kind(ob, key), bpy.context.scene)
        right.operator('allset.cb_select_channel', text=_zh(text, 'MWK:ui/channel_box.py:1837'), depress=True).key = key
        row.label(text=_dcc_display(''), icon='CONSTRAINT')
        return row
    right.alert = state in _ALERT_STATES
    right.prop(value_owner, value_prop, text=_dcc_display(''))
    row.label(text=_dcc_display(''), icon=_STATE_ICON.get(state, 'BLANK1'))
    return row

def _modifier_props(mod, limit=10):
    """Editable scalar properties of a modifier, Maya INPUTS-style; a kit Maya deformer shows
    its Maya attributes instead (``maya:<key>`` rows, operators/deformers.ATTRS, step 144)."""
    from ..operators import deformers
    maya = deformers.attrs(mod)
    if maya is not None:
        return [deformers.PREFIX + a.key for a in maya]
    skip = {'name', 'show_expanded', 'show_on_cage', 'show_in_editmode', 'show_render', 'use_apply_on_spline', 'use_pin_to_last', 'is_override_data_editable', 'persistent_uid', 'execution_time', 'show_viewport'}
    out = []
    for p in mod.bl_rna.properties:
        ident = p.identifier
        if ident in skip or p.is_readonly or ident.startswith(('show_', 'open_', 'is_')) or ident.endswith('_panel'):
            continue
        if p.type in {'INT', 'FLOAT', 'BOOLEAN'} and getattr(p, 'array_length', 0) == 0:
            out.append(p.identifier)
        if len(out) >= limit:
            break
    return out
SHAPE_PROPS = {'CAMERA': ('lens', 'clip_start', 'clip_end'), 'LIGHT': ('maya:colorR', 'maya:colorG', 'maya:colorB', 'allset_intensity', 'maya:coneAngle', 'maya:penumbraAngle'), 'LATTICE': ('points_u', 'points_w', 'points_v')}

def wanted_rows(ob):
    """(kind, name, mod_type, nth) for every text row of the lead object."""
    out = [('CUSTOM', name, '', 0) for name in custom_keys(ob)]
    data = getattr(ob, 'data', None)
    if data is not None:
        for prop in SHAPE_PROPS.get(ob.type, ()):
            rna = data.bl_rna.properties.get(prop)
            if rna is not None and cb_entry.kind_of_rna(rna) or _virtual(data, prop) is not None:
                out.append(('SHAPE', prop, '', 0))
    for mod in _inputs(ob):
        if is_open(ob, mod_node(mod)):
            for prop in _modifier_props(mod):
                out.append(('INPUT', prop, mod.type, _nth_of_type(ob, mod)))
    from ..operators import constrain_multi
    for con in constraints(ob):
        if not is_open(ob, con_node(ob, con)):
            continue
        mb = constrain_multi.member(con, ob)
        if mb is None:
            out.append(('CONSTRAINT', 'influence', con.type, _nth_constraint(ob, con)))
        elif constrain_multi.is_head(con, ob):
            out += [('CUSTOM', prop, '', 0) for (prop, _label) in constrain_multi.weights(ob, mb.group) if prop in ob.keys()]
    return out

def rows_signature(ob):
    if ob is None:
        return ''
    cons = [(c.name, c.type, weight_name(c)) for c in constraints(ob)]
    opened = sorted(open_nodes(ob))
    if is_bone(ob):
        return repr(('BONE', ob.id_data.name, ob.name, custom_keys(ob), cons, opened))
    mods = [(m.name, m.type) for m in _inputs(ob)]
    return repr((ob.name, ob.type, custom_keys(ob), mods, cons, opened))
_rows_state = {'busy': False}

def rebuild_rows(context=None):
    """Make ``Scene.allset_cb.rows`` match the lead object (only when it changed)."""
    context = context or bpy.context
    scene = getattr(context, 'scene', None)
    cb = getattr(scene, 'allset_cb', None) if scene is not None else None
    view_layer = getattr(context, 'view_layer', None)
    if cb is None or view_layer is None or _rows_state['busy']:
        return False
    ob = lead(context)
    sig = rows_signature(ob)
    if cb.rows_sig == sig:
        return False
    _rows_state['busy'] = True
    try:
        cb.rows.clear()
        if ob is not None:
            for (kind, name, mod_type, nth) in wanted_rows(ob):
                r = cb.rows.add()
                (r.kind, r.name, r.mod_type, r.nth) = (kind, name, mod_type, nth)
        cb.rows_sig = sig
    finally:
        _rows_state['busy'] = False
    return True

def row_for(context, ob, kind, name, mod_type='', nth=0):
    """The text row to draw, or None when the rows are stale (then draw the real property)."""
    cb = context.scene.allset_cb
    if cb.rows_sig != rows_signature(ob):
        return None
    for r in cb.rows:
        if r.kind == kind and r.name == name and (r.mod_type == mod_type) and (r.nth == nth):
            return r
    return None

@persistent
def _on_depsgraph(_scene, _depsgraph):
    rebuild_rows()
    from . import maya_dock
    maya_dock.redraw()

@persistent
def _on_load(_dummy):
    global _wheel_generation
    _wheel_generation += 1
    _wheel_windows.clear()
    _last.clear()
    reset_open()
    rebuild_rows()
_transform_snapshot = None

def _transforming():
    """A transform modal (manipulator drag, G / R / S) runs in some window."""
    wm = bpy.context.window_manager
    return wm is not None and any((op.bl_idname.startswith('TRANSFORM_OT_') for w in wm.windows for op in w.modal_operators))

def _poll_transform_values():
    """Refresh displayed transform channels even during modal gizmo movements."""
    global _transform_snapshot
    try:
        ob = lead()
        if ob is None:
            signature = None
        elif is_bone(ob):
            signature = (ob.id_data.as_pointer(), ob.name, tuple((v for row in ob.matrix for v in row)))
        else:
            signature = (ob.as_pointer(), tuple(ob.location), tuple(ob.rotation_euler), tuple(ob.rotation_quaternion), tuple(ob.rotation_axis_angle), tuple(ob.scale), ob.rotation_mode, ob.hide_viewport)
        if signature != _transform_snapshot or _transforming():
            _transform_snapshot = signature
            from . import maya_dock
            maya_dock.redraw()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return 0.1

def _first_rebuild():
    rebuild_rows()
    return None

def _draw_text_row(layout, context, ob, owner, prop, kind, mod_type='', nth=0, label=None):
    """A SHAPES / INPUTS row: label + text field applied to all selected (else the real prop)."""
    v = _virtual(owner, prop)
    if label is None:
        label = v.label if v is not None else owner.bl_rna.properties[prop].name
    row = row_for(context, ob, kind, prop, mod_type, nth)
    line = layout.row(align=True)
    split = line.split(factor=0.5, align=True)
    if kind == 'SHAPE' and row is not None:
        key = SHAPE_PREFIX + prop
        sub = split.row(align=True)
        sub.prop(row, 'sel', text=_zh(label, 'MWK:ui/channel_box.py:2030'), toggle=True, emboss=key in selected_channels(context))
        right = split.row(align=True)
        state = channel_state(ob, key)
        right.alert = state in _ALERT_STATES
        right.prop(row, 'text', text=_dcc_display(''))
        line.label(text=_dcc_display(''), icon=_STATE_ICON.get(state, 'BLANK1'))
        return
    name = split.row(align=True)
    name.alignment = 'CENTER'
    name.label(text=_zh(label, 'MWK:ui/channel_box.py:2039'))
    right = split.row(align=True)
    if row is None:
        if v is not None:
            right.label(text=_zh(cb_entry.format_value(v.get(owner), v.kind, context.scene), 'MWK:ui/channel_box.py:2043'))
        else:
            right.prop(owner, f'["{prop}"]' if kind == 'CUSTOM' else prop, text=_dcc_display(''))
    else:
        right.prop(row, 'text', text=_dcc_display(''))
    line.label(text=_dcc_display(''), icon='BLANK1')
_scroll = {}
_reveal = {'node': None}
_last = {}
WHEEL_LINES = 3
BUTTON_LINES = 3
_wheel_windows = {}
_wheel_generation = 0

class Lines:
    """An aligned column of equal rows that shows only rows ``first`` .. ``first + limit`` (``layout`` None: count)."""

    def __init__(self, layout, first=0, limit=None):
        self.layout = layout
        self.first = first
        self.limit = limit
        self.n = 0
        self.shown = 0
        self.marks = {}

    def row(self):
        i = self.n
        self.n += 1
        if self.layout is None or i < self.first or (self.limit is not None and self.shown >= self.limit):
            return None
        self.shown += 1
        return self.layout.row(align=True)

def reveal(node):
    """Scroll the Channel Box to INPUTS node ``node`` at its next draw."""
    _reveal['node'] = node

def as_lines(layout):
    return layout if isinstance(layout, Lines) else Lines(layout)

def window_lines(total, room, first):
    """(first, limit, overflow) for ``total`` lines in a pane of ``room`` lines. The scroll buttons sit on the lead's
    name line (step 135: on the last content line they took the place of the node that was just expanded)."""
    if room is None or total <= room:
        return (0, None, False)
    limit = max(1, room)
    return (max(0, min(first, total - limit)), limit, True)

def _unit(context):
    system = context.preferences.system
    return _round_half_up(18.0 * system.ui_scale) + 2 * system.pixel_size

def _split_off(context):
    sdk = getattr(context.window_manager, 'allset_sdk', None)
    return sdk is not None and sdk.open

def pane_room(context, units):
    """Lines that fit in the Channel Box part (CB_SHARE of the region) under ``units`` of fixed rows; None = no
    split (no region: headless drawing, or the Set Driven Key window)."""
    region = context.region
    if region is None or region.type not in {'UI', 'WINDOW'} or _split_off(context):
        return None
    u = _unit(context)
    if u <= 0 or region.height <= 0:
        return None
    room = (cb_share(region, u) * region.height / u - units - PANE_TOP - 0.3) / ROW_SCALE
    return max(2, int(room + 1e-06))

def node_row(lines, ob, node, label, tip='', active=True):
    """An INPUTS node name: Maya's indented, flat, click-to-expand row. Returns (row or None, expanded)."""
    opened = is_open(ob, node)
    if isinstance(lines, Lines):
        lines.marks[node] = lines.n
    row = lines.row()
    if row is not None:
        name = row.row(align=True)
        name.alignment = 'LEFT'
        name.active = active
        name.separator(factor=1.5)
        op = name.operator(ALLSET_OT_cb_node_toggle.bl_idname, text=_zh(label, 'MWK:ui/channel_box.py:2138'), emboss=False)
        op.node = node
        op.tip = tip
    return (row, opened)

class ALLSET_OT_cb_node_toggle(bpy.types.Operator):
    """Show or hide this node's attributes (Maya: click the node name in INPUTS)"""
    bl_translation_context = 'MWK:ui/channel_box.py:2147'
    bl_idname = 'allset.cb_node_toggle'
    bl_label = _zh_native('Expand Node', 'MWK:ui/channel_box.py:2147')
    bl_description = _zh_native("Show or hide this node's attributes (Maya: click the node name in INPUTS)", 'MWK:ui/channel_box.py:2147')
    bl_options = {'INTERNAL'}
    node: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/channel_box.py:2150')
    tip: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/channel_box.py:2151')

    @classmethod
    def description(cls, context, props):
        return _zh(props.tip or cls.__doc__, 'MWK:ui/channel_box.py:2155')

    def execute(self, context):
        ob = lead(context)
        if ob is None or not self.node:
            return {'CANCELLED'}
        set_open(ob, self.node, not is_open(ob, self.node))
        rebuild_rows(context)
        _redraw(context.window)
        return {'FINISHED'}

def _is_cb_dock(context):
    (area, region) = (context.area, context.region)
    if area is None or region is None or area.type != 'PROPERTIES' or (region.type != 'WINDOW'):
        return False
    from . import maya_dock
    return maya_dock.shown_kind(context) == 'CHANNEL_BOX'

def in_channel_part(context, event):
    """The mouse is over the Channel Box part of a Maya dock (above the Layer Editor), cells or not."""
    if not _is_cb_dock(context):
        return False
    region = context.region
    from_top = region.height - event.mouse_region_y
    return 0 <= from_top <= cb_share(region, _unit(context)) * region.height

def over_pane(context, event):
    """The mouse is over an overflowing Channel Box part of a Maya dock."""
    (area, region) = (context.area, context.region)
    if area is None or region is None or area.type != 'PROPERTIES' or (region.type != 'WINDOW'):
        return False
    from . import maya_dock
    if maya_dock.shown_kind(context) != 'CHANNEL_BOX':
        return False
    if _last.get(area.as_pointer(), (0, 0, None))[2] is None:
        return False
    from_top = region.height - event.mouse_region_y
    return 0 <= from_top <= cb_share(region, _unit(context)) * region.height

def scroll_lines(context, amount):
    """Move only the virtual Channel Box rows, never values or the Layer Editor."""
    area = context.area
    if area is None:
        return False
    ptr = area.as_pointer()
    (first, total, limit) = _last.get(ptr, (0, 0, None))
    if limit is None:
        return False
    first = _scroll.get(ptr, first)
    _scroll[ptr] = max(0, min(first + amount, max(0, total - limit)))
    if _scroll[ptr] != first and context.window is not None:
        _hover.pop(context.window.as_pointer(), None)
    area.tag_redraw()
    return True

class ALLSET_OT_cb_wheel(bpy.types.Operator):
    """Catch Channel Box scrolling before Blender's field and panel handlers"""
    bl_translation_context = 'MWK:ui/channel_box.py:2220'
    bl_idname = 'allset.cb_wheel'
    bl_label = _zh_native('Channel Box Wheel Navigation', 'MWK:ui/channel_box.py:2220')
    bl_description = _zh_native("Catch Channel Box scrolling before Blender's field and panel handlers", 'MWK:ui/channel_box.py:2220')
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        if context.window is None:
            return {'CANCELLED'}
        self._window_ptr = context.window.as_pointer()
        self._generation = _wheel_generation
        self._fraction = {}
        _wheel_windows[self._window_ptr] = self._generation
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        from .. import live_refs
        window = live_refs.window(self._window_ptr)
        if self._generation != _wheel_generation or window is None:
            if _wheel_windows.get(self._window_ptr) == self._generation:
                _wheel_windows.pop(self._window_ptr, None)
            return {'CANCELLED', 'PASS_THROUGH'}
        if event.type not in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN'} or event.ctrl or event.shift or event.alt or event.oskey:
            return {'PASS_THROUGH'}
        (x, y) = (event.mouse_x, event.mouse_y)
        for area in window.screen.areas:
            if area.type != 'PROPERTIES':
                continue
            for region in area.regions:
                if region.type != 'WINDOW' or not region.x <= x < region.x + region.width or (not region.y <= y < region.y + region.height):
                    continue
                with context.temp_override(window=window, area=area, region=region):
                    ctx = bpy.context
                    from . import maya_dock
                    if x >= region.x + region.width - maya_dock.area_reserved_px(ctx):
                        return {'PASS_THROUGH'}
                    from types import SimpleNamespace
                    if not over_pane(ctx, SimpleNamespace(mouse_region_y=y - region.y)):
                        return {'PASS_THROUGH'}
                    if event.type == 'TRACKPADPAN':
                        ptr = area.as_pointer()
                        delta = (event.mouse_prev_y - event.mouse_y) / row_pitch(ctx)
                        fraction = self._fraction.get(ptr, 0.0) + delta
                        amount = int(fraction)
                        self._fraction[ptr] = fraction - amount
                    else:
                        amount = WHEEL_LINES if event.type == 'WHEELDOWNMOUSE' else -WHEEL_LINES
                    scroll_lines(ctx, amount)
                    return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}

def _ensure_wheel_watch():
    if bpy.app.background:
        return None
    for window in bpy.context.window_manager.windows:
        if _wheel_windows.get(window.as_pointer()) == _wheel_generation:
            continue
        for area in window.screen.areas:
            if area.type != 'PROPERTIES':
                continue
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if region is None:
                continue
            with bpy.context.temp_override(window=window, area=area, region=region):
                if _is_cb_dock(bpy.context):
                    bpy.ops.allset.cb_wheel('INVOKE_DEFAULT')
                    break
    return 0.25

class ALLSET_OT_cb_scroll(bpy.types.Operator):
    """Scroll the Channel Box (Maya: its own scroll bar; the Layer Editor below stays)"""
    bl_translation_context = 'MWK:ui/channel_box.py:2296'
    bl_idname = 'allset.cb_scroll'
    bl_label = _zh_native('Scroll Channel Box', 'MWK:ui/channel_box.py:2296')
    bl_description = _zh_native('Scroll the Channel Box (Maya: its own scroll bar; the Layer Editor below stays)', 'MWK:ui/channel_box.py:2296')
    bl_options = {'INTERNAL'}
    lines: IntProperty(options={'SKIP_SAVE'}, translation_context='MWK:ui/channel_box.py:2299')

    def invoke(self, context, event):
        if event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            if event.ctrl or event.shift or event.alt or (not over_pane(context, event)):
                return {'PASS_THROUGH'}
            self.lines = WHEEL_LINES if event.type == 'WHEELDOWNMOUSE' else -WHEEL_LINES
        return self.execute(context)

    def execute(self, context):
        return {'FINISHED'} if scroll_lines(context, self.lines) else {'CANCELLED'}

def _scroll_row(col, first, limit, total):
    row = col.row(align=True)
    row.alignment = 'RIGHT'
    for (lines, icon, on) in ((-BUTTON_LINES, 'TRIA_UP', first > 0), (BUTTON_LINES, 'TRIA_DOWN', first + limit < total)):
        sub = row.row(align=True)
        sub.enabled = on
        sub.operator(ALLSET_OT_cb_scroll.bl_idname, text=_dcc_display(''), icon=icon, emboss=False).lines = lines
COMPONENT_TYPES = {'MESH', 'CURVE', 'SURFACE', 'LATTICE'}

def component_mode(ob):
    """Maya component mode on the lead: a mesh / curve / surface / lattice object in edit mode (armature edit mode is
    joint placement, PLACING_TEXT)."""
    return ob is not None and (not is_bone(ob)) and (ob.type in COMPONENT_TYPES) and (ob.mode == 'EDIT')

def _draw_component_lines(lines, context, ob):
    """Component mode under the shape's name: the CVs line / table (points selected), then INPUTS."""
    cb_points.draw(lines, context, ob)
    draw_inputs(lines, context, ob)

def _draw_lines(lines, context, ob, cb, sel, blue):
    """Every Channel Box line under the lead's name: channels, SHAPES, INPUTS (collapsed nodes, step 135)."""
    for (key, _label, _path, _idx, kind) in MAIN:
        if is_hidden(ob, key):
            continue
        if kind == 'ROT' and (not has_channel(ob, key)):
            continue
        r = lines.row()
        if r is not None:
            draw_channel_row(r, ob, key, cb, key + '_text', key in sel, key in blue, cb, key + '_sel')
    if not has_channel(ob, 'rx'):
        r = lines.row()
        if r is not None:
            r.label(text=_zh(f'Rotation mode {ob.rotation_mode}', 'MWK:ui/channel_box.py:2349'))
        r = lines.row()
        if r is not None:
            r.prop(ob, 'rotation_quaternion' if ob.rotation_mode == 'QUATERNION' else 'rotation_axis_angle', text=_dcc_display(''))
        r = lines.row()
        if r is not None:
            r.operator(ALLSET_OT_cb_rotate_order.bl_idname, text=_zh('Rotate Order XYZ', 'MWK:ui/channel_box.py:2355')).order = 'XYZ'
    for name in custom_keys(ob):
        key = CUSTOM_PREFIX + name
        if is_hidden(ob, key):
            continue
        r = lines.row()
        if r is None:
            continue
        row = row_for(context, ob, 'CUSTOM', name)
        if row is not None:
            draw_channel_row(r, ob, key, row, 'text', key in sel, sel_owner=row, sel_prop='sel')
        else:
            draw_channel_row(r, ob, key, ob, f'["{name}"]', key in sel)
    if is_bone(ob) and hasattr(ob.bone, 'allset_joint_radius'):
        r = lines.row()
        if r is not None:
            split = r.row(align=True).split(factor=0.5, align=True)
            split.alignment = 'RIGHT'
            split.label(text=_zh('Radius', 'MWK:ui/channel_box.py:2374'))
            split.prop(ob.bone, 'allset_joint_radius', text=_dcc_display(''))
            r.label(text=_dcc_display(''), icon='BLANK1')
    data = getattr(ob, 'data', None)
    if data is not None:
        r = lines.row()
        if r is not None:
            r.label(text=_zh('SHAPES', 'MWK:ui/channel_box.py:2384'))
        r = lines.row()
        if r is not None:
            r.separator(factor=1.5)
            r.prop(data, 'name', text=_dcc_display(''))
        for prop in SHAPE_PROPS.get(ob.type, ()):
            if hasattr(data, prop) or _virtual(data, prop) is not None:
                r = lines.row()
                if r is not None:
                    _draw_text_row(r, context, ob, data, prop, 'SHAPE', label=shape_label(ob, prop))
    draw_inputs(lines, context, ob)

def draw_inputs(lines, context, ob):
    """INPUTS, newest first; every node starts collapsed (Maya).
    Smooth Mesh Preview is a shape display attribute in Maya, not an input node (step 15)."""
    inputs = _inputs(ob)
    cons = constraints(ob)
    from . import in_view
    last = in_view.cb_record(context, ob)
    from . import creation_inputs
    created = creation_inputs.has_node(ob)
    if not (inputs or cons or last is not None or created):
        return
    r = lines.row()
    if r is not None:
        r.label(text=_zh('INPUTS', 'MWK:ui/channel_box.py:2413'))
    if last is not None:
        in_view.draw_cb_node(lines, context, last)
    from . import attribute_editor
    for mod in inputs:
        try:
            label = attribute_editor.modifier_node(ob, mod)[0]
        except ValueError:
            label = mod.name
        (row, opened) = node_row(lines, ob, mod_node(mod), label)
        if row is not None:
            row.prop(mod, 'show_viewport', text=_dcc_display(''))
        if opened:
            for prop in _modifier_props(mod):
                r = lines.row()
                if r is not None:
                    _draw_text_row(r, context, ob, mod, prop, 'INPUT', mod.type, _nth_of_type(ob, mod))
    if created:
        creation_inputs.draw_cb(lines, context, ob)
    from ..operators import constrain_multi
    for con in cons:
        mb = constrain_multi.member(con, ob)
        if mb is not None:
            if constrain_multi.is_head(con, ob):
                _draw_group(lines, context, ob, con, mb)
            continue
        (row, opened) = node_row(lines, ob, con_node(ob, con), constraint_node_name(ob, con), active=constraint_enabled(con))
        if row is not None and hasattr(con, 'enabled'):
            row.prop(con, 'enabled', text=_dcc_display(''))
        if opened:
            r = lines.row()
            if r is not None:
                _draw_text_row(r, context, ob, con, 'influence', 'CONSTRAINT', con.type, _nth_constraint(ob, con), label=weight_name(con))

def _draw_group(lines, context, ob, con, mb):
    """A kit multi-target constraint = one Maya node: its state toggles every member, its rows are the target weights
    <target>W0, W1 ... (step 226, operators/constrain_multi.py)."""
    from ..operators import constrain_multi
    on = constraint_enabled(con)
    (row, opened) = node_row(lines, ob, con_node(ob, con), constraint_node_name(ob, con), active=on)
    if row is not None:
        op = row.operator('allset.constraint_group_enable', text=_dcc_display(''), emboss=False, icon='CHECKBOX_HLT' if on else 'CHECKBOX_DEHLT')
        op.object = ob.id_data.name
        op.bone = ob.name if is_bone(ob) else ''
        op.group = mb.group
    if opened:
        if constrain_multi.group_type(con, ob) in ('orientConstraint', 'parentConstraint'):
            r = lines.row()
            if r is not None:
                _draw_interp_row(r, ob, mb.group)
        for (prop, label) in constrain_multi.weights(ob, mb.group):
            if prop not in ob.keys():
                continue
            r = lines.row()
            if r is not None:
                _draw_text_row(r, context, ob, ob, prop, 'CUSTOM', label=label)

def _draw_interp_row(layout, ob, group):
    """Maya's keyable Interp Type of an orient / parent constraint (enum, factory Average; step 252, #168)."""
    from ..operators import constrain_interp
    mode = constrain_interp.mode_of(ob, group)
    line = layout.row(align=True)
    split = line.split(factor=0.5, align=True)
    name = split.row(align=True)
    name.alignment = 'CENTER'
    name.label(text=_zh('Interp Type', 'MWK:ui/channel_box.py:2485'))
    right = split.row(align=True)
    right.context_pointer_set('allset_interp_owner', ob)
    right.context_string_set('allset_interp_group', group)
    right.menu(ALLSET_MT_cb_interp.bl_idname, text=_zh(constrain_interp.NAMES[constrain_interp.SHORTEST if mode is None else mode], 'MWK:ui/channel_box.py:2490'))
    line.label(text=_dcc_display(''), icon='BLANK1')

class ALLSET_MT_cb_interp(bpy.types.Menu):
    bl_translation_context = 'MWK:ui/channel_box.py:2496'
    bl_idname = 'ALLSET_MT_cb_interp'
    bl_label = _zh_native('Interp Type', 'MWK:ui/channel_box.py:2496')

    def draw(self, context):
        from ..operators import constrain_interp
        owner = getattr(context, 'allset_interp_owner', None)
        group = getattr(context, 'allset_interp_group', '')
        if owner is None or not group:
            return
        for (i, n) in enumerate(constrain_interp.NAMES):
            op = self.layout.operator('allset.constraint_interp', text=_zh(n, 'MWK:ui/channel_box.py:2505'))
            op.object = owner.id_data.name
            op.bone = owner.name if is_bone(owner) else ''
            op.group = group
            op.mode = str(i)

class ALLSET_PT_channel_box(bpy.types.Panel):
    bl_translation_context = 'MWK:ui/channel_box.py:2516'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = CATEGORY
    bl_label = _zh_native('Channel Box', 'MWK:ui/channel_box.py:2516')
    bl_order = 0
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        units = ALLSET_PT_channel_box.body(self.layout, context)
        fill_pane(self.layout, context, units)

    @staticmethod
    def body(layout, context):
        """Draw the Channel Box; returns its height in UI units (estimate, for the CB_SHARE pane). The row above it
        (Maya's title / tab row) is the dock's handle + tab row (ui/maya_dock.py, step 116)."""
        if context.area is not None:
            _last.pop(context.area.as_pointer(), None)
        from .attribute_editor import wrap_rows
        rows = wrap_rows(context, [label for (label, _m) in MENU_BAR], equal=False)
        for idx in rows:
            chrome.menu_bar(layout, [MENU_BAR[i] for i in idx])
        units = 1.0 + len(rows)
        if placing_joints(context):
            extra = draw_joint_translate(layout, context)
            layout.separator(factor=2)
            chrome.wrapped(layout, PLACING_TEXT)
            return units + 0.5 + extra + len(PLACING_TEXT)
        ob = lead(context)
        comp = component_mode(ob)
        if ob is None or (comp and (not cb_points.has_selection(ob))):
            draw_empty(layout)
            return units + 4.2 + len(EMPTY_TEXT)
        units += 1.0
        cb = context.scene.allset_cb
        sel = set(selected_channels(context))
        head = layout.row(align=True)
        if comp:
            head.prop(ob.data, 'name', text=_dcc_display(''), emboss=False)
            args = (context, ob)
            draw = _draw_component_lines
        else:
            head.prop(ob, 'name', text=_dcc_display(''), emboss=False)
            args = (context, ob, cb, sel, constrained_keys(ob))
            draw = _draw_lines
        n = len(targets(context))
        if n > 1:
            head.label(text=f'+{_dcc_display(n - 1)}')
        if not is_bone(ob) and ob.type == 'ARMATURE' and (ob.mode == 'OBJECT'):
            hint = layout.row()
            hint.active = False
            hint.label(text=_zh(POSE_HINT, 'MWK:ui/channel_box.py:2576'))
            units += 1.0
        count = Lines(None)
        draw(count, *args)
        area = context.area
        ptr = area.as_pointer() if area is not None else 0
        start = _scroll.get(ptr, 0)
        if _reveal['node'] in count.marks:
            start = count.marks[_reveal['node']]
            _reveal['node'] = None
        (first, limit, over) = window_lines(count.n, pane_room(context, units), start)
        if over:
            _scroll[ptr] = first
        col = layout.column(align=True)
        col.scale_y = ROW_SCALE
        lines = Lines(col, first, limit)
        draw(lines, *args)
        shown = lines.shown
        if over:
            _scroll_row(head, first, limit, count.n)
        _last[ptr] = (first, count.n, limit)
        return units + shown * ROW_SCALE + 0.3

def fill_pane(layout, context, units):
    """Empty space under the Channel Box so the Layer Editor starts at CB_SHARE of the dock height, like Maya's
    fixed split (a longer Channel Box scrolls inside its part, ``Lines``)."""
    region = context.region
    if units is None or region is None or region.type not in {'UI', 'WINDOW'} or _split_off(context):
        return
    u = _unit(context)
    if u <= 0:
        return
    gap = cb_share(region, u) * region.height / u - units - PANE_TOP
    if gap > 0.25:
        col = layout.column()
        col.scale_y = gap
        col.label(text=_dcc_display(''))
PANE_TOP = 1.6

class ALLSET_PT_dock_attribute_editor(bpy.types.Panel):
    """Maya Attribute Editor tab of the dock (step 99)"""
    bl_translation_context = 'MWK:ui/channel_box.py:2630'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = AE_CATEGORY
    bl_label = _zh_native('Attribute Editor', 'MWK:ui/channel_box.py:2630')
    bl_order = 0
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        from . import attribute_editor
        attribute_editor.draw_panel(self.layout, context)

class ALLSET_PT_dock_modeling_toolkit(bpy.types.Panel):
    """Maya Modeling Toolkit tab of the dock (step 99)"""
    bl_translation_context = 'MWK:ui/channel_box.py:2644'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = MTK_CATEGORY
    bl_label = _zh_native('Modeling Toolkit', 'MWK:ui/channel_box.py:2644')
    bl_order = 0
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        from . import modeling_toolkit
        modeling_toolkit.draw(self.layout, context)
classes = (ALLSET_PG_cb_row, ALLSET_PG_channel_box, ALLSET_OT_cb_virtual_slider, ALLSET_OT_cb_select_channel, ALLSET_OT_cb_deselect_channels, ALLSET_OT_cb_hover, ALLSET_OT_cb_channel_drag, ALLSET_PT_cb_field, ALLSET_OT_cb_node_toggle, ALLSET_OT_cb_scroll, ALLSET_OT_cb_wheel, *CHANNEL_OPS, ALLSET_OT_cb_show_all, ALLSET_MT_cb_channels, ALLSET_MT_cb_freeze, ALLSET_MT_cb_settings, ALLSET_OT_cb_make_lead, ALLSET_OT_cb_rotate_order, ALLSET_MT_cb_edit, ALLSET_MT_cb_interp, ALLSET_MT_cb_object, ALLSET_MT_cb_show)

def register():
    global _wheel_generation
    _wheel_generation += 1
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.allset_cb = bpy.props.PointerProperty(type=ALLSET_PG_channel_box, translation_context='MWK:ui/channel_box.py:2670')
    bpy.types.WindowManager.allset_cb_selected = StringProperty(name=_zh_native('Selected Channels', 'MWK:ui/channel_box.py:2671'), options={'SKIP_SAVE'}, translation_context='MWK:ui/channel_box.py:2671')
    bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph)
    bpy.app.handlers.load_post.append(_on_load)
    bpy.app.timers.register(_first_rebuild, first_interval=0.0)
    if not bpy.app.timers.is_registered(_poll_transform_values):
        bpy.app.timers.register(_poll_transform_values, first_interval=0.1)
    bpy.types.UI_MT_button_context_menu.prepend(draw_button_menu)
    if not bpy.app.background:
        bpy.app.timers.register(_ensure_wheel_watch, first_interval=0.0, persistent=True)

def unregister():
    global _transform_snapshot, _wheel_generation
    _wheel_generation += 1
    _wheel_windows.clear()
    if bpy.app.timers.is_registered(_ensure_wheel_watch):
        bpy.app.timers.unregister(_ensure_wheel_watch)
    _transform_snapshot = None
    if bpy.app.timers.is_registered(_poll_transform_values):
        bpy.app.timers.unregister(_poll_transform_values)
    _reveal['node'] = None
    _watching.clear()
    _hover.clear()
    reset_open()
    _last.clear()
    bpy.types.UI_MT_button_context_menu.remove(draw_button_menu)
    if bpy.app.timers.is_registered(_first_rebuild):
        bpy.app.timers.unregister(_first_rebuild)
    bpy.app.handlers.load_post.remove(_on_load)
    bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph)
    del bpy.types.WindowManager.allset_cb_selected
    del bpy.types.Scene.allset_cb
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
