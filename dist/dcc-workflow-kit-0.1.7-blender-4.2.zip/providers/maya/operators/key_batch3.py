# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Key batch 3 (docs/steps/step_107.md 「계획」): Maya keys that had no or a wrong binding.

Maya commands (meanings from Maya's annotations):
- Ctrl+M ToggleMainMenubar: the main menu bar folds into Blender's top-bar menu button (``area.show_menus`` of the
  top bar, which the kit menu bar already follows: ui/status_line.draw_left).
- Alt+B CycleBackgroundColor: Maya's cycle in every view, flat colours only (steps 120, 130; see below).
- Alt+C ToggleColorFeedback (skin paint): the weight colours on / off (Weight Paint overlay opacity 1 <-> 0).
- u PaintOperationMarkingMenu: Maya's Artisan paint operations Replace / Add / Scale / Smooth (ui/paint_weights.py
  OPERATIONS) as a menu.
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy.props import EnumProperty
from .. import results
(FLAT, LIGHT, BLACK) = (0.36, 0.631, 0.0)
CYCLE = ('GREY', 'LIGHT', 'BLACK')

def srgb_to_linear(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

def linear_to_srgb(c):
    return c * 12.92 if c <= 0.0031308 else 1.055 * c ** (1 / 2.4) - 0.055

def background_state(shading):
    """'GREY' / 'LIGHT' / 'BLACK' of a 3D View's shading, else the display value of its colour."""
    if shading.background_type == 'THEME':
        return 'GREY'
    if shading.background_type != 'VIEWPORT':
        return FLAT
    v = linear_to_srgb(shading.background_color[0])
    if abs(v - LIGHT) < 0.001:
        return 'LIGHT'
    if abs(v - FLAT) < 0.001:
        return 'GREY'
    if v < 0.0001:
        return 'BLACK'
    return v

def next_state(state):
    """Maya's Alt+B rule on a state or a display value, flat colours only (no gradient)."""
    value = {'GREY': FLAT, 'LIGHT': LIGHT, 'BLACK': BLACK}.get(state, state)
    if value == 0:
        return 'GREY'
    if value < 0.5:
        return 'LIGHT'
    return 'BLACK'

def set_shading(shading, state, color=None):
    """A view's own flat background (``VIEWPORT``): Maya's grey / light grey / black, or ``color`` (display RGB)."""
    rgb = color if color is not None else ({'GREY': FLAT, 'LIGHT': LIGHT}.get(state, BLACK),) * 3
    shading.background_type = 'VIEWPORT'
    shading.background_color = tuple((srgb_to_linear(c) for c in rgb))

def view_spaces():
    """Every 3D View of the file (Maya's background is one global setting), the Tool Box column excepted."""
    from ..ui import toolbox
    for screen in bpy.data.screens:
        for area in screen.areas:
            for space in area.spaces:
                if space.type == 'VIEW_3D' and (not toolbox.is_toolbox(space)):
                    yield (area, space)

def apply_background(state, color=None):
    """Put every 3D View in a Maya background state ('GREY' / 'LIGHT' / 'BLACK' / 'CUSTOM' + color)."""
    for (area, space) in view_spaces():
        set_shading(space.shading, state, color)
        area.tag_redraw()

def cycle_background(shading):
    """Next Maya background (Alt+B) read from ``shading`` (the view under the mouse), applied to every view."""
    state = next_state(background_state(shading))
    apply_background(state)
    set_shading(shading, state)
    return state

def reset_background():
    """Maya's factory background (flat 0.36) in every view: promotional / comparison shots use it (step 120)."""
    apply_background('GREY')

class ALLSET_OT_cycle_background(bpy.types.Operator):
    """Cycle the background color from dark to light (Maya Alt+B): grey, light grey, black"""
    bl_translation_context = 'MWK:operators/key_batch3.py:111'
    bl_idname = 'allset.cycle_background'
    bl_label = _zh_native('Cycle Background Color', 'MWK:operators/key_batch3.py:111')
    bl_description = _zh_native('Cycle the background color from dark to light (Maya Alt+B): grey, light grey, black', 'MWK:operators/key_batch3.py:111')
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space is not None and space.type == 'VIEW_3D'

    def execute(self, context):
        state = cycle_background(context.space_data.shading)
        results.result(self, _zh(f'Background: {state.title()}', 'MWK:operators/key_batch3.py:121'))
        return {'FINISHED'}

def _dialog_values(op):
    shading = next((space.shading for (_area, space) in view_spaces()), None)
    if shading is not None and shading.background_type == 'VIEWPORT':
        op.background = tuple((linear_to_srgb(c) for c in shading.background_color))
    else:
        op.background = (FLAT,) * 3

class ALLSET_OT_color_settings(bpy.types.Operator):
    """Viewport background color (Maya Windows > Settings/Preferences > Color Settings: 3D Views Background).
    Maya's gradient background has no per-view equivalent in Blender"""
    bl_translation_context = 'MWK:operators/key_batch3.py:137'
    bl_idname = 'allset.color_settings'
    bl_label = _zh_native('Color Settings', 'MWK:operators/key_batch3.py:137')
    bl_description = _zh_native("Viewport background color (Maya Windows > Settings/Preferences > Color Settings: 3D Views Background).\nMaya's gradient background has no per-view equivalent in Blender", 'MWK:operators/key_batch3.py:137')
    bl_options = {'REGISTER'}
    background: bpy.props.FloatVectorProperty(name=_zh_native('Background', 'MWK:operators/key_batch3.py:140'), subtype='COLOR_GAMMA', size=3, min=0.0, max=1.0, default=(FLAT,) * 3, translation_context='MWK:operators/key_batch3.py:140')

    def invoke(self, context, event):
        _dialog_values(self)
        return context.window_manager.invoke_props_dialog(self, title=_zh('Color Settings', 'MWK:operators/key_batch3.py:145'), confirm_text=_zh('Apply', 'MWK:operators/key_batch3.py:145'))

    def draw(self, context):
        col = self.layout.column()
        col.use_property_split = True
        col.label(text=_zh('3D Views', 'MWK:operators/key_batch3.py:150'))
        col.prop(self, 'background')

    def execute(self, context):
        if all((abs(c - FLAT) < 0.001 for c in self.background)):
            apply_background('GREY')
        else:
            apply_background('CUSTOM', color=tuple(self.background))
        return {'FINISHED'}

def top_bar(context):
    """The window's top bar area (a global area, remembered while the kit menu bar draws: ui/status_line)."""
    from ..ui import status_line
    window = context.window
    return status_line._top_bars.get(window.as_pointer()) if window is not None else None

class ALLSET_OT_main_menubar_toggle(bpy.types.Operator):
    """Show or hide the main menu bar (Maya Ctrl+M): the menus fold into the top bar's menu button"""
    bl_translation_context = 'MWK:operators/key_batch3.py:171'
    bl_idname = 'allset.main_menubar_toggle'
    bl_label = _zh_native('Toggle Main Menu Bar', 'MWK:operators/key_batch3.py:171')
    bl_description = _zh_native("Show or hide the main menu bar (Maya Ctrl+M): the menus fold into the top bar's menu button", 'MWK:operators/key_batch3.py:171')
    bl_options = {'REGISTER'}

    def execute(self, context):
        area = top_bar(context)
        if area is None:
            return {'CANCELLED'}
        try:
            area.show_menus = not area.show_menus
            area.tag_redraw()
        except ReferenceError:
            return {'CANCELLED'}
        return {'FINISHED'}

class ALLSET_OT_color_feedback(bpy.types.Operator):
    """Show or hide the weight colours while painting skin weights (Maya Alt+C, Toggle Color Feedback)"""
    bl_translation_context = 'MWK:operators/key_batch3.py:189'
    bl_idname = 'allset.color_feedback'
    bl_label = _zh_native('Toggle Color Feedback', 'MWK:operators/key_batch3.py:189')
    bl_description = _zh_native('Show or hide the weight colours while painting skin weights (Maya Alt+C, Toggle Color Feedback)', 'MWK:operators/key_batch3.py:189')
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space is not None and space.type == 'VIEW_3D'

    def execute(self, context):
        overlay = context.space_data.overlay
        overlay.weight_paint_mode_opacity = 0.0 if overlay.weight_paint_mode_opacity > 0.0 else 1.0
        return {'FINISHED'}
PAINT_OPERATIONS = (('MIX', _dcc_source('Replace')), ('ADD', _dcc_source('Add')), ('MUL', _dcc_source('Scale')), ('SMOOTH', _dcc_source('Smooth')))

class ALLSET_OT_paint_operation(bpy.types.Operator):
    """Maya paint operation of the skin weight brush: Replace / Add / Scale (brush blend) or Smooth (Blur tool)"""
    bl_translation_context = 'MWK:operators/key_batch3.py:209'
    bl_idname = 'allset.paint_operation'
    bl_label = _zh_native('Paint Operation', 'MWK:operators/key_batch3.py:209')
    bl_description = _zh_native('Maya paint operation of the skin weight brush: Replace / Add / Scale (brush blend) or Smooth (Blur tool)', 'MWK:operators/key_batch3.py:209')
    bl_options = {'REGISTER', 'UNDO'}
    operation: EnumProperty(items=_zh_enum([(k, label, '') for (k, label) in PAINT_OPERATIONS], 'MWK:operators/key_batch3.py:212'), translation_context='MWK:operators/key_batch3.py:212')

    @classmethod
    def poll(cls, context):
        return context.mode == 'PAINT_WEIGHT'

    def execute(self, context):
        if self.operation == 'SMOOTH':
            return bpy.ops.wm.tool_set_by_id(name='builtin_brush.Blur')
        brush = context.tool_settings.weight_paint.brush
        if brush is None:
            return {'CANCELLED'}
        brush.blend = self.operation
        return {'FINISHED'}

class ALLSET_MT_paint_operation(bpy.types.Menu):
    """Maya Artisan paint operation marking menu (u)"""
    bl_translation_context = 'MWK:operators/key_batch3.py:231'
    bl_idname = 'ALLSET_MT_paint_operation'
    bl_label = _zh_native('Paint Operation', 'MWK:operators/key_batch3.py:231')

    def draw(self, context):
        brush = getattr(context.tool_settings.weight_paint, 'brush', None)
        for (key, label) in PAINT_OPERATIONS:
            on = brush is not None and brush.blend == key
            self.layout.operator(ALLSET_OT_paint_operation.bl_idname, text=_zh(label, 'MWK:operators/key_batch3.py:237'), icon='RADIOBUT_ON' if on else 'RADIOBUT_OFF').operation = key
classes = (ALLSET_OT_cycle_background, ALLSET_OT_color_settings, ALLSET_OT_main_menubar_toggle, ALLSET_OT_color_feedback, ALLSET_OT_paint_operation, ALLSET_MT_paint_operation)
