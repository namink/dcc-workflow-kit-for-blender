# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya DAG rules for a parent: what happens to a node's descendants (step 164).

Maya: a node is drawn only while it **and every ancestor** are visible —
hiding group1 (h, Ctrl+H, its Visibility channel, its display layer's V) hides pCube1 without touching pCube1's own
Visibility, and showing group1 again leaves a child that was hidden on its own hidden. Delete, Export Selection and
Isolate Select take the selected nodes with everything below them.

Blender (measured, same file): a parent's ``hide_viewport`` / ``hide_set`` never hides its children and
``object.delete`` leaves the children, unparented. So:

- ``sync``: an object whose ancestor is hidden (own Visibility = ``hide_viewport``, or its display layer's V) gets the
  view-layer flag (``hide_set``) marked ``MARK``; its own ``hide_viewport`` (Maya's Visibility channel) stays as it
  was. Objects the kit did not hide that way are never touched (a layer's or Blender's own ``hide_set`` stays).
  Run from a depsgraph handler (only writes on change, so it settles) and right after kit visibility edits.
- ``hierarchy``: the selection with all descendants, for Delete (``allset.delete``), Export Selection
  (``selected_hierarchy``) and Isolate Select (``allset.isolate``).
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy.app.handlers import persistent
MARK = 'allset_hidden_by_parent'

def hierarchy(objects):
    """``objects`` plus everything below them, each once, parents first."""
    (out, seen) = ([], set())
    for ob in objects:
        for o in (ob, *ob.children_recursive):
            if o.session_uid not in seen:
                seen.add(o.session_uid)
                out.append(o)
    return out

def _layer_hidden(ob, scene):
    from ..ui import layer_editor
    coll = layer_editor.layer_of(ob, scene)
    return coll is not None and (not coll.allset_layer.visible)

def hidden_self(ob, scene):
    """Maya: the node's own visibility off, or its display layer hidden (the node's drawOverride)."""
    return ob.hide_viewport or _layer_hidden(ob, scene)

def hidden_by_ancestor(ob, scene):
    p = ob.parent
    while p is not None:
        if hidden_self(p, scene):
            return True
        p = p.parent
    return False

def sync(scene=None, view_layer=None):
    """Hide / show descendants of hidden nodes (view-layer flag + ``MARK``). Returns the number of changes."""
    scene = scene or bpy.context.scene
    if scene is None:
        return 0
    view_layer = view_layer or bpy.context.view_layer
    if view_layer is None:
        return 0
    changed = 0
    for ob in scene.objects:
        by_parent = hidden_by_ancestor(ob, scene)
        if not by_parent and MARK not in ob:
            continue
        want = by_parent or _layer_hidden(ob, scene)
        try:
            if ob.hide_get(view_layer=view_layer) != want:
                ob.hide_set(want, view_layer=view_layer)
                changed += 1
        except RuntimeError:
            continue
        if by_parent:
            if MARK not in ob:
                ob[MARK] = True
        elif MARK in ob:
            del ob[MARK]
    return changed
_busy = []

@persistent
def _on_depsgraph(scene, _depsgraph=None):
    if _busy:
        return
    _busy.append(True)
    try:
        sync(scene)
    except Exception:
        pass
    finally:
        _busy.clear()

@persistent
def _on_load(*_args):
    for scene in bpy.data.scenes:
        for vl in scene.view_layers:
            try:
                sync(scene, vl)
            except Exception:
                pass

def delete_hierarchy(context, objects):
    """Maya delete of transforms: the nodes and every descendant, with their now unused data. Returns the count."""
    from . import constrain_199, startup_cameras
    obs = [ob for ob in hierarchy(objects) if not startup_cameras.is_startup(ob)]
    helpers = [h for h in constrain_199.helpers_owned_by(obs) if h not in obs]
    from . import ik_rp
    poles = ik_rp.helpers_of(obs)
    from . import spline_twist
    spline_twist.release(obs)
    datas = {ob.data for ob in obs if ob.data is not None}
    n = len(obs)
    for ob in reversed(obs):
        bpy.data.objects.remove(ob, do_unlink=True)
    constrain_199.remove_helpers(helpers)
    for h in poles:
        try:
            bpy.data.objects.remove(h, do_unlink=True)
        except ReferenceError:
            pass
    for data in datas:
        try:
            if data.users == 0:
                getattr(bpy.data, _DATA_COLLECTION.get(type(data).__name__, ''), None).remove(data)
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    return n
_DATA_COLLECTION = {_dcc_source('Mesh'): 'meshes', _dcc_source('Curve'): 'curves', 'SurfaceCurve': 'curves', 'TextCurve': 'curves', _dcc_source('Lattice'): 'lattices', _dcc_source('Armature'): 'armatures', _dcc_source('Camera'): 'cameras', _dcc_source('Light'): 'lights', _dcc_source('SpotLight'): 'lights', _dcc_source('PointLight'): 'lights', 'SunLight': 'lights', 'AreaLight': 'lights', 'MetaBall': 'metaballs', 'GreasePencil': 'grease_pencils'}

class selected_hierarchy:
    """``with selected_hierarchy(context):`` the descendants of the selection are selected too (Maya Export
    Selection), and the selection is put back afterwards."""

    def __init__(self, context):
        self.context = context
        self.added = []

    def __enter__(self):
        sel = list(self.context.selected_objects)
        for ob in hierarchy(sel):
            if not ob.select_get():
                try:
                    ob.select_set(True)
                    self.added.append(ob)
                except RuntimeError:
                    pass
        return self

    def __exit__(self, *_exc):
        for ob in self.added:
            try:
                ob.select_set(False)
            except (RuntimeError, ReferenceError):
                pass
        return False

class ALLSET_OT_delete(bpy.types.Operator):
    """Delete the selected objects and everything below them (Maya Edit > Delete)"""
    bl_translation_context = 'MWK:operators/dag.py:183'
    bl_idname = 'allset.delete'
    bl_label = _zh_native('Delete', 'MWK:operators/dag.py:183')
    bl_description = _zh_native('Delete the selected objects and everything below them (Maya Edit > Delete)', 'MWK:operators/dag.py:183')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and bool(context.selected_objects)

    def execute(self, context):
        from . import startup_cameras
        for ob in context.selected_objects:
            if startup_cameras.is_startup(ob):
                self.report({'WARNING'}, _zh(f"Non-deletable node '{ob.name}' cannot be deleted.", 'MWK:operators/dag.py:194'))
        delete_hierarchy(context, list(context.selected_objects))
        return {'FINISHED'}

class ALLSET_OT_isolate(bpy.types.Operator):
    """Isolate Select: show only the selected objects and everything below them (Maya Ctrl+1); again = back"""
    bl_translation_context = 'MWK:operators/dag.py:202'
    bl_idname = 'allset.isolate'
    bl_label = _zh_native('Isolate Select', 'MWK:operators/dag.py:202')
    bl_description = _zh_native('Isolate Select: show only the selected objects and everything below them (Maya Ctrl+1); again = back', 'MWK:operators/dag.py:202')
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.space_data is not None and context.space_data.type == 'VIEW_3D'

    def execute(self, context):
        space = context.space_data
        if space.local_view is not None:
            return bpy.ops.view3d.localview(frame_selected=False)
        with selected_hierarchy(context):
            return bpy.ops.view3d.localview(frame_selected=False)
classes = (ALLSET_OT_delete, ALLSET_OT_isolate)

def register_handlers():
    if _on_depsgraph not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph)
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)

def release_all():
    """Disable: show again what only the kit's parent rule hid (the objects' own flags stay)."""
    for scene in bpy.data.scenes:
        for ob in scene.objects:
            if MARK not in ob:
                continue
            for vl in scene.view_layers:
                try:
                    if not _layer_hidden(ob, scene):
                        ob.hide_set(False, view_layer=vl)
                except RuntimeError:
                    pass
            del ob[MARK]

def unregister_handlers():
    for (lst, fn) in ((bpy.app.handlers.depsgraph_update_post, _on_depsgraph), (bpy.app.handlers.load_post, _on_load)):
        if fn in lst:
            lst.remove(fn)
    try:
        release_all()
    except Exception:
        pass
