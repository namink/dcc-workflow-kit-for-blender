# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya's wire deformer (Deform > Wire and Deform > Wire >, step 169).

Maya rule (Maya-exact): for a deformed point p, c = the nearest point of the
*base* wire (a hidden copy of the curve made with the deformer, ``curve1BaseWire``) at parameter u, c' = the wire at
the same u, T / T' their tangents, d = |p - c|, D = Dropoff Distance (× the dropoff locators' scale at u):

    w  = (1 - (d / D)²) · weight              (0 when d >= D)
    p' = p + envelope · [ w (c' - c) + R(T -> T', w · rotation · angle(T, T')) (p - c) - (p - c) ]

so a moved curve pulls the points with it, a bent one turns their offsets, and twist / scale of the curve object
alone change nothing (the curve's points don't move). Blender has no wire modifier, so the kit wire is a Geometry
Nodes modifier named like the Maya node (``wire1``) on a shared node group: both curves become polylines at their
evaluated points (same count, uniform in parameter), the nearest base edge gives c and u. The weights are the
vertex group ``wire1`` (Maya factory weight 1), which Deform > Paint Weights > Wire paints.

Dropoff locators: a locator at parameter a with Percent s scales D; between neighbouring knots
[0, locators sorted by parameter, 1] with scales [1, s..., 1] the scale is s_a + (s_b - s_a) g(t), g(t) = 1 - (1 - t²)²;
the kit keeps up to ``LOCATOR_SLOTS`` per wire.
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
import bpy
from mathutils import Vector
GROUP = '.Allset Wire'
LOCATOR_SLOTS = 4
RESOLUTION = 64
VERSION_PROP = 'allset_wire_version'
VERSION = 1
BASE_SUFFIX = 'BaseWire'
WIRE_PROP = 'allset_wire'
LOC_PROP = 'allset_dropoff'
INPUTS = ((_dcc_source('Wire'), 'NodeSocketObject', None), (_dcc_source('Base Wire'), 'NodeSocketObject', None), (_dcc_source('Dropoff Distance'), 'NodeSocketFloat', 1.0), (_dcc_source('Rotation'), 'NodeSocketFloat', 1.0), (_dcc_source('Envelope'), 'NodeSocketFloat', 1.0), (_dcc_source('Weight'), 'NodeSocketFloat', 1.0)) + tuple((item for i in range(1, LOCATOR_SLOTS + 1) for item in ((f'Locator {i} Param', 'NodeSocketFloat', 1.0), (f'Locator {i} Percent', 'NodeSocketFloat', 1.0))))

class _B:
    """Tiny node builder: math helpers that return output sockets."""

    def __init__(self, ng):
        (self.ng, self.x) = (ng, 0)

    def node(self, kind, **props):
        n = self.ng.nodes.new(kind)
        for (k, v) in props.items():
            setattr(n, k, v)
        self.x += 30
        n.location = (self.x, 0)
        return n

    def link(self, out, inp):
        self.ng.links.new(out, inp)

    def _in(self, sock, value):
        if hasattr(value, 'is_output'):
            self.link(value, sock)
        else:
            sock.default_value = value

    def math(self, op, a, b=0.0, clamp=False):
        n = self.node('ShaderNodeMath', operation=op, use_clamp=clamp)
        self._in(n.inputs[0], a)
        self._in(n.inputs[1], b)
        return n.outputs[0]

    def vmath(self, op, a, b=None, scale=None, out=_dcc_source('Vector')):
        n = self.node('ShaderNodeVectorMath', operation=op)
        self._in(n.inputs[0], a)
        if b is not None:
            self._in(n.inputs[1], b)
        if scale is not None:
            self._in(n.inputs[_dcc_source('Scale')], scale)
        return n.outputs[out]

    def sample_index(self, geo, value, index, domain='EDGE'):
        n = self.node('GeometryNodeSampleIndex', data_type='FLOAT_VECTOR', domain=domain)
        self.link(geo, n.inputs[_dcc_source('Geometry')])
        self.link(value, n.inputs[_dcc_source('Value')])
        self.link(index, n.inputs[_dcc_source('Index')])
        return n.outputs[_dcc_source('Value')]

def _polyline(b, obj_socket):
    info = b.node('GeometryNodeObjectInfo', transform_space='RELATIVE')
    b.link(obj_socket, info.inputs[_dcc_source('Object')])
    rs = b.node('GeometryNodeResampleCurve')
    if hasattr(rs, 'mode'):
        rs.mode = 'EVALUATED'
    else:
        rs.inputs[_dcc_source('Mode')].default_value = _dcc_source('Evaluated')
    b.link(info.outputs[_dcc_source('Geometry')], rs.inputs[_dcc_source('Curve')])
    cm = b.node('GeometryNodeCurveToMesh')
    b.link(rs.outputs[_dcc_source('Curve')], cm.inputs[_dcc_source('Curve')])
    return cm.outputs[_dcc_source('Mesh')]

def _g(b, t):
    """1 - (1 - t²)²."""
    t2 = b.math('MULTIPLY', t, t)
    one = b.math('SUBTRACT', 1.0, t2)
    return b.math('SUBTRACT', 1.0, b.math('MULTIPLY', one, one))

def build_group():
    ng = bpy.data.node_groups.new(GROUP, 'GeometryNodeTree')
    ng[VERSION_PROP] = VERSION
    ng.interface.new_socket(_dcc_source('Geometry'), in_out='INPUT', socket_type='NodeSocketGeometry')
    for (name, stype, default) in INPUTS:
        s = ng.interface.new_socket(name, in_out='INPUT', socket_type=stype)
        if default is not None:
            s.default_value = default
    ng.interface.new_socket(_dcc_source('Geometry'), in_out='OUTPUT', socket_type='NodeSocketGeometry')
    b = _B(ng)
    gin = b.node('NodeGroupInput')
    gout = b.node('NodeGroupOutput')
    I = gin.outputs
    base = _polyline(b, I[_dcc_source('Base Wire')])
    wire = _polyline(b, I[_dcc_source('Wire')])
    p = b.node('GeometryNodeInputPosition').outputs[0]
    near = b.node('GeometryNodeSampleNearest', domain='EDGE')
    b.link(base, near.inputs[_dcc_source('Geometry')])
    b.link(p, near.inputs[_dcc_source('Sample Position')])
    e = near.outputs[_dcc_source('Index')]
    ev = b.node('GeometryNodeInputMeshEdgeVertices')
    A = b.sample_index(base, ev.outputs[_dcc_source('Position 1')], e)
    B = b.sample_index(base, ev.outputs[_dcc_source('Position 2')], e)
    A2 = b.sample_index(wire, ev.outputs[_dcc_source('Position 1')], e)
    B2 = b.sample_index(wire, ev.outputs[_dcc_source('Position 2')], e)
    ab = b.vmath('SUBTRACT', B, A)
    ab2 = b.vmath('SUBTRACT', B2, A2)
    num = b.vmath('DOT_PRODUCT', b.vmath('SUBTRACT', p, A), ab, out=_dcc_source('Value'))
    den = b.vmath('DOT_PRODUCT', ab, ab, out=_dcc_source('Value'))
    f = b.math('DIVIDE', num, den, clamp=True)
    c = b.vmath('ADD', A, b.vmath('SCALE', ab, scale=f))
    c2 = b.vmath('ADD', A2, b.vmath('SCALE', ab2, scale=f))
    size = b.node('GeometryNodeAttributeDomainSize', component='MESH')
    b.link(base, size.inputs[_dcc_source('Geometry')])
    u = b.math('DIVIDE', b.math('ADD', e, f), size.outputs[_dcc_source('Edge Count')])
    knots = [0.0] + [I[f'Locator {i} Param'] for i in range(1, LOCATOR_SLOTS + 1)] + [1.0]
    scales = [1.0] + [I[f'Locator {i} Percent'] for i in range(1, LOCATOR_SLOTS + 1)] + [1.0]
    scale = 1.0
    for j in range(len(knots) - 1):
        span = b.math('SUBTRACT', knots[j + 1], knots[j])
        t = b.math('DIVIDE', b.math('SUBTRACT', u, knots[j]), span, clamp=True)
        step = b.math('SUBTRACT', scales[j + 1], scales[j])
        scale = b.math('ADD', scale, b.math('MULTIPLY', step, _g(b, t)))
    dropoff = b.math('MULTIPLY', I[_dcc_source('Dropoff Distance')], scale)
    v = b.vmath('SUBTRACT', p, c)
    d = b.vmath('LENGTH', v, out=_dcc_source('Value'))
    r = b.math('DIVIDE', d, dropoff)
    w = b.math('MAXIMUM', b.math('SUBTRACT', 1.0, b.math('MULTIPLY', r, r)), 0.0)
    w = b.math('MULTIPLY', w, I[_dcc_source('Weight')])
    T = b.vmath('NORMALIZE', ab)
    T2 = b.vmath('NORMALIZE', ab2)
    axis = b.vmath('CROSS_PRODUCT', T, T2)
    ang = b.math('ARCTAN2', b.vmath('LENGTH', axis, out=_dcc_source('Value')), b.vmath('DOT_PRODUCT', T, T2, out=_dcc_source('Value')))
    ang = b.math('MULTIPLY', b.math('MULTIPLY', ang, w), I[_dcc_source('Rotation')])
    aa = b.node('FunctionNodeAxisAngleToRotation')
    b.link(axis, aa.inputs[_dcc_source('Axis')])
    b.link(ang, aa.inputs[_dcc_source('Angle')])
    rv = b.node('FunctionNodeRotateVector')
    b.link(v, rv.inputs[_dcc_source('Vector')])
    b.link(aa.outputs[_dcc_source('Rotation')], rv.inputs[_dcc_source('Rotation')])
    disp = b.vmath('ADD', b.vmath('SCALE', b.vmath('SUBTRACT', c2, c), scale=w), b.vmath('SUBTRACT', rv.outputs[_dcc_source('Vector')], v))
    sp = b.node('GeometryNodeSetPosition')
    b.link(I[_dcc_source('Geometry')], sp.inputs[_dcc_source('Geometry')])
    b.link(b.vmath('SCALE', disp, scale=I[_dcc_source('Envelope')]), sp.inputs[_dcc_source('Offset')])
    b.link(sp.outputs[_dcc_source('Geometry')], gout.inputs[0])
    return ng

def group():
    ng = bpy.data.node_groups.get(GROUP)
    if ng is not None and ng.bl_idname == 'GeometryNodeTree' and (ng.get(VERSION_PROP) == VERSION):
        return ng
    if ng is not None:
        ng.name = GROUP + '.old'
    return build_group()

def ident(md, name):
    item = md.node_group.interface.items_tree.get(name) if md.node_group is not None else None
    return item.identifier if item is not None else None

def get(md, name):
    from .. import compat
    key = ident(md, name)
    return compat.gn_input_get(md, key) if key is not None else None

def set_(md, name, value):
    from .. import compat
    key = ident(md, name)
    if key is not None:
        compat.gn_input_set(md, key, value)
        md.id_data.update_tag()

def is_wire(md):
    return md.type == 'NODES' and md.node_group is not None and md.node_group.name.startswith(GROUP)

def wires_of_curve(curve):
    """[(object, modifier)] of the kit wires the curve object drives."""
    out = []
    for ob in bpy.data.objects:
        for md in getattr(ob, 'modifiers', ()):
            if is_wire(md) and get(md, _dcc_source('Wire')) == curve:
                out.append((ob, md))
    return out

def make_base(context, curve):
    """``<curve>BaseWire``: a hidden copy of the curve (Maya: transform + nurbsCurve, hidden)."""
    data = curve.data.copy()
    data.name = f'{curve.name}{BASE_SUFFIX}Shape'
    base = bpy.data.objects.new(f'{curve.name}{BASE_SUFFIX}', data)
    for coll in curve.users_collection or (context.scene.collection,):
        coll.objects.link(base)
    base.matrix_world = curve.matrix_world.copy()
    base.hide_set(True)
    base.hide_render = True
    return base

def prepare_curve(curve):
    """The wire's polyline must be fine and have as many points as the base's (a copy of the same data)."""
    if curve.data.resolution_u < RESOLUTION:
        curve.data.resolution_u = RESOLUTION

def add_wire(context, ob, curve, name, group_name, dropoff, envelope=1.0, rotation=1.0):
    """One kit wire node ``name`` on ``ob`` driven by ``curve`` (a base wire is made from its current shape)."""
    prepare_curve(curve)
    base = make_base(context, curve)
    md = ob.modifiers.new(name, 'NODES')
    md.node_group = group()
    set_(md, _dcc_source('Wire'), curve)
    set_(md, _dcc_source('Base Wire'), base)
    set_(md, _dcc_source('Dropoff Distance'), float(dropoff))
    set_(md, _dcc_source('Envelope'), float(envelope))
    set_(md, _dcc_source('Rotation'), float(rotation))
    key = ident(md, _dcc_source('Weight'))
    if group_name:
        from .. import compat
        compat.gn_input_attribute(md, key, group_name)
    names = [n for n in curve.get(WIRE_PROP, '').split(',') if n]
    curve[WIRE_PROP] = ','.join(names + [name])
    return md

def reset(md):
    """Maya Reset: the wire curve goes back to its base (shape and transform), so the wire deforms nothing."""
    (curve, base) = (get(md, _dcc_source('Wire')), get(md, _dcc_source('Base Wire')))
    if curve is None or base is None:
        return False
    curve.data.splines.clear()
    for sp in base.data.splines:
        new = curve.data.splines.new(sp.type)
        if sp.type == 'BEZIER':
            new.bezier_points.add(len(sp.bezier_points) - 1)
            for (a, b) in zip(new.bezier_points, sp.bezier_points):
                (a.co, a.handle_left, a.handle_right) = (b.co, b.handle_left, b.handle_right)
                (a.handle_left_type, a.handle_right_type) = (b.handle_left_type, b.handle_right_type)
        else:
            new.points.add(len(sp.points) - 1)
            for (a, b) in zip(new.points, sp.points):
                a.co = b.co
            new.order_u = sp.order_u
            new.use_endpoint_u = sp.use_endpoint_u
        new.use_cyclic_u = sp.use_cyclic_u
        new.resolution_u = sp.resolution_u
    curve.matrix_world = base.matrix_world.copy()
    return True

def remove(md):
    """Maya Remove: the node and its base wire go, the curve stays (curve1 kept, no BaseWire left)."""
    ob = md.id_data
    (curve, base) = (get(md, _dcc_source('Wire')), get(md, _dcc_source('Base Wire')))
    name = md.name
    ob.modifiers.remove(md)
    vg = ob.vertex_groups.get(name)
    if vg is not None:
        ob.vertex_groups.remove(vg)
    for loc in [o for o in bpy.data.objects if o.get(LOC_PROP) == f'{ob.name}|{name}']:
        bpy.data.objects.remove(loc, do_unlink=True)
    if base is not None and (not any((get(m, _dcc_source('Base Wire')) == base for o in bpy.data.objects for m in getattr(o, 'modifiers', ()) if is_wire(m)))):
        data = base.data
        bpy.data.objects.remove(base, do_unlink=True)
        if data is not None and data.users == 0:
            bpy.data.curves.remove(data)
    if curve is not None:
        names = [n for n in curve.get(WIRE_PROP, '').split(',') if n and n != name]
        if names:
            curve[WIRE_PROP] = ','.join(names)
        elif WIRE_PROP in curve:
            del curve[WIRE_PROP]

def locators(md):
    """[(param, percent)] in slot order (unused slots param 1, percent 1)."""
    return [(get(md, f'Locator {i} Param'), get(md, f'Locator {i} Percent')) for i in range(1, LOCATOR_SLOTS + 1)]

def add_locator(context, md, param, percent=1.0, envelope=1.0):
    """A Maya dropoff locator at curve parameter ``param`` (0..1 of the curve's range): an empty on the wire at that
    point whose ``percent`` (× envelope, Maya's locator envelope) scales the dropoff there. Returns the empty."""
    used = [(p, s) for (p, s) in locators(md) if p is not None and p < 1.0 - 1e-09]
    if len(used) >= LOCATOR_SLOTS:
        raise RuntimeError(f'A kit wire takes {LOCATOR_SLOTS} dropoff locators.')
    scale = 1.0 + float(envelope) * (float(percent) - 1.0)
    used.append((float(param), scale))
    used.sort()
    for i in range(1, LOCATOR_SLOTS + 1):
        (p, s) = used[i - 1] if i <= len(used) else (1.0, 1.0)
        set_(md, f'Locator {i} Param', p)
        set_(md, f'Locator {i} Percent', s)
    curve = get(md, _dcc_source('Wire'))
    from . import deformers
    loc = bpy.data.objects.new(deformers.new_name('locator'), None)
    loc.empty_display_type = 'PLAIN_AXES'
    context.view_layer.active_layer_collection.collection.objects.link(loc)
    if curve is not None:
        loc.location = point_at(curve, param)
        loc.parent = curve
        loc.matrix_parent_inverse = curve.matrix_world.inverted()
    loc[LOC_PROP] = f'{md.id_data.name}|{md.name}'
    loc['percent'] = float(percent)
    loc['param'] = float(param)
    return loc

def point_at(curve, fraction):
    """World point of ``curve`` at parameter fraction (first spline)."""
    from . import curves_maya, curves_math
    mc = curves_maya.read_spline(curve.data.splines[0], curve.matrix_world)
    full = curves_math.full(mc.knots)
    (lo, hi) = (full[mc.degree], full[len(mc.cvs)])
    return Vector(curves_math.evaluate(mc.cvs, mc.knots, mc.degree, lo + (hi - lo) * fraction, mc.weights))

def nearest_param(curve, world_point, samples=400):
    """Parameter fraction of the curve point nearest to ``world_point``."""
    best = None
    for i in range(samples + 1):
        f = i / samples
        dd = (point_at(curve, f) - world_point).length
        if best is None or dd < best[0]:
            best = (dd, f)
    return best[1]
