# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya Duplicate (Ctrl+D), Duplicate Special (Ctrl+Shift+D) and Duplicate with
Transform (Shift+D).

Maya ``duplicateSpecial`` factory options (copy,
count 1, group under Parent, T/R = 0, S = 1) and ``shiftD``
(``cmds.duplicate(smartTransform=True)``). Edit > Duplicate Special runs with
the saved options (DuplicateSpecial), no dialog; Blender's Adjust Last Operation
edits them afterwards. Maya duplicates the whole subtree; names count up (``pCube1`` -> ``pCube2``).
Plan: docs/steps/step_10.md 「계획」 5; Ctrl+D: docs/steps/step_19.md.
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy.props import EnumProperty, FloatVectorProperty, IntProperty
from mathutils import Euler, Quaternion, Vector
from .. import undo_steps
from . import naming, prim_history
from .freeze import hierarchy
from .group import make_group
PAIRS = {}

def selected_roots(objects):
    chosen = set(objects)
    out = []
    for ob in objects:
        p = ob.parent
        while p is not None and p not in chosen:
            p = p.parent
        if p is None:
            out.append(ob)
    return out

def copy_subtree(root, instance=False):
    """Copy ``root`` and its descendants (data copied, or shared for an instance)."""
    new_of = {}
    for ob in hierarchy([root]):
        new = ob.copy()
        if ob.data is not None and (not instance):
            new.data = ob.data.copy()
        if not instance:
            for idb in (new, new.data):
                for key in (prim_history.KEY, prim_history.PART):
                    if idb is not None and key in idb:
                        del idb[key]
        for coll in ob.users_collection:
            coll.objects.link(new)
        if ob is not root:
            new.parent = new_of[ob.parent]
        naming.apply_maya_name(new, naming.base_name(ob.name), rename_data=not instance)
        new_of[ob] = new
    return new_of[root]

def offset_channels(ob, k, translate, rotate, scale):
    """k-th copy: channels t + k*T, r + k*R, s * S^k (Maya cumulative offsets)."""
    ob.location = Vector(ob.location) + k * Vector(translate)
    q = Euler(tuple((k * a for a in rotate))).to_quaternion()
    if ob.rotation_mode == 'QUATERNION':
        ob.rotation_quaternion = q @ ob.rotation_quaternion
    elif ob.rotation_mode == 'AXIS_ANGLE':
        (angle, *axis) = ob.rotation_axis_angle
        (axis, angle) = (q @ Quaternion(axis, angle)).to_axis_angle()
        ob.rotation_axis_angle = (angle, *axis)
    else:
        ob.rotation_euler = tuple((a + k * b for (a, b) in zip(ob.rotation_euler, rotate)))
    ob.scale = tuple((a * b ** k for (a, b) in zip(ob.scale, scale)))

def _select(context, objects):
    for ob in context.selected_objects:
        ob.select_set(False)
    for ob in objects:
        ob.select_set(True)
    if objects:
        context.view_layer.objects.active = objects[-1]

def duplicate(context, instance=False):
    """Copy every selected root with its subtree in place, Maya names; returns the copies.
    Records source pairs so a following Shift+D repeats the move between them."""
    roots = selected_roots(context.selected_objects)
    (made, pairs) = ([], {})
    for root in roots:
        new = copy_subtree(root, instance)
        made.append(new)
        pairs[new.name] = root.name
    PAIRS.clear()
    PAIRS.update(pairs)
    _select(context, made)
    return made

class ALLSET_OT_duplicate(bpy.types.Operator):
    """Duplicate the selection in place with its children; copies are named the Maya way
    (pCube1 -> pCube2, pCubeShape2) and selected (Maya Edit > Duplicate, Ctrl+D)"""
    bl_translation_context = 'MWK:operators/duplicate.py:104'
    bl_idname = 'allset.duplicate'
    bl_label = _zh_native('Duplicate', 'MWK:operators/duplicate.py:104')
    bl_description = _zh_native('Duplicate the selection in place with its children; copies are named the Maya way\n(pCube1 -> pCube2, pCubeShape2) and selected (Maya Edit > Duplicate, Ctrl+D)', 'MWK:operators/duplicate.py:104')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        if not duplicate(context):
            self.report({'WARNING'}, _zh('Nothing selected', 'MWK:operators/duplicate.py:113'))
            return {'CANCELLED'}
        return {'FINISHED'}

@undo_steps.no_redo_panel
class ALLSET_OT_duplicate_special(bpy.types.Operator):
    """Duplicate with options: copies or instances, number of copies, offsets per
    copy, where to put them (Maya Edit > Duplicate Special)"""
    bl_translation_context = 'MWK:operators/duplicate.py:123'
    bl_idname = 'allset.duplicate_special'
    bl_label = _zh_native('Duplicate Special', 'MWK:operators/duplicate.py:123')
    bl_description = _zh_native('Duplicate with options: copies or instances, number of copies, offsets per\ncopy, where to put them (Maya Edit > Duplicate Special)', 'MWK:operators/duplicate.py:123')
    bl_options = {'REGISTER', 'UNDO'}
    geometry_type: EnumProperty(name=_zh_native('Geometry Type', 'MWK:operators/duplicate.py:126'), items=_zh_enum((('COPY', 'Copy', 'Copy the geometry'), ('INSTANCE', 'Instance', 'Share the geometry (Blender linked duplicate)')), 'MWK:operators/duplicate.py:126'), translation_context='MWK:operators/duplicate.py:126')
    group_under: EnumProperty(name=_zh_native('Group Under', 'MWK:operators/duplicate.py:130'), items=_zh_enum((('PARENT', 'Parent', 'Same parent as the original'), ('WORLD', 'World', 'At the top of the hierarchy'), ('NEW_GROUP', 'New Group', 'Under a new group')), 'MWK:operators/duplicate.py:130'), translation_context='MWK:operators/duplicate.py:130')
    translate: FloatVectorProperty(name=_zh_native('Translate', 'MWK:operators/duplicate.py:135'), subtype='TRANSLATION', unit='LENGTH', translation_context='MWK:operators/duplicate.py:135')
    rotate: FloatVectorProperty(name=_zh_native('Rotate', 'MWK:operators/duplicate.py:136'), subtype='EULER', unit='ROTATION', translation_context='MWK:operators/duplicate.py:136')
    scale: FloatVectorProperty(name=_zh_native('Scale', 'MWK:operators/duplicate.py:137'), default=(1.0, 1.0, 1.0), subtype='XYZ', translation_context='MWK:operators/duplicate.py:137')
    copies: IntProperty(name=_zh_native('Number of Copies', 'MWK:operators/duplicate.py:138'), default=1, min=1, soft_max=100, max=10000, translation_context='MWK:operators/duplicate.py:138')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        roots = selected_roots(context.selected_objects)
        if not roots:
            self.report({'WARNING'}, _zh('Nothing selected', 'MWK:operators/duplicate.py:147'))
            return {'CANCELLED'}
        (made, pairs) = ([], {})
        for root in roots:
            for k in range(1, self.copies + 1):
                new = copy_subtree(root, self.geometry_type == 'INSTANCE')
                offset_channels(new, k, self.translate, self.rotate, self.scale)
                made.append(new)
                if self.copies == 1:
                    pairs[new.name] = root.name
        context.view_layer.update()
        if self.group_under == 'WORLD':
            from .parenting import unparent
            unparent(made)
        elif self.group_under == 'NEW_GROUP':
            grp = make_group(context, made)
            made = [grp]
        PAIRS.clear()
        PAIRS.update(pairs)
        _select(context, made)
        return {'FINISHED'}

class ALLSET_OT_duplicate_with_transform(bpy.types.Operator):
    """Duplicate and repeat the transform between the last duplicate and its source,
    so repeated use builds an array (Maya Edit > Duplicate with Transform, Shift+D)"""
    bl_translation_context = 'MWK:operators/duplicate.py:174'
    bl_idname = 'allset.duplicate_with_transform'
    bl_label = _zh_native('Duplicate with Transform', 'MWK:operators/duplicate.py:174')
    bl_description = _zh_native('Duplicate and repeat the transform between the last duplicate and its source,\nso repeated use builds an array (Maya Edit > Duplicate with Transform, Shift+D)', 'MWK:operators/duplicate.py:174')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        roots = selected_roots(context.selected_objects)
        if not roots:
            self.report({'WARNING'}, _zh('Nothing selected', 'MWK:operators/duplicate.py:184'))
            return {'CANCELLED'}
        context.view_layer.update()
        (made, pairs) = ([], {})
        for ob in roots:
            src = bpy.data.objects.get(PAIRS.get(ob.name, ''))
            new = copy_subtree(ob)
            if src is not None and src is not ob:
                delta = ob.matrix_world @ src.matrix_world.inverted_safe()
                new.matrix_world = delta @ ob.matrix_world
            made.append(new)
            pairs[new.name] = ob.name
        PAIRS.clear()
        PAIRS.update(pairs)
        _select(context, made)
        return {'FINISHED'}
classes = (ALLSET_OT_duplicate, ALLSET_OT_duplicate_special, ALLSET_OT_duplicate_with_transform)
