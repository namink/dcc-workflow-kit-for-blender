# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya light / shadow linking on Blender light linking (docs/steps/step_179.md).

Maya 2022: every light illuminates and every object casts
shadows from every light by default; Lighting/Shading > Make / Break Light Links link / unlink every
selected light x selected object, and breaking a group breaks its whole hierarchy; a new object is linked to every
default light; a light whose Illuminates by Default is off (not in defaultLightSet) lights only the objects made links
with. Make / Break Shadow Links = the same for shadows. Select Objects Illuminated by Light / Shadowed by Light take the
*first* selected node, and select the transforms of the linked objects (no groups, no shapes, no sets), or nothing when
that node is not a light; Select Lights Illuminating / Shadowing Object do the reverse.

Blender 4.5 (Cycles probe, step_179.md): ``Object.light_linking.receiver_collection`` / ``blocker_collection`` of a
light; objects in it with link state EXCLUDE are not lit / cast no shadow while everything else is (an empty
collection = everything), and once any object is INCLUDE only the INCLUDE objects are. So:
- default light: a broken link = the object EXCLUDE in the light's collection, a made link = no entry;
- Illuminates by Default off (``Object.allset_illuminates_by_default``, Maya's light attribute): linked objects are
  INCLUDE, and the light itself is INCLUDE too as a placeholder (a light receives no light), so no links = nothing lit.
Collections: ``<light>_lightLinks`` / ``<light>_shadowLinks``, linked to no scene, fake user (Maya keeps the links on
its lightLinker node; delegated names).
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from .. import undo_steps
KINDS = {'LIGHT': ('receiver_collection', '_lightLinks'), 'SHADOW': ('blocker_collection', '_shadowLinks')}
RENDERABLE = {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'CURVES', 'POINTCLOUD', 'VOLUME', 'GREASEPENCIL'}

def is_light(ob):
    return ob is not None and ob.type == 'LIGHT'

def linkable(ob):
    return ob is not None and (ob.type in RENDERABLE or ob.type == 'EMPTY')

def illuminates_by_default(light):
    return bool(getattr(light, 'allset_illuminates_by_default', True))

def _collection(light, kind, create=False):
    (attr, suffix) = KINDS[kind]
    coll = getattr(light.light_linking, attr)
    if coll is None and create:
        coll = bpy.data.collections.new(light.name + suffix)
        coll.use_fake_user = True
        setattr(light.light_linking, attr, coll)
    return coll

def _entries(coll):
    """{object: link state} of a light linking collection."""
    if coll is None:
        return {}
    return {ob: co.light_linking.link_state for (ob, co) in zip(coll.objects, coll.collection_objects)}

def _set_entry(coll, ob, state):
    if state is None:
        if ob.name in coll.objects:
            coll.objects.unlink(ob)
        return
    if ob.name not in coll.objects:
        coll.objects.link(ob)
    idx = list(coll.objects).index(ob)
    coll.collection_objects[idx].light_linking.link_state = state

def linked(light, ob, kind='LIGHT'):
    """Maya ``cmds.lightlink(query=True)``: does ``light`` illuminate (kind LIGHT) / get shadows from (SHADOW)
    ``ob``."""
    ent = _entries(_collection(light, kind))
    includes = [o for (o, s) in ent.items() if s == 'INCLUDE']
    if includes:
        return ent.get(ob) == 'INCLUDE'
    if kind == 'LIGHT' and (not illuminates_by_default(light)):
        return False
    return ent.get(ob) != 'EXCLUDE'

def set_linked(light, ob, kind, on):
    """Make (``on``) or break the link of ``light`` and ``ob``."""
    exclusive = kind == 'LIGHT' and (not illuminates_by_default(light))
    if not exclusive and on and (_collection(light, kind) is None):
        return
    coll = _collection(light, kind, create=True)
    if exclusive:
        _set_entry(coll, light, 'INCLUDE')
        _set_entry(coll, ob, 'INCLUDE' if on else None)
    else:
        _set_entry(coll, ob, None if on else 'EXCLUDE')

def set_illuminates_by_default(light, value):
    """Maya Illuminates by Default (defaultLightSet membership): on = lights every object (light links cleared), off =
    lights only objects made links with — none right after switching (directionalLight1 links [] before the
    first Make, case not_default)."""
    if illuminates_by_default(light) == bool(value):
        return
    light['allset_illuminates_by_default'] = bool(value)
    coll = _collection(light, 'LIGHT', create=not value)
    if coll is not None:
        for o in list(coll.objects):
            coll.objects.unlink(o)
        if not value:
            _set_entry(coll, light, 'INCLUDE')

def hierarchy(objects):
    """The objects with all their descendants (Maya breaks / makes a group's whole hierarchy)."""
    (out, seen) = ([], set())
    for ob in objects:
        for o in (ob, *ob.children_recursive):
            if o.name not in seen and linkable(o):
                seen.add(o.name)
                out.append(o)
    return out

def split_selection(objects):
    lights = [o for o in objects if is_light(o)]
    others = [o for o in objects if not is_light(o) and linkable(o)]
    return (lights, others)

def link_selection(objects, kind, on):
    """Maya Make / Break Light Links (shadow links too): (lights, objects) changed."""
    (lights, others) = split_selection(objects)
    targets = hierarchy(others)
    for light in lights:
        for ob in targets:
            set_linked(light, ob, kind, on)
    return (lights, targets)

def objects_of(light, kind, scene):
    """Maya Select Objects Illuminated / Shadowed by Light: transforms of linked renderable objects (no groups)."""
    return [o for o in scene.objects if o.type in RENDERABLE and linked(light, o, kind)]

def lights_of(ob, kind, scene):
    return [o for o in scene.objects if is_light(o) and linked(o, ob, kind)]

def first_selected(context):
    """Maya reads the first node of the active list; Blender keeps no selection order, so the active object when it
    is selected, else the first selected one (delegated)."""
    ob = context.active_object
    sel = list(context.selected_objects)
    if ob is not None and ob in sel:
        return ob
    return sel[0] if sel else None

def _select_only(context, objects):
    for o in context.selected_objects:
        o.select_set(False)
    for o in objects:
        try:
            o.select_set(True)
        except RuntimeError:
            pass
    if objects:
        context.view_layer.objects.active = objects[0]
_KIND_ITEMS = [('LIGHT', _dcc_source('Light'), ''), ('SHADOW', _dcc_source('Shadow'), '')]

@undo_steps.no_redo_panel
class ALLSET_OT_light_link(bpy.types.Operator):
    """Make or break light (or shadow) links between the selected lights and the selected objects (Maya Make / Break
    Light Links, Make / Break Shadow Links)"""
    bl_translation_context = 'MWK:operators/light_links.py:182'
    bl_idname = 'allset.light_link'
    bl_label = _zh_native('Light Links', 'MWK:operators/light_links.py:182')
    bl_description = _zh_native('Make or break light (or shadow) links between the selected lights and the selected objects (Maya Make / Break\nLight Links, Make / Break Shadow Links)', 'MWK:operators/light_links.py:182')
    bl_options = {'REGISTER', 'UNDO'}
    kind: EnumProperty(items=_zh_enum(_KIND_ITEMS, 'MWK:operators/light_links.py:185'), default='LIGHT', options={'SKIP_SAVE'}, translation_context='MWK:operators/light_links.py:185')
    make: BoolProperty(default=True, options={'SKIP_SAVE'}, translation_context='MWK:operators/light_links.py:186')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        (lights, targets) = link_selection(list(context.selected_objects), self.kind, self.make)
        if not lights or not targets:
            self.report({'WARNING'}, _zh('Select at least one light and one object', 'MWK:operators/light_links.py:195'))
            return {'CANCELLED'}
        for ob in targets:
            ob.update_tag()
        for light in lights:
            light.update_tag()
        return {'FINISHED'}

@undo_steps.no_redo_panel
class ALLSET_OT_light_link_select(bpy.types.Operator):
    """Select the objects the first selected light illuminates / shadows, or the lights illuminating / shadowing the
    first selected object (Maya Select Objects Illuminated by Light ...)"""
    bl_translation_context = 'MWK:operators/light_links.py:209'
    bl_idname = 'allset.light_link_select'
    bl_label = _zh_native('Select by Light Links', 'MWK:operators/light_links.py:209')
    bl_description = _zh_native('Select the objects the first selected light illuminates / shadows, or the lights illuminating / shadowing the\nfirst selected object (Maya Select Objects Illuminated by Light ...)', 'MWK:operators/light_links.py:209')
    bl_options = {'REGISTER', 'UNDO'}
    kind: EnumProperty(items=_zh_enum(_KIND_ITEMS, 'MWK:operators/light_links.py:212'), default='LIGHT', options={'SKIP_SAVE'}, translation_context='MWK:operators/light_links.py:212')
    lights: BoolProperty(default=False, options={'SKIP_SAVE'}, description=_zh_native('Select lights (else objects)', 'MWK:operators/light_links.py:213'), translation_context='MWK:operators/light_links.py:213')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        first = first_selected(context)
        if first is None:
            return {'CANCELLED'}
        if self.lights:
            found = [] if is_light(first) else lights_of(first, self.kind, context.scene)
        else:
            found = objects_of(first, self.kind, context.scene) if is_light(first) else []
        _select_only(context, found)
        return {'FINISHED'}

class ALLSET_OT_light_link_toggle(bpy.types.Operator):
    """Make or break this link (Light Linking Editor)"""
    bl_translation_context = 'MWK:operators/light_links.py:234'
    bl_idname = 'allset.light_link_toggle'
    bl_label = _zh_native('Toggle Light Link', 'MWK:operators/light_links.py:234')
    bl_description = _zh_native('Make or break this link (Light Linking Editor)', 'MWK:operators/light_links.py:234')
    bl_options = {'INTERNAL', 'UNDO'}
    light: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:operators/light_links.py:237')
    target: StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:operators/light_links.py:238')
    kind: EnumProperty(items=_zh_enum(_KIND_ITEMS, 'MWK:operators/light_links.py:239'), default='LIGHT', options={'SKIP_SAVE'}, translation_context='MWK:operators/light_links.py:239')

    def execute(self, context):
        (light, ob) = (bpy.data.objects.get(self.light), bpy.data.objects.get(self.target))
        if light is None or ob is None:
            return {'CANCELLED'}
        on = not linked(light, ob, self.kind)
        for o in hierarchy([ob]):
            set_linked(light, o, self.kind, on)
        light.update_tag()
        ob.update_tag()
        for area in context.screen.areas:
            area.tag_redraw()
        return {'FINISHED'}
classes = (ALLSET_OT_light_link, ALLSET_OT_light_link_select, ALLSET_OT_light_link_toggle)

def _ibd_get(self):
    return bool(self.get('allset_illuminates_by_default', True))

def _ibd_set(self, value):
    set_illuminates_by_default(self, value)

def register_props():
    bpy.types.Object.allset_illuminates_by_default = BoolProperty(name=_zh_native('Illuminates by Default', 'MWK:operators/light_links.py:267'), description=_zh_native('The light lights every object unless a link is broken (Maya Illuminates by Default); off: only the objects linked to it', 'MWK:operators/light_links.py:267'), get=_ibd_get, set=_ibd_set, translation_context='MWK:operators/light_links.py:267')

def unregister_props():
    del bpy.types.Object.allset_illuminates_by_default
