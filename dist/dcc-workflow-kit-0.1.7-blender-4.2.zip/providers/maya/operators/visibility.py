# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya object visibility keys: h, Ctrl+H, Alt+H, Shift+H, Ctrl+Shift+H.

Maya default hotkeys: h toggles the visibility of the
selection and keeps it selected; Ctrl+H hides the selection, Alt+H the rest;
Shift+H shows the selected hidden objects; Ctrl+Shift+H shows what was hidden last.

Maya's ``visibility`` attribute is ``Object.hide_viewport`` (per object, keyable; the Channel
Box Visibility row reads the same flag): h, Display > Hide / Show and the Channel Box write one
attribute (docs/steps/step_129_cb.md 「계획」 #26). A display layer's V uses the view-layer flag
(``hide_set``) instead, so it never changes this attribute.

A hidden object can't stay selected in Blender, so Maya's "hidden but still selected" is kept
as an ID property on the object (``KEPT``). ``LAST`` marks what the latest hide of this
operator hid. Plan: docs/steps/step_16.md 2.

Step 162: Toggle Show/Hide (h) follows Maya's "Toggle Visibility Options" (optionVar
toggleVisibilityAndKeepSelectionBehaviour): the toggled set is
the selection = the visible selected objects plus the hidden-but-selected ones (``KEPT``). First Selection Independent
(factory, 1) flips each object; Dependent (2) gives every one the opposite of the first selected object's visibility.
The saved window value (option_windows.saved("toggle_show_hide")) applies to h and the menu click alike.
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy.props import EnumProperty
from .. import undo_steps
TOGGLE_KEY = 'toggle_show_hide'
KEPT = 'allset_kept'
LAST = 'allset_last_hidden'
ACTIONS = (('TOGGLE', _dcc_source('Toggle Visibility'), _dcc_source('Maya h: hide the selection and keep it selected, or show it again')), ('HIDE', _dcc_source('Hide Selection'), 'Maya Ctrl+H'), ('HIDE_UNSELECTED', _dcc_source('Hide Unselected Objects'), 'Maya Alt+H'), ('SHOW_SELECTED', _dcc_source('Show Selected Objects'), 'Maya Shift+H'), ('SHOW_LAST', _dcc_source('Show Last Hidden'), 'Maya Ctrl+Shift+H'), ('SHOW_ALL', _dcc_source('Show All'), _dcc_source('Maya Display > Show > All: every object whose visibility is off')))

def _clear(objects, key):
    for ob in objects:
        if key in ob:
            del ob[key]

def _hide(objects, all_objects, kept=False):
    """Hide ``objects``; they become the "last hidden" set (and the kept selection)."""
    _clear(all_objects, LAST)
    if kept:
        _clear(all_objects, KEPT)
    for ob in objects:
        ob.hide_viewport = True
        try:
            ob.select_set(False)
        except RuntimeError:
            pass
        ob[LAST] = True
        if kept:
            ob[KEPT] = True
    return len(objects)

def _show(objects, view_layer, select=True):
    shown = 0
    for ob in objects:
        ob.hide_viewport = False
        for key in (KEPT, LAST):
            if key in ob:
                del ob[key]
        if not select:
            shown += 1
            continue
        try:
            ob.select_set(True)
        except RuntimeError:
            continue
        view_layer.objects.active = view_layer.objects.active or ob
        shown += 1
    return shown

def toggle_dependent():
    """The saved First Selection of Maya's Toggle Visibility Options: True = Dependent (factory Independent)."""
    from . import option_windows
    v = option_windows.saved(TOGGLE_KEY) or {}
    return v.get('first_selection') == _dcc_source('Dependent')

def _first(objects, active):
    from .mesh_maya import _first_selected
    return _first_selected(objects, active)

def toggle(context, dependent=False):
    """Maya Toggle Visibility (h) on the selection (visible selected + hidden kept). Returns the count."""
    vl = context.view_layer
    objs = list(vl.objects)
    selected = [ob for ob in objs if ob.visible_get() and ob.select_get()]
    kept = [ob for ob in objs if ob.hide_viewport and KEPT in ob]
    members = selected + [ob for ob in kept if ob not in selected]
    if not members:
        return 0
    if dependent:
        first = _first(members, vl.objects.active if vl.objects.active in members else None)
        show = first.hide_viewport
        to_hide = [] if show else members
        to_show = members if show else []
    else:
        to_hide = [ob for ob in members if not ob.hide_viewport]
        to_show = [ob for ob in members if ob.hide_viewport]
    if to_hide:
        _hide(to_hide, objs, kept=True)
    if to_show:
        _show([ob for ob in to_show if ob.hide_viewport], vl)
    return len(members)

def apply(context, action, dependent=None):
    """Run ``action`` on the view layer; returns the number of objects changed."""
    vl = context.view_layer
    objs = list(vl.objects)
    selected = [ob for ob in objs if ob.visible_get() and ob.select_get()]
    hidden = [ob for ob in objs if ob.hide_viewport]
    if action == 'TOGGLE':
        return toggle(context, toggle_dependent() if dependent is None else dependent)
    if action == 'HIDE':
        return _hide(selected, objs)
    if action == 'HIDE_UNSELECTED':
        from .dag import hierarchy
        keep = {o.session_uid for o in hierarchy(selected)}
        for ob in selected:
            p = ob.parent
            while p is not None:
                keep.add(p.session_uid)
                p = p.parent
        return _hide([ob for ob in objs if ob.visible_get() and (not ob.select_get()) and (ob.session_uid not in keep)], objs)
    if action == 'SHOW_SELECTED':
        act = vl.objects.active
        return _show([ob for ob in hidden if KEPT in ob or ob == act], vl)
    if action == 'SHOW_LAST':
        return _show([ob for ob in hidden if LAST in ob], vl)
    if action == 'SHOW_ALL':
        return _show(hidden, vl, select=False)
    raise ValueError(action)

@undo_steps.no_redo_panel
class ALLSET_OT_visibility(bpy.types.Operator):
    """Maya object visibility (h, Ctrl+H, Alt+H, Shift+H, Ctrl+Shift+H)"""
    bl_translation_context = 'MWK:operators/visibility.py:159'
    bl_idname = 'allset.visibility'
    bl_label = _zh_native('Maya Visibility', 'MWK:operators/visibility.py:159')
    bl_description = _zh_native('Maya object visibility (h, Ctrl+H, Alt+H, Shift+H, Ctrl+Shift+H)', 'MWK:operators/visibility.py:159')
    bl_options = {'REGISTER', 'UNDO'}
    action: EnumProperty(name=_zh_native('Action', 'MWK:operators/visibility.py:162'), items=_zh_enum(ACTIONS, 'MWK:operators/visibility.py:162'), default='TOGGLE', translation_context='MWK:operators/visibility.py:162')
    behaviour: EnumProperty(name=_zh_native('First Selection', 'MWK:operators/visibility.py:164'), options={'SKIP_SAVE', 'HIDDEN'}, default='SAVED', items=_zh_enum((('SAVED', 'Saved', ''), ('INDEPENDENT', 'Independent', ''), ('DEPENDENT', 'Dependent', '')), 'MWK:operators/visibility.py:164'), translation_context='MWK:operators/visibility.py:164')

    @classmethod
    def description(cls, context, props):
        return _zh(dict(((a[0], a[2]) for a in ACTIONS))[props.action], 'MWK:operators/visibility.py:169')

    @classmethod
    def poll(cls, context):
        return context.view_layer is not None and context.mode == 'OBJECT'

    def execute(self, context):
        vl = context.view_layer
        had_selection = any((ob.visible_get() and ob.select_get() for ob in vl.objects))
        changed = apply(context, self.action, None if self.behaviour == 'SAVED' else self.behaviour == 'DEPENDENT')
        from . import dag
        dag.sync(context.scene, vl)
        text = message(self.action, had_selection, changed)
        if text:
            from ..ui import view_message
            view_message.show(context, text)
        return {'FINISHED'}

def message(action, had_selection, changed):
    """Maya's in-view message for a visibility action, or None (Maya's Hide / Toggle
    Visibility messages)."""
    if action == 'HIDE':
        if had_selection:
            return 'Selection <hl>hidden</hl>.\nTo show it again, select it in the Outliner and press <hl>Shift+H</hl>.'
        return _dcc_source('Nothing is selected to hide.')
    if action == 'HIDE_UNSELECTED':
        if changed:
            return 'Unselected objects <hl>hidden</hl>.\nTo show them, select them in the Outliner and press <hl>Shift+H</hl>.'
        return _dcc_source('No unselected objects to hide.')
    if action == 'TOGGLE' and (not changed):
        return _dcc_source('Nothing selected to toggle.')
    return None
classes = (ALLSET_OT_visibility,)
