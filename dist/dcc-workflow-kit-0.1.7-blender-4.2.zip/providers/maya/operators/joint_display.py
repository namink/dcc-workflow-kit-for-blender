# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Joint display with Maya's controls (step 248, Issue #165): the Channel Box Radius row, Display > Transform Display >
Local Rotation Axes, Display > Animation > Joint Size... (RIG_UPGRADE_PLAN "Joint display / Channel Box" row).

- Radius = the Maya joint radius the kit keeps on each bone (``joints.RADIUS``, Maya units; a joint without one reads
  Maya's default 1). It sizes the joint's click sphere (``joints.joint_sphere_radius``).
- Joint Size = Maya's scene-wide jointDisplayScale (factory 1) as ``Scene.allset_joint_size``: it scales every joint's
  click sphere. Blender draws a bone's size from its length only, so the drawn joints keep their size (delegated,
  docs/steps/step_248.md).
- Local Rotation Axes: Maya toggles the selected nodes' displayLocalAxis. Blender shows bone axes per skeleton
  (``Armature.show_axes``) and object axes per object (``Object.show_axis``).
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy.props import FloatProperty
from .. import results
from . import joints
JOINT_SIZE = 'allset_joint_size'
MAYA_RADIUS = 1.0

def _get_radius(bone):
    return float(bone.get(joints.RADIUS, MAYA_RADIUS))

def _set_radius(bone, value):
    bone[joints.RADIUS] = max(0.0, float(value))

class ALLSET_OT_local_rotation_axes(bpy.types.Operator):
    """Maya Display > Transform Display > Local Rotation Axes: show / hide the axes of the selected joints or objects"""
    bl_translation_context = 'MWK:operators/joint_display.py:37'
    bl_idname = 'allset.local_rotation_axes'
    bl_label = _zh_native('Local Rotation Axes', 'MWK:operators/joint_display.py:37')
    bl_description = _zh_native('Maya Display > Transform Display > Local Rotation Axes: show / hide the axes of the selected joints or objects', 'MWK:operators/joint_display.py:37')
    bl_options = {'UNDO'}

    def execute(self, context):
        ob = context.active_object
        if ob is not None and ob.type == 'ARMATURE' and (ob.mode in {'POSE', 'EDIT'}):
            arms = [o for o in getattr(context, 'objects_in_mode', None) or [ob] if o.type == 'ARMATURE']
            on = not ob.data.show_axes
            for arm in arms:
                arm.data.show_axes = on
            results.result(self, _zh(f"Joint axes {('on' if on else 'off')}", 'MWK:operators/joint_display.py:47'))
            return {'FINISHED'}
        obs = list(context.selected_objects) or ([ob] if ob is not None else [])
        if not obs:
            self.report({'WARNING'}, _zh('Select objects or joints', 'MWK:operators/joint_display.py:51'))
            return {'CANCELLED'}
        on = not (ob.show_axis if ob is not None else obs[0].show_axis)
        for o in obs:
            o.show_axis = on
        results.result(self, _zh(f"Local rotation axes {('on' if on else 'off')}", 'MWK:operators/joint_display.py:56'))
        return {'FINISHED'}

class ALLSET_OT_joint_size(bpy.types.Operator):
    """Maya Display > Animation > Joint Size: the scene's joint display scale (sizes the joints' click spheres)"""
    bl_translation_context = 'MWK:operators/joint_display.py:63'
    bl_idname = 'allset.joint_size'
    bl_label = _zh_native('Joint Display Scale', 'MWK:operators/joint_display.py:63')
    bl_description = _zh_native("Maya Display > Animation > Joint Size: the scene's joint display scale (sizes the joints' click spheres)", 'MWK:operators/joint_display.py:63')
    bl_options = {'UNDO'}
    size: FloatProperty(name=_zh_native('Joint Size', 'MWK:operators/joint_display.py:66'), default=1.0, min=0.01, max=100.0, soft_max=10.0, translation_context='MWK:operators/joint_display.py:66')

    def invoke(self, context, event):
        self.size = getattr(context.scene, JOINT_SIZE, 1.0)
        return context.window_manager.invoke_props_dialog(self, width=300, confirm_text=_zh('Close', 'MWK:operators/joint_display.py:70'))

    def draw(self, context):
        self.layout.prop(self, 'size')
        self.layout.label(text=_zh('Blender draws joints by bone length: this sizes where a click picks them.', 'MWK:operators/joint_display.py:74'))

    def execute(self, context):
        setattr(context.scene, JOINT_SIZE, self.size)
        results.result(self, _zh(f'Joint Size {self.size:g}', 'MWK:operators/joint_display.py:78'))
        return {'FINISHED'}
classes = (ALLSET_OT_local_rotation_axes, ALLSET_OT_joint_size)

def register_props():
    bpy.types.Bone.allset_joint_radius = FloatProperty(name=_zh_native('Radius', 'MWK:operators/joint_display.py:86'), description=_zh_native("Maya joint radius (sizes the joint's click sphere)", 'MWK:operators/joint_display.py:86'), min=0.0, soft_max=100.0, get=_get_radius, set=_set_radius, translation_context='MWK:operators/joint_display.py:86')
    bpy.types.Scene.allset_joint_size = FloatProperty(name=_zh_native('Joint Size', 'MWK:operators/joint_display.py:89'), description=_zh_native('Maya joint display scale', 'MWK:operators/joint_display.py:89'), default=1.0, min=0.01, max=100.0, translation_context='MWK:operators/joint_display.py:89')

def unregister_props():
    for (owner, name) in ((bpy.types.Bone, 'allset_joint_radius'), (bpy.types.Scene, 'allset_joint_size')):
        if hasattr(owner, name):
            delattr(owner, name)
