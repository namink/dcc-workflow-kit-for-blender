# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya Modify > Align: Snap Align Objects, Snap Together Tool, Make Live, Match
Transformations (docs/steps/step_59.md 「계획」 4).

Maya 2022:

- S9 Point to Point: the object owning the first point moves (no rotation) so that point
  lands on the last one.
- S10/S11 2 / 3 Points to 2 / 3 Points: move + rotate so the points line up (first on first,
  the rest give the direction / plane).
- S11 Align Objects (factory options): world X only, mid, to the average.
- S12 Snap Together Tool: click a surface point on the object to move, then a point on the
  target: the object moves there and turns so the two normals face each other.
- S13 Make Live: a live surface the moves snap onto; "No Live Surface" in the Status Line.

Points: in object mode the pivots (Blender origins) of the selected objects, the active
one (Maya's last selected) being the target; in mesh edit mode each mesh's selected
vertices in selection order (``select_history``), the active object's being the target.
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import math
import bmesh
import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, PointerProperty
from bpy_extras import view3d_utils
from mathutils import Matrix, Vector
from .. import results
EPS = 1e-09

def _frame(points):
    """Orthonormal frame (3x3, columns) of 2 or 3 points: X along p0->p1, Z = plane normal."""
    x = points[1] - points[0]
    if x.length < EPS:
        return None
    x = x.normalized()
    if len(points) > 2:
        z = x.cross(points[2] - points[0])
        if z.length < EPS:
            z = None
        else:
            z = z.normalized()
    else:
        z = None
    if z is None:
        helper = Vector((0, 0, 1)) if abs(x.z) < 0.9 else Vector((0, 1, 0))
        z = x.cross(helper).cross(x).normalized()
        z = -z if z.dot(helper) < 0 else z
    y = z.cross(x).normalized()
    return Matrix((x, y, z)).transposed()

def points_transform(src, dst):
    """World matrix that takes ``src`` points onto ``dst`` (1: move, 2: move + aim, 3: + plane)."""
    n = min(len(src), len(dst))
    if n == 0:
        return Matrix.Identity(4)
    if n == 1:
        return Matrix.Translation(dst[0] - src[0])
    (fs, fd) = (_frame(src[:n]), _frame(dst[:n]))
    if fs is None or fd is None:
        return Matrix.Translation(dst[0] - src[0])
    if n == 2:
        a = (src[1] - src[0]).normalized()
        b = (dst[1] - dst[0]).normalized()
        rot = a.rotation_difference(b).to_matrix()
    else:
        rot = fd @ fs.transposed()
    m = rot.to_4x4()
    return Matrix.Translation(dst[0]) @ m @ Matrix.Translation(-src[0])

def bbox_world(ob):
    corners = [ob.matrix_world @ Vector(c) for c in ob.bound_box]
    lo = Vector(tuple((min((c[i] for c in corners)) for i in range(3))))
    hi = Vector(tuple((max((c[i] for c in corners)) for i in range(3))))
    return (lo, hi)

def _ordered_verts(ob):
    bm = bmesh.from_edit_mesh(ob.data)
    hist = [e for e in bm.select_history if isinstance(e, bmesh.types.BMVert)]
    rest = [v for v in bm.verts if v.select and v not in hist]
    return [ob.matrix_world @ v.co for v in hist + rest]

def point_sets(context):
    """(movers [(object, points)], target points) or None."""
    active = context.view_layer.objects.active
    if context.mode == 'EDIT_MESH':
        obs = [ob for ob in context.objects_in_mode_unique_data if ob.type == 'MESH']
        target = [ob for ob in obs if ob == active]
        movers = [ob for ob in obs if ob != active]
        if not target or not movers:
            return None
        return ([(ob, _ordered_verts(ob)) for ob in movers], _ordered_verts(target[0]))
    sel = [ob for ob in context.selected_objects]
    if active is None or active not in sel or len(sel) < 2:
        return None
    return ([(ob, [ob.matrix_world.translation.copy()]) for ob in sel if ob != active], [active.matrix_world.translation.copy()])

def snap_points(context, count):
    """Snap Align Objects > Point to Point / 2 Points / 3 Points. Returns the moved count."""
    sets = point_sets(context)
    if sets is None:
        return 0
    (movers, target) = sets
    done = 0
    for (ob, pts) in movers:
        n = min(count, len(pts), len(target))
        if n == 0:
            continue
        m = points_transform(pts[:n], target[:n])
        if ob.parent is None or ob.parent not in [o for (o, _p) in movers]:
            ob.matrix_world = m @ ob.matrix_world
            done += 1
    return done

def align_objects(context, axes=(True, False, False), mode='MID'):
    """Snap Align Objects > Align Objects with Maya's factory options (S11): along world
    ``axes``, the bounding boxes' min / mid / max lined up at their average."""
    obs = list(context.selected_objects)
    if len(obs) < 2:
        return 0
    boxes = {ob: bbox_world(ob) for ob in obs}

    def key(bb, i):
        (lo, hi) = bb
        return lo[i] if mode == 'MIN' else hi[i] if mode == 'MAX' else (lo[i] + hi[i]) / 2
    for (i, on) in enumerate(axes):
        if not on:
            continue
        avg = sum((key(bb, i) for bb in boxes.values())) / len(obs)
        for (ob, bb) in boxes.items():
            d = Vector((0, 0, 0))
            d[i] = avg - key(bb, i)
            ob.matrix_world = Matrix.Translation(d) @ ob.matrix_world
    return len(obs)
_BONE_TO_OBJECT = Matrix.Rotation(math.pi / 2, 4, 'Z')

def _maya_frame(node):
    """World matrix of ``node`` (Object / PoseBone) in an object's axis convention (Maya Match compares Maya axes)."""
    if isinstance(node, bpy.types.PoseBone):
        return node.id_data.matrix_world @ node.matrix @ _BONE_TO_OBJECT
    return node.matrix_world.copy()

def _set_maya_frame(node, m):
    if isinstance(node, bpy.types.PoseBone):
        node.matrix = node.id_data.matrix_world.inverted_safe() @ m @ _BONE_TO_OBJECT.inverted()
    else:
        node.matrix_world = m

def match_lead(context):
    """(lead, others) of Maya Match Transformations: the last selected node is the lead. A joint lead = the active pose
    bone in pose mode (decision 16: picking a joint enters Pose mode, the objects picked before stay selected), or the
    active bone of an active armature in object mode (step 226 L3, ATTACH_PLAN L3 (a))."""
    lead = context.view_layer.objects.active
    if lead is None:
        return (None, [])
    others = [ob for ob in context.selected_objects if ob is not lead]
    if lead.type == 'ARMATURE' and lead.pose is not None:
        pb = None
        if lead.mode == 'POSE':
            pb = context.active_pose_bone
            others += [b for b in context.selected_pose_bones or () if b != pb and b.id_data == lead]
        elif lead.data.bones.active is not None:
            pb = lead.pose.bones.get(lead.data.bones.active.name)
        if pb is not None:
            return (pb, others)
    return (lead, others)

def match_transform(context, translate=True, rotate=True, scale=True):
    (lead, others) = match_lead(context)
    if lead is None or not others:
        return 0
    (lt, lr, ls) = _maya_frame(lead).decompose()
    for node in others:
        (t, r, s) = _maya_frame(node).decompose()
        _set_maya_frame(node, Matrix.LocRotScale(lt if translate else t, lr if rotate else r, ls if scale else s))
        if isinstance(node, bpy.types.PoseBone):
            context.view_layer.update()
    return len(others)

class _ObjOp:
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode in ('OBJECT', 'EDIT_MESH')

class ALLSET_OT_snap_points(_ObjOp, bpy.types.Operator):
    """Move (and turn) the first selected object so its points land on the last selected
    object's points (Maya Modify > Snap Align Objects > Point to Point / 2 / 3 Points)"""
    bl_translation_context = 'MWK:operators/snap_align.py:221'
    bl_idname = 'allset.snap_points'
    bl_label = _zh_native('Snap Points', 'MWK:operators/snap_align.py:221')
    bl_description = _zh_native("Move (and turn) the first selected object so its points land on the last selected\nobject's points (Maya Modify > Snap Align Objects > Point to Point / 2 / 3 Points)", 'MWK:operators/snap_align.py:221')
    count: IntProperty(name=_zh_native('Points', 'MWK:operators/snap_align.py:223'), default=1, min=1, max=3, translation_context='MWK:operators/snap_align.py:223')

    @classmethod
    def description(cls, context, props):
        return _zh({1: 'Point to Point: move the object so its point lands on the target point', 2: '2 Points to 2 Points: move and turn so two points line up', 3: '3 Points to 3 Points: move and turn so three points line up'}[props.count], 'MWK:operators/snap_align.py:227')

    def execute(self, context):
        n = snap_points(context, self.count)
        if not n:
            self.report({'WARNING'}, _zh('Select points on the object to move, then on the target (last)', 'MWK:operators/snap_align.py:234'))
            return {'CANCELLED'}
        return {'FINISHED'}

class ALLSET_OT_align_objects(bpy.types.Operator):
    """Line the selected objects up along world X at the middle of their bounding boxes
    (Maya Modify > Snap Align Objects > Align Objects, factory options)"""
    bl_translation_context = 'MWK:operators/snap_align.py:243'
    bl_idname = 'allset.align_objects'
    bl_label = _zh_native('Align Objects', 'MWK:operators/snap_align.py:243')
    bl_description = _zh_native('Line the selected objects up along world X at the middle of their bounding boxes\n(Maya Modify > Snap Align Objects > Align Objects, factory options)', 'MWK:operators/snap_align.py:243')
    bl_options = {'REGISTER', 'UNDO'}
    mode: EnumProperty(name=_zh_native('Align Mode', 'MWK:operators/snap_align.py:246'), items=_zh_enum((('MIN', 'Min', ''), ('MID', 'Mid', ''), ('MAX', 'Max', '')), 'MWK:operators/snap_align.py:246'), default='MID', translation_context='MWK:operators/snap_align.py:246')
    axis_x: BoolProperty(name=_zh_native('World X', 'MWK:operators/snap_align.py:248'), default=True, translation_context='MWK:operators/snap_align.py:248')
    axis_y: BoolProperty(name=_zh_native('World Y', 'MWK:operators/snap_align.py:249'), default=False, translation_context='MWK:operators/snap_align.py:249')
    axis_z: BoolProperty(name=_zh_native('World Z', 'MWK:operators/snap_align.py:250'), default=False, translation_context='MWK:operators/snap_align.py:250')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        if not align_objects(context, (self.axis_x, self.axis_y, self.axis_z), self.mode):
            self.report({'WARNING'}, _zh('Select two or more objects', 'MWK:operators/snap_align.py:258'))
            return {'CANCELLED'}
        return {'FINISHED'}

class ALLSET_OT_match_transform(bpy.types.Operator):
    """Match the transforms of the selected objects to the last selected one
    (Maya Modify > Match Transformations)"""
    bl_translation_context = 'MWK:operators/snap_align.py:267'
    bl_idname = 'allset.match_transform'
    bl_label = _zh_native('Match Transformations', 'MWK:operators/snap_align.py:267')
    bl_description = _zh_native('Match the transforms of the selected objects to the last selected one\n(Maya Modify > Match Transformations)', 'MWK:operators/snap_align.py:267')
    bl_options = {'REGISTER', 'UNDO'}
    kind: EnumProperty(items=_zh_enum((('ALL', 'All Transforms', ''), ('TRANSLATE', 'Translation', ''), ('ROTATE', 'Rotation', ''), ('SCALE', 'Scaling', '')), 'MWK:operators/snap_align.py:270'), default='ALL', translation_context='MWK:operators/snap_align.py:270')

    @classmethod
    def poll(cls, context):
        return context.mode in ('OBJECT', 'POSE')

    def execute(self, context):
        k = self.kind
        n = match_transform(context, k in ('ALL', 'TRANSLATE'), k in ('ALL', 'ROTATE'), k in ('ALL', 'SCALE'))
        if not n:
            self.report({'WARNING'}, _zh('Select the objects, then the target last', 'MWK:operators/snap_align.py:281'))
            return {'CANCELLED'}
        return {'FINISHED'}

def make_live(context, ob):
    ts = context.scene.tool_settings
    context.scene.allset_live = ob
    elements = set(ts.snap_elements)
    if ob is not None:
        ts.snap_elements = elements | {'FACE_PROJECT'}
        ts.use_snap = True
        ts.use_snap_align_rotation = False
    else:
        elements.discard('FACE_PROJECT')
        if elements:
            ts.snap_elements = elements
        if not elements or elements == {'INCREMENT'}:
            ts.use_snap = False
    for area in context.screen.areas if context.screen else ():
        area.tag_redraw()

class ALLSET_OT_make_live(bpy.types.Operator):
    """Make the selected surface live: moves snap onto it. With nothing selected the live
    surface is cleared (Maya Modify > Make Live)"""
    bl_translation_context = 'MWK:operators/snap_align.py:310'
    bl_idname = 'allset.make_live'
    bl_label = _zh_native('Make Live', 'MWK:operators/snap_align.py:310')
    bl_description = _zh_native('Make the selected surface live: moves snap onto it. With nothing selected the live\nsurface is cleared (Maya Modify > Make Live)', 'MWK:operators/snap_align.py:310')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        ob = context.view_layer.objects.active
        if ob is not None and (not ob.select_get() or ob.type != 'MESH'):
            ob = None
        make_live(context, ob)
        results.result(self, _zh(f'Live surface: {ob.name}' if ob else 'No Live Surface', 'MWK:operators/snap_align.py:322'))
        from ..ui import view_message
        view_message.show(context, f'{ob.name} is <hl>live</hl>.' if ob else 'Make Live is <hl>off</hl>.', 'TOP_CENTER')
        return {'FINISHED'}

def surface_hit(context, region, rv3d, coord):
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    depsgraph = context.evaluated_depsgraph_get()
    (ok, loc, normal, _i, ob, _m) = context.scene.ray_cast(depsgraph, origin, direction)
    if not ok:
        return None
    return (ob.original if hasattr(ob, 'original') else ob, loc, normal.normalized())

def snap_together_matrix(src_point, src_normal, dst_point, dst_normal, orient=True):
    """World matrix that puts ``src_point`` on ``dst_point`` with the normals facing each other."""
    if not orient:
        return Matrix.Translation(dst_point - src_point)
    rot = src_normal.rotation_difference(-dst_normal).to_matrix().to_4x4()
    return Matrix.Translation(dst_point) @ rot @ Matrix.Translation(-src_point)

class ALLSET_OT_snap_together(bpy.types.Operator):
    """Click a point on the object to move, then a point on the target: the object moves
    there and turns so the surfaces face each other (Maya Modify > Snap Together Tool)"""
    bl_translation_context = 'MWK:operators/snap_align.py:354'
    bl_idname = 'allset.snap_together'
    bl_label = _zh_native('Snap Together Tool', 'MWK:operators/snap_align.py:354')
    bl_description = _zh_native('Click a point on the object to move, then a point on the target: the object moves\nthere and turns so the surfaces face each other (Maya Modify > Snap Together Tool)', 'MWK:operators/snap_align.py:354')
    bl_options = {'UNDO'}
    set_orientation: BoolProperty(name=_zh_native('Set Orientation', 'MWK:operators/snap_align.py:357'), default=True, translation_context='MWK:operators/snap_align.py:357')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def _view(self, context, event):
        for area in context.window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            for region in area.regions:
                if region.type == 'WINDOW' and region.x <= event.mouse_x < region.x + region.width and (region.y <= event.mouse_y < region.y + region.height):
                    return (area, region, region.data)
        return (None, None, None)

    def invoke(self, context, event):
        self._first = None
        context.window_manager.modal_handler_add(self)
        context.workspace.status_text_set(_dcc_source('Snap Together Tool: click a point on the object to move (Esc / right-click: cancel)'))
        return {'RUNNING_MODAL'}

    def _end(self, context):
        context.workspace.status_text_set(None)

    def modal(self, context, event):
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            self._end(context)
            return {'CANCELLED'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            (area, region, rv3d) = self._view(context, event)
            if region is None or rv3d is None:
                return {'PASS_THROUGH'}
            coord = (event.mouse_x - region.x, event.mouse_y - region.y)
            hit = surface_hit(context, region, rv3d, coord)
            if hit is None:
                return {'RUNNING_MODAL'}
            if self._first is None:
                self._first = hit
                context.workspace.status_text_set(f'Snap Together Tool: now click the target point (moving {hit[0].name})')
                return {'RUNNING_MODAL'}
            (ob, p0, n0) = self._first
            (_ob1, p1, n1) = hit
            m = snap_together_matrix(p0, n0, p1, n1, self.set_orientation)
            ob.matrix_world = m @ ob.matrix_world
            self._end(context)
            return {'FINISHED'}
        return {'PASS_THROUGH'} if event.type.startswith(('WHEEL', 'MIDDLEMOUSE', 'MOUSEMOVE', 'TRACKPAD')) or event.alt else {'RUNNING_MODAL'}
classes = (ALLSET_OT_snap_points, ALLSET_OT_align_objects, ALLSET_OT_match_transform, ALLSET_OT_make_live, ALLSET_OT_snap_together)

def register_props():
    bpy.types.Scene.allset_live = PointerProperty(type=bpy.types.Object, name=_zh_native('Live Surface', 'MWK:operators/snap_align.py:415'), description=_zh_native('Maya live surface: moves snap onto it (Modify > Make Live)', 'MWK:operators/snap_align.py:415'), translation_context='MWK:operators/snap_align.py:415')

def unregister_props():
    del bpy.types.Scene.allset_live
STEP_FLAGS = {'TRANSLATE': 'use_snap_translate', 'ROTATE': 'use_snap_rotate', 'RESIZE': 'use_snap_scale'}
MAYA_ROTATE_STEP = 0.2617993877991494
STEP_PROP = 'allset_step_snap'
OTHER_SNAPS = ('GRID', 'VERTEX', 'EDGE', 'FACE', 'FACE_PROJECT', 'FACE_NEAREST', 'VOLUME', 'EDGE_MIDPOINT', 'EDGE_PERPENDICULAR')

def _record(ts):
    scene = ts.id_data
    return dict(scene.get(STEP_PROP, {})) if scene is not None else {}

def _store(ts, rec):
    if ts.id_data is not None:
        ts.id_data[STEP_PROP] = rec

def step_snap_mode(ts, kind):
    """'OFF' / 'RELATIVE' / 'ABSOLUTE' for the tool ``kind`` (Maya Step Snap)."""
    if not (ts.use_snap and 'INCREMENT' in ts.snap_elements and getattr(ts, STEP_FLAGS[kind])):
        return 'OFF'
    own = _record(ts).get(kind)
    if own in ('OFF', 'RELATIVE', 'ABSOLUTE'):
        return own
    return 'ABSOLUTE' if ts.use_snap_grid_absolute else 'RELATIVE'
TOOL_KINDS = {'builtin.move': 'TRANSLATE', 'builtin.rotate': 'ROTATE', 'builtin.scale': 'RESIZE'}

def absolute_offered(scene, kind):
    """Maya offers Move's Absolute step snap only while its axis orientation is World (Move Tool Settings);
    Rotate and Scale always offer it."""
    if kind != 'TRANSLATE':
        return True
    from ..ui import manipulator
    return manipulator.slot_type(scene, kind) == 'GLOBAL'

def apply_tool(ts, kind):
    """Blender's shared Absolute Grid Snap flag = the stored mode of tool ``kind`` (no change without one)."""
    if kind not in STEP_FLAGS:
        return False
    own = _record(ts).get(kind)
    if own not in ('RELATIVE', 'ABSOLUTE'):
        return False
    want = own == 'ABSOLUTE'
    if ts.use_snap_grid_absolute != want:
        ts.use_snap_grid_absolute = want
        return True
    return False

def active_kind(context):
    """'TRANSLATE' / 'ROTATE' / 'RESIZE' of the active 3D View tool, else None."""
    workspace = getattr(context, 'workspace', None)
    if workspace is None:
        return None
    try:
        tool = workspace.tools.from_space_view3d_mode(context.mode, create=False)
    except (AttributeError, RuntimeError, TypeError):
        return None
    return TOOL_KINDS.get(tool.idname) if tool is not None else None

def apply_active(context):
    kind = active_kind(context)
    return apply_tool(context.scene.tool_settings, kind) if kind and context.scene else False

def other_snaps_on(ts):
    """Any snap mode besides the increment step is on (grid / point / curve / live)."""
    return ts.use_snap and bool(set(ts.snap_elements) & set(OTHER_SNAPS))

def heal_affect(ts):
    """Turn the Move / Rotate / Scale Affect flags back on wherever Step Snap isn't the reason they are off: with
    a grid / point / curve snap on, Blender would otherwise ignore it for that transform (#139)."""
    if not other_snaps_on(ts):
        return 0
    n = 0
    for (kind, flag) in STEP_FLAGS.items():
        if not getattr(ts, flag):
            setattr(ts, flag, True)
            n += 1
    return n

def settle_affect(ts):
    """After the Status Line snap set changed: with a grid / point / curve snap on, every Affect flag is on (#139);
    with none left, a tool whose Step Snap the user turned Off gets its Affect flag back off — otherwise it kept
    stepping by another tool's increment while showing Off (step 240 QA C-240-1)."""
    if other_snaps_on(ts):
        return heal_affect(ts)
    n = 0
    for (kind, mode) in _record(ts).items():
        flag = STEP_FLAGS.get(kind)
        if mode == 'OFF' and flag and getattr(ts, flag):
            setattr(ts, flag, False)
            n += 1
    return n

def set_step_snap(ts, kind, mode):
    if mode == 'TOGGLE':
        mode = 'OFF' if step_snap_mode(ts, kind) != 'OFF' else 'RELATIVE'
    rec = _record(ts)
    rec[kind] = mode
    _store(ts, rec)
    if mode == 'OFF':
        stepping = [k for k in STEP_FLAGS if k != kind and rec.get(k) in ('RELATIVE', 'ABSOLUTE') and (step_snap_mode(ts, k) != 'OFF')]
        elements = set(ts.snap_elements) if ts.use_snap else set()
        if not stepping:
            elements.discard('INCREMENT')
        setattr(ts, STEP_FLAGS[kind], bool(elements - {'INCREMENT'}))
        if elements:
            ts.snap_elements = elements
        else:
            ts.use_snap = False
        return 'OFF'
    was_snapping = ts.use_snap and 'INCREMENT' in ts.snap_elements
    for (other, flag) in STEP_FLAGS.items():
        if other == kind or rec.get(other) in ('RELATIVE', 'ABSOLUTE', 'OFF'):
            continue
        if was_snapping and getattr(ts, flag):
            rec[other] = 'ABSOLUTE' if ts.use_snap_grid_absolute else 'RELATIVE'
            continue
        rec[other] = 'OFF'
        if not other_snaps_on(ts):
            setattr(ts, flag, False)
    _store(ts, rec)
    ts.snap_elements = set(ts.snap_elements if ts.use_snap else ()) | {'INCREMENT'}
    ts.use_snap = True
    setattr(ts, STEP_FLAGS[kind], True)
    ts.use_snap_grid_absolute = mode == 'ABSOLUTE'
    if kind == 'ROTATE' and abs(ts.snap_angle_increment_3d - 0.0872664600610733) < 1e-06:
        ts.snap_angle_increment_3d = MAYA_ROTATE_STEP
    return mode

class ALLSET_OT_step_snap(bpy.types.Operator):
    """Maya Step Snap of the Move / Rotate / Scale tool: off, relative to the start, or to
    absolute steps (Discrete Move / Rotate / Snap Scale)"""
    bl_translation_context = 'MWK:operators/snap_align.py:587'
    bl_idname = 'allset.step_snap'
    bl_label = _zh_native('Step Snap', 'MWK:operators/snap_align.py:587')
    bl_description = _zh_native('Maya Step Snap of the Move / Rotate / Scale tool: off, relative to the start, or to\nabsolute steps (Discrete Move / Rotate / Snap Scale)', 'MWK:operators/snap_align.py:587')
    bl_options = {'REGISTER', 'UNDO'}
    kind: EnumProperty(items=_zh_enum((('TRANSLATE', 'Move', ''), ('ROTATE', 'Rotate', ''), ('RESIZE', 'Scale', '')), 'MWK:operators/snap_align.py:590'), translation_context='MWK:operators/snap_align.py:590')
    mode: EnumProperty(items=_zh_enum((('OFF', 'Off', ''), ('RELATIVE', 'Relative', ''), ('ABSOLUTE', 'Absolute', ''), ('TOGGLE', 'Toggle', '')), 'MWK:operators/snap_align.py:591'), translation_context='MWK:operators/snap_align.py:591')

    def execute(self, context):
        got = set_step_snap(context.scene.tool_settings, self.kind, self.mode)
        results.result(self, _zh(f'Step snap {got.lower()}', 'MWK:operators/snap_align.py:596'))
        for area in context.screen.areas if context.screen else ():
            area.tag_redraw()
        return {'FINISHED'}
classes += (ALLSET_OT_step_snap,)
