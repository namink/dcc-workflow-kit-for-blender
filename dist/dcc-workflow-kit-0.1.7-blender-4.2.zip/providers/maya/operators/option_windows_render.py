# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Step 152 (#101) Maya option windows of the Render menu.

Same spec as operators/option_windows.py (``F`` fields, ``Window`` = one ``allset.opt_<key>`` operator;
option_windows._extend appends ``WINDOWS``). Maya 2022 with factory prefs:

- Render > Render Sequence ❒ = "Render Sequence (Current Frame)": Render Options (Current Camera persp, All
  Render-Enabled Layers / Cameras, Render Region, Ignore Local Overrides off, Alternate Output File Location empty),
  Render View Options (Add to Render View off); buttons "Render Sequence and Close" / "Render Sequence" / "Close".
  The kit runs Current Camera and Alternate Output File Location; the rest are Maya concepts Blender has no part for.
- Render > Batch Render ❒: the factory renderer (Arnold) opens no window; Maya Software opens "Batch Render Frame"
  (Use all available processors on, Number of processors to use 0; "Batch render and close" / "Batch render").
  The kit's batch render is a background Blender, so the Maya Software window maps to its ``-t`` threads
  (delegated, step 152).
- Render > Render Current Frame ❒ / IPR Render Current Frame ❒ open no window in Maya: the Help Line reads
  'Renderer "<name>" does not provide render options.' — ``NO_OPTIONS`` (option_windows.ALLSET_OT_option_generic).
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy.props import EnumProperty, StringProperty
from .option_windows import F, Window
NO_OPTIONS = {'Render/Render Current Frame': _dcc_source('Renderer "{name}" does not provide render options.'), 'Render/IPR Render Current Frame': _dcc_source('Renderer "{name}" does not provide IPR options.')}
ENGINE_NAMES = {'BLENDER_EEVEE_NEXT': 'EEVEE', 'BLENDER_EEVEE': 'EEVEE', 'CYCLES': 'Cycles', 'BLENDER_WORKBENCH': _dcc_source('Workbench')}

def engine_name(scene):
    return ENGINE_NAMES.get(scene.render.engine, scene.render.engine.title())

def no_options_text(path, scene):
    """Maya's Help Line warning for ``path``'s option box, or None when it has a window."""
    text = NO_OPTIONS.get(path)
    return text.format(name=engine_name(scene)) if text else None

def _cameras(_self, context):
    items = [('persp', 'persp', _dcc_source("The view's camera, else the kit persp camera (Maya persp)"))]
    scene = getattr(context, 'scene', None)
    for ob in sorted((o for o in (scene.objects if scene else ()) if o.type == 'CAMERA' and (not o.get('allset_persp'))), key=lambda o: o.name):
        items.append((ob.name, ob.name, ''))
    return items

class FCamera(F):
    """Maya's Current Camera combo: persp + the scene's cameras (items read when the window opens)."""

    def __init__(self, name, label):
        super().__init__(name, label, 'camera', 'persp')

    def prop(self):
        return EnumProperty(name=_zh_native(self.label.rstrip(':'), 'MWK:operators/option_windows_render.py:59'), items=_zh_enum(_cameras, 'MWK:operators/option_windows_render.py:59'), translation_context='MWK:operators/option_windows_render.py:59')

class FPath(F):
    """A folder field (Maya: text field + folder button)."""

    def __init__(self, name, label):
        super().__init__(name, label, 'path', '')

    def prop(self):
        return StringProperty(name=_zh_native(self.label.rstrip(':'), 'MWK:operators/option_windows_render.py:69'), default='', subtype='DIR_PATH', translation_context='MWK:operators/option_windows_render.py:69')

def _run_sequence(context, v):
    camera = v.get('camera') or 'persp'
    return bpy.ops.allset.render_sequence('INVOKE_DEFAULT', camera='' if camera == 'persp' else camera, output=v.get('output') or '')

def _run_batch(context, v):
    threads = 0 if v['all_processors'] else max(1, int(v['processors']))
    return bpy.ops.allset.batch_render('EXEC_DEFAULT', threads=threads)
WINDOWS = [Window('render_sequence', _dcc_source('Render Sequence (Current Frame)'), _dcc_source('Render Sequence and Close'), None, [FCamera('camera', _dcc_source('Current Camera:')), FPath('output', _dcc_source('Alternate Output File Location:'))], _run_sequence, paths=('Render/Render Sequence',), apply_text=_dcc_source('Render Sequence'), missing=(_dcc_source('All Render-Enabled Layers'), _dcc_source('All Render-Enabled Cameras'), _dcc_source('Render Region'), _dcc_source('Ignore Local Overrides'), _dcc_source('Render View Options: Add to Render View')), translation_context='MWK:operators/option_windows_render.py:84'), Window('batch_render', _dcc_source('Batch Render Frame'), _dcc_source('Batch render and close'), None, [F('all_processors', '', 'bool', True, text=_zh_native('Use all available processors', 'MWK:operators/option_windows_render.py:91'), translation_context='MWK:operators/option_windows_render.py:91'), F('processors', _dcc_source('Number of processors to use:'), 'int', 0, lo=0, hi=256, translation_context='MWK:operators/option_windows_render.py:92')], _run_batch, paths=('Render/Batch Render',), apply_text=_dcc_source('Batch render'), translation_context='MWK:operators/option_windows_render.py:90')]
