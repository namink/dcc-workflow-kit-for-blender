# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Step 152 (#101) Maya option windows of the Display menu: Display > Grid ❒ = Maya's Grid Options.

Same spec as operators/option_windows.py (``F`` fields, ``Window`` = one ``allset.opt_<key>`` operator;
option_windows._extend appends ``WINDOWS``). Labels, kinds, factory defaults and buttons are Maya 2022's
with factory prefs (Grid Options;
grid size 12, spacing 5, divisions 5,
displayColor grid / gridAxis / gridHighlight = index 2 = 0.25 grey).

Maya keeps grid options as optionVars (gridSize / gridSpacing / gridDivisions, displayGrid*: per user), so the kit
keeps them where every option window keeps its values: the add-on preference ``option_settings`` (key
"grid_options"). ui/maya_grid.py draws from ``grid_settings()`` = the applied values over Maya's factory ones.
Colours: Maya picks them on its 31-entry colour index slider; Blender has a colour picker (delegated, step 152), with
Maya's index 2 grey (#404040) as the default. Grid numbers are not drawn by the kit (Maya's factory: Hide).
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import json
import bpy
from bpy.props import FloatVectorProperty
from .option_windows import F, Window
KEY = 'grid_options'
MAYA_GREY = (0.25, 0.25, 0.25)

class FColor(F):
    """A colour (Maya: a colour index slider): display-space RGB, drawn as is like the grid lines."""

    def __init__(self, name, label, default=MAYA_GREY):
        super().__init__(name, label, 'vec3color', default)

    def prop(self):
        return FloatVectorProperty(name=_zh_native(self.label.rstrip(':'), 'MWK:operators/option_windows_display.py:37'), default=self.default, size=3, subtype='COLOR_GAMMA', min=0.0, max=1.0, translation_context='MWK:operators/option_windows_display.py:37')
FIELDS = [F('size', _dcc_source('Length and width:'), 'float', 12.0, lo=0.01, hi=1000.0, translation_context='MWK:operators/option_windows_display.py:43'), F('spacing', _dcc_source('Grid lines every:'), 'float', 5.0, lo=0.01, hi=1000.0, translation_context='MWK:operators/option_windows_display.py:44'), F('divisions', _dcc_source('Subdivisions:'), 'int', 5, lo=1, hi=20, translation_context='MWK:operators/option_windows_display.py:45'), FColor('axis_color', _dcc_source('Axes:')), FColor('line_color', _dcc_source('Grid lines & numbers:')), FColor('division_color', _dcc_source('Subdivision lines:')), F('show_axes', _dcc_source('Display:'), 'bool', True, text=_zh_native('Axes', 'MWK:operators/option_windows_display.py:51'), translation_context='MWK:operators/option_windows_display.py:51'), F('thick_axes', '', 'bool', True, text=_zh_native('Thicker line for axes', 'MWK:operators/option_windows_display.py:52'), translation_context='MWK:operators/option_windows_display.py:52'), F('show_lines', '', 'bool', True, text=_zh_native('Grid lines', 'MWK:operators/option_windows_display.py:53'), translation_context='MWK:operators/option_windows_display.py:53'), F('show_divisions', '', 'bool', True, text=_zh_native('Subdivision lines', 'MWK:operators/option_windows_display.py:54'), translation_context='MWK:operators/option_windows_display.py:54')]

def _run_grid(context, v):
    """Apply = the grid redraws with the window's values (execute / Apply stored them first). Maya's Apply doesn't
    turn a hidden grid on (delegated: the values only change how the grid looks, Display > Grid shows / hides it)."""
    _CACHE.clear()
    wm = context.window_manager
    for win in wm.windows if wm else ():
        for area in win.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
    return {'FINISHED'}
TOGGLE_KEY = 'toggle_show_hide'

def _run_toggle(context, v):
    return bpy.ops.allset.visibility('EXEC_DEFAULT', action='TOGGLE', behaviour='DEPENDENT' if v['first_selection'] == _dcc_source('Dependent') else 'INDEPENDENT')
WINDOWS = [Window(TOGGLE_KEY, _dcc_source('Toggle Visibility Options'), _dcc_source('Apply and Close'), None, [F('first_selection', _dcc_source('First Selection:'), 'enum', _dcc_source('Independent'), items=(_dcc_source('Independent'), _dcc_source('Dependent')), translation_context='MWK:operators/option_windows_display.py:84')], _run_toggle, paths=('Display/Toggle Show/Hide',), translation_context='MWK:operators/option_windows_display.py:83'), Window(KEY, _dcc_source('Grid Options'), _dcc_source('Apply and Close'), None, FIELDS, _run_grid, paths=('Display/Grid',), missing=(_dcc_source('Perspective grid numbers: Hide / On Axes / Along Edge (factory Hide)'), _dcc_source('Orthographic grid numbers: Hide / On Axes / Along Edge (factory Hide)')), click_saved=False, translation_context='MWK:operators/option_windows_display.py:86')]

def defaults():
    return {f.name: f.default for f in FIELDS}
_CACHE = {}

def grid_settings():
    """Maya grid options in Maya units: the applied ones over the factory ones (cached on the stored text)."""
    from .. import preferences
    try:
        raw = preferences.get().option_settings or ''
    except (KeyError, AttributeError):
        raw = ''
    hit = _CACHE.get('raw')
    if hit is not None and hit == raw:
        return _CACHE['values']
    values = defaults()
    try:
        saved = json.loads(raw).get(KEY) if raw else None
    except ValueError:
        saved = None
    for (k, val) in (saved or {}).items():
        if k in values:
            values[k] = tuple(val) if isinstance(values[k], tuple) else type(values[k])(val)
    (_CACHE['raw'], _CACHE['values']) = (raw, values)
    return values
