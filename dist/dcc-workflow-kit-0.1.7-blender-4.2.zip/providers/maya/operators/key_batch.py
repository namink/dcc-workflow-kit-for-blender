# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Step 78 keys (docs/steps/step_78.md): Shift+G repeat last at the mouse position, Ctrl+Shift+C camera from
the view.

- Shift+G = Maya's Repeat Last at the mouse position:
  the point on the
  ground plane under the mouse, then the last action again, then the (new) selection moved there.
- Ctrl+Shift+C = ``MTcreateCameraFromView`` (Maya default hotkey).
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy_extras import view3d_utils
from mathutils import Vector
from .. import results
from . import create
VIEW_SENSOR = 72.0

def ground_point(origin, direction, eps=1e-06):
    """Where the view ray ``origin + t * direction`` (t > 0) meets Maya's ground plane (Y = 0 -> Blender Z = 0);
    None when the ray runs along the plane or away from it."""
    if abs(direction.z) < eps:
        return None
    t = -origin.z / direction.z
    if t <= 0:
        return None
    return origin + direction * t

def mouse_point(region, rv3d, mouse):
    """Maya autoPlace -um: the ground plane under the mouse, else the view plane through the world origin."""
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, mouse)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, mouse)
    p = ground_point(Vector(origin), Vector(direction))
    if p is None:
        p = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse, Vector((0.0, 0.0, 0.0)))
    return Vector(p)

def move_to(objects, point):
    """Maya ``move x y z`` (absolute): each object's pivot (the origin, step 10) goes to ``point``. Children of
    another moved object follow their parent."""
    moved = set(objects)
    for ob in objects:
        if ob.parent in moved:
            continue
        mw = ob.matrix_world.copy()
        mw.translation = point
        ob.matrix_world = mw

class ALLSET_OT_repeat_at_mouse(bpy.types.Operator):
    """Repeat the last action and move the result to the mouse position (Maya Shift+G)"""
    bl_translation_context = 'MWK:operators/key_batch.py:61'
    bl_idname = 'allset.repeat_at_mouse'
    bl_label = _zh_native('Repeat Last at Mouse Position', 'MWK:operators/key_batch.py:61')
    bl_description = _zh_native('Repeat the last action and move the result to the mouse position (Maya Shift+G)', 'MWK:operators/key_batch.py:61')
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def invoke(self, context, event):
        (region, rv3d) = (context.region, context.region_data)
        if region is None or region.type != 'WINDOW' or rv3d is None:
            return {'PASS_THROUGH'}
        point = mouse_point(region, rv3d, (event.mouse_region_x, event.mouse_region_y))
        from . import repeat_maya
        try:
            res = repeat_maya.repeat(context, inside_undo_op=True)
        except RuntimeError as ex:
            self.report({'WARNING'}, _zh(f'Nothing to repeat ({ex})', 'MWK:operators/key_batch.py:79'))
            return {'CANCELLED'}
        if res is None:
            self.report({'WARNING'}, _zh('Nothing to repeat', 'MWK:operators/key_batch.py:82'))
            return {'CANCELLED'}
        if context.mode == 'OBJECT' and context.selected_objects:
            move_to(list(context.selected_objects), point)
        return {'FINISHED'}

def camera_matrix(view_matrix):
    """The camera world matrix that sees what the view sees (both look down their local -Z)."""
    return view_matrix.inverted()

class ALLSET_OT_camera_from_view(bpy.types.Operator):
    """Create a camera that matches this view (Maya Ctrl+Shift+C, Create Camera from View)"""
    bl_translation_context = 'MWK:operators/key_batch.py:97'
    bl_idname = 'allset.camera_from_view'
    bl_label = _zh_native('Create Camera from View', 'MWK:operators/key_batch.py:97')
    bl_description = _zh_native('Create a camera that matches this view (Maya Ctrl+Shift+C, Create Camera from View)', 'MWK:operators/key_batch.py:97')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and (context.region_data is not None)

    def execute(self, context):
        (space, rv3d) = (context.space_data, context.region_data)
        ob = create.create(context, 'CAMERA', create._maya_naming(context))
        ob.matrix_world = camera_matrix(rv3d.view_matrix)
        cam = ob.data
        if rv3d.is_perspective:
            cam.type = 'PERSP'
            cam.lens = space.lens * cam.sensor_width / VIEW_SENSOR
        else:
            cam.type = 'ORTHO'
            cam.ortho_scale = rv3d.view_distance * VIEW_SENSOR / space.lens
        for other in context.selected_objects:
            if other != ob:
                other.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        results.result(self, _zh(f'Created {ob.name} from the view', 'MWK:operators/key_batch.py:121'))
        return {'FINISHED'}
classes = (ALLSET_OT_repeat_at_mouse, ALLSET_OT_camera_from_view)
