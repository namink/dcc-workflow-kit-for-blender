# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Deformer order (Maya ``reorderDeformers``) and Key > Set Blend Shape Target Weight Keys (step 218, L17 / L15b).

Maya 2026:
``reorderDeformers A B`` moves **B** to directly before A in evaluation order, so A then runs right after B; when B
already runs right before A, nothing moves and Maya warns "B and A are already in the specified order." With
three clusters (evaluation c1 c2 c3): (c3, c1) -> c2 c1 c3, (c1, c3) -> c3 c1 c2, (c1, c2) -> c2 c1 c3, (c2, c1) ->
warning. The kit's deformers are the object's modifiers (the stack = evaluation order); blend shapes are shape keys,
which Blender always evaluates first (= Maya's automatic Blend Shape placement before the skin) and can't move.
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import bpy
from bpy.props import StringProperty
from .. import results, undo_steps

class AlreadyInOrder(ValueError):
    pass

def reorder(order, a, b):
    """New evaluation order after ``reorderDeformers a b`` (``order`` = names, first evaluated first)."""
    order = list(order)
    (ia, ib) = (order.index(a), order.index(b))
    if ia == ib:
        raise ValueError(_dcc_source('same deformer'))
    if ib + 1 == ia:
        raise AlreadyInOrder(f'{b} and {a} are already in the specified order.')
    order.remove(b)
    order.insert(order.index(a), b)
    return order

def movable(ob):
    """The modifiers the kit shows as Maya deformers / history nodes, in stack order (Channel Box INPUTS)."""
    from ..ui import channel_box
    own = [m for m in channel_box._inputs(ob) if m.id_data == ob]
    return own

def apply_order(ob, names):
    """Move ``ob``'s modifiers so the movable ones follow ``names``; the others keep their stack slots."""
    mods = ob.modifiers
    slots = sorted((i for (i, m) in enumerate(mods) if m.name in set(names)))
    for (slot, name) in zip(slots, names):
        cur = mods.find(name)
        if cur != slot:
            with bpy.context.temp_override(object=ob):
                bpy.ops.object.modifier_move_to_index(modifier=name, index=slot)

def reorder_deformers(ob, a, b):
    """Maya ``reorderDeformers a b <ob>`` on modifier names ``a`` / ``b``. Raises AlreadyInOrder / ValueError."""
    names = [m.name for m in movable(ob)]
    if a not in names or b not in names:
        raise ValueError(f'{ob.name} has no deformer {(a if a not in names else b)}')
    new = reorder(names, a, b)
    apply_order(ob, new)
    return new

@undo_steps.no_redo_panel
class ALLSET_OT_reorder_deformers(bpy.types.Operator):
    """Change the order in which two deformers affect the object (Maya reorderDeformers: the first runs right after
    the second)"""
    bl_translation_context = 'MWK:operators/deformer_order.py:70'
    bl_idname = 'allset.reorder_deformers'
    bl_label = _zh_native('Reorder Deformers', 'MWK:operators/deformer_order.py:70')
    bl_description = _zh_native('Change the order in which two deformers affect the object (Maya reorderDeformers: the first runs right after\nthe second)', 'MWK:operators/deformer_order.py:70')
    bl_options = {'REGISTER', 'UNDO'}
    object: StringProperty(options={'HIDDEN', 'SKIP_SAVE'}, translation_context='MWK:operators/deformer_order.py:73')
    first: StringProperty(options={'HIDDEN', 'SKIP_SAVE'}, translation_context='MWK:operators/deformer_order.py:74')
    second: StringProperty(options={'HIDDEN', 'SKIP_SAVE'}, translation_context='MWK:operators/deformer_order.py:75')

    def execute(self, context):
        ob = bpy.data.objects.get(self.object)
        if ob is None:
            return {'CANCELLED'}
        try:
            reorder_deformers(ob, self.first, self.second)
        except AlreadyInOrder as ex:
            self.report({'WARNING'}, _zh(str(ex), 'MWK:operators/deformer_order.py:84'))
            return {'CANCELLED'}
        except ValueError as ex:
            self.report({'ERROR'}, _zh(str(ex), 'MWK:operators/deformer_order.py:87'))
            return {'CANCELLED'}
        results.result(self, _zh(f'reorderDeformers {self.first} {self.second} {ob.name}', 'MWK:operators/deformer_order.py:89'))
        for area in context.screen.areas if context.screen else ():
            area.tag_redraw()
        return {'FINISHED'}

def blend_shape_keys(ob):
    """The target shape keys (not the basis) of ``ob``."""
    key = getattr(getattr(ob, 'data', None), 'shape_keys', None)
    if key is None:
        return []
    from . import blend_shapes_227
    return blend_shapes_227.target_blocks(key)

def key_target_weights(context, objects):
    """Key every blend shape target weight (shape key Value) of ``objects`` at the current frame; returns the count.
    Maya 2026 keys nothing for any selection we could give it,
    so the kit does what the menu name says (delegated)."""
    frame = context.scene.frame_current
    n = 0
    for ob in objects:
        for kb in blend_shape_keys(ob):
            if kb.keyframe_insert('value', frame=frame):
                n += 1
    return n
SHAPE_TYPES = {'MESH', 'CURVE', 'SURFACE', 'LATTICE'}

@undo_steps.no_redo_panel
class ALLSET_OT_key_blend_shape_weights(bpy.types.Operator):
    """Set keys on the blend shape target weights of the selected objects (Maya Key > Set Blend Shape Target Weight
    Keys; Blender: the shape key Values)"""
    bl_translation_context = 'MWK:operators/deformer_order.py:128'
    bl_idname = 'allset.key_blend_shape_weights'
    bl_label = _zh_native('Set Blend Shape Target Weight Keys', 'MWK:operators/deformer_order.py:128')
    bl_description = _zh_native('Set keys on the blend shape target weights of the selected objects (Maya Key > Set Blend Shape Target Weight\nKeys; Blender: the shape key Values)', 'MWK:operators/deformer_order.py:128')
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        objects = list(context.selected_objects)
        if not any((ob.type in SHAPE_TYPES for ob in objects)):
            self.report({'ERROR'}, _zh('No shape was selected.', 'MWK:operators/deformer_order.py:135'))
            return {'CANCELLED'}
        n = key_target_weights(context, objects)
        if not n:
            self.report({'WARNING'}, _zh('No blend shape targets on the selected objects.', 'MWK:operators/deformer_order.py:139'))
            return {'CANCELLED'}
        results.result(self, _zh(f"Set {n} blend shape target weight key{('s' if n != 1 else '')}", 'MWK:operators/deformer_order.py:141'))
        return {'FINISHED'}
classes = (ALLSET_OT_reorder_deformers, ALLSET_OT_key_blend_shape_weights)
