# SPDX-License-Identifier: GPL-3.0-or-later
# Simplified Chinese localization by namink; additional display integration 2026-10-31.
"""Maya option windows (the □ option box of a menu item): docs/steps/step_103.md 「계획」.

Maya opens a window per command with its fields (labels right-aligned, field + slider), an Edit menu (Save Settings /
Reset Settings) and three buttons: the command ("Create", "Extrude", ...), Apply (run, keep the window) and Close; the
values are kept between sessions (optionVars). Fields, labels and factory defaults below were read from the running
Maya 2022 windows.

Each ``Window`` becomes one operator ``allset.opt_<key>`` drawn with ``invoke_props_dialog`` (confirm = the
command's button, Blender's cancel = Close); Apply / Save Settings / Reset Settings are toggle buttons inside the
dialog whose update callbacks act at once and spring back. ``Window.run`` maps the Maya values onto the kit or
Blender operator. ``find(action)`` ties a window to a menu / marking menu / shelf action, so every option box of
that action opens it, and a plain click uses the saved values once the user has applied or saved them (Maya runs a
menu item with its option values).
"""
from ..i18n import source_message as _dcc_source, display_message as _dcc_display, format_message as _dcc_format
from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native
import json
import bmesh
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty
from mathutils import Matrix, Vector
from . import units

class F:
    """One Maya field: ``kind`` float / length (× maya_unit) / int / bool / enum / vec3 / vec3len / angle3."""

    def __init__(self, name, label, kind, default, items=None, lo=None, hi=None, text=None, heading=None, translation_context=None):
        (self.name, self.label, self.kind, self.default) = (name, label, kind, default)
        self.translation_context = translation_context or 'MWK:operators/option_windows.py:field'
        (self.items, self.lo, self.hi, self.text, self.heading) = (items, lo, hi, text, heading)

    def prop(self):
        kw = {'name': _zh_native(self.label.rstrip(':'), self.translation_context), 'default': self.default, 'translation_context': self.translation_context}
        if self.kind in ('float', 'length'):
            kw.update(soft_min=self.lo if self.lo is not None else -1000000.0, soft_max=self.hi if self.hi is not None else 1000000.0, precision=4, step=10)
            return FloatProperty(**kw)
        if self.kind == 'int':
            return IntProperty(min=self.lo if self.lo is not None else 0, soft_max=self.hi or 100, **kw)
        if self.kind == 'bool':
            return BoolProperty(**kw)
        if self.kind == 'enum':
            return EnumProperty(items=_zh_enum([(i, i, '') for i in self.items], self.translation_context), **kw)
        return FloatVectorProperty(size=3, precision=4, **kw)

class Window:

    def __init__(self, key, title, action, match, fields, run, paths=(), missing=(), width=440, apply_text=_dcc_source('Apply'), click_saved=True, translation_context=None):
        (self.key, self.title, self.action) = (key, title, action)
        self.translation_context = translation_context or 'MWK:operators/option_windows.py:window'
        self.click_saved = click_saved
        self.apply_text = apply_text
        self.match = match
        (self.fields, self.run, self.paths) = (fields, run, tuple(paths))
        self.missing = tuple(missing)
        self.width = width

    @property
    def idname(self):
        return f'allset.opt_{self.key}'

    def defaults(self):
        return {f.name: f.default for f in self.fields}

def _k(context):
    return units.maya_unit(context.scene)
_AXES = {'X': (1.0, 0.0, 0.0), 'Y': (0.0, 1.0, 0.0), 'Z': (0.0, 0.0, 1.0)}
_NODE_FIELDS = {'CUBE': {'width': 'width', 'height': 'height', 'depth': 'depth', 'width_div': 'subdivisionsWidth', 'height_div': 'subdivisionsHeight', 'depth_div': 'subdivisionsDepth'}, 'SPHERE': {'radius': 'radius', 'axis_div': 'subdivisionsAxis', 'height_div': 'subdivisionsHeight'}, 'CYLINDER': {'radius': 'radius', 'height': 'height', 'axis_div': 'subdivisionsAxis', 'height_div': 'subdivisionsHeight', 'cap_div': 'subdivisionsCaps', 'round_cap': 'roundCap'}, 'CONE': {'radius': 'radius', 'height': 'height', 'axis_div': 'subdivisionsAxis', 'height_div': 'subdivisionsHeight', 'cap_div': 'subdivisionsCap', 'round_cap': 'roundCap'}, 'TORUS': {'radius': 'radius', 'section_radius': 'sectionRadius', 'twist': 'twist', 'axis_div': 'subdivisionsAxis', 'height_div': 'subdivisionsHeight'}, 'PLANE': {'width': 'width', 'height': 'height', 'width_div': 'subdivisionsWidth', 'height_div': 'subdivisionsHeight'}}

def _primitive(kind):

    def run(context, v):
        from . import create
        over = {node: v[field] for (field, node) in _NODE_FIELDS[kind].items() if field in v}
        ax = _AXES.get(v.get('axis', 'Y'), _AXES['Y'])
        over.update(axisX=ax[0], axisY=ax[1], axisZ=ax[2], createUVs=int(bool(v.get('create_uvs', True))))
        create.create(context, kind, overrides=over)
        return {'FINISHED'}
    return run

def _op(op_id, **kw):
    (mod, name) = op_id.split('.')
    return getattr(getattr(bpy.ops, mod), name)('EXEC_DEFAULT', **kw)

def _components(context, op_id, select_mode, **kw):
    """Run an edit-mode mesh command; from object mode on every component of the selected meshes (Maya)."""
    if context.mode == 'EDIT_MESH':
        return _op(op_id, **kw)
    meshes = [o for o in context.selected_objects if o.type == 'MESH']
    if not meshes:
        raise RuntimeError(_dcc_source('Select a mesh first.'))
    if context.view_layer.objects.active not in meshes:
        context.view_layer.objects.active = meshes[0]
    bpy.ops.object.mode_set(mode='EDIT')
    try:
        bpy.ops.mesh.select_mode(type=select_mode)
        bpy.ops.mesh.select_all(action='SELECT')
        return _op(op_id, **kw)
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')

def _with_hierarchy(context, below, fn):
    """Maya Hierarchy: Selected / Below (the selection plus everything under it while ``fn`` runs)."""
    if not below:
        return fn()
    from .freeze import hierarchy
    extra = [o for o in hierarchy(context.selected_objects) if not o.select_get()]
    for o in extra:
        o.select_set(True)
    try:
        return fn()
    finally:
        for o in extra:
            o.select_set(False)

def _last_constraint(context):
    pb = context.active_pose_bone if context.mode == 'POSE' else None
    owner = pb if pb is not None else context.active_object
    return owner.constraints[-1] if owner is not None and owner.constraints else None

def _group_axes(cons, ctype, v):
    """Constraint axes on every Blender constraint of a kit multi-target group (step 226): the parent group's Copy
    Location members take Translate, its Copy Rotation members Rotate (Maya Z = Blender -Y, Maya Y = Blender Z)."""
    for con in cons:
        if ctype == 'CHILD_OF':
            pre = 'all_t' if con.type == 'COPY_LOCATION' else 'all_r'
            keys = ('tx', 'tz', 'ty') if con.type == 'COPY_LOCATION' else ('rx', 'rz', 'ry')
            (con.use_x, con.use_y, con.use_z) = (v[pre] or v[k] for k in keys)
        else:
            con.use_x = v['all'] or v['x']
            con.use_y = v['all'] or v['z']
            con.use_z = v['all'] or v['y']

def _constraint(ctype):

    def run(context, v):
        from . import constrain_multi
        res = bpy.ops.allset.constrain('EXEC_DEFAULT', type=ctype, weight=v['weight'], maintain_offset='ON' if v['maintain_offset'] else 'OFF')
        con = _last_constraint(context)
        if res != {'FINISHED'} or con is None:
            return res
        mb = constrain_multi.member(con)
        if mb is not None:
            _group_axes(constrain_multi.members(mb.owner, mb.group), ctype, v)
            return res
        con.influence = v['weight']
        if ctype == 'CHILD_OF':
            if not v['maintain_offset']:
                con.inverse_matrix = Matrix.Identity(4)
            con.use_location_x = v['all_t'] or v['tx']
            con.use_location_y = v['all_t'] or v['tz']
            con.use_location_z = v['all_t'] or v['ty']
            con.use_rotation_x = v['all_r'] or v['rx']
            con.use_rotation_y = v['all_r'] or v['rz']
            con.use_rotation_z = v['all_r'] or v['ry']
        else:
            con.use_x = v['all'] or v['x']
            con.use_y = v['all'] or v['z']
            con.use_z = v['all'] or v['y']
            if v['maintain_offset']:
                if ctype == 'COPY_LOCATION':
                    con.use_offset = True
                else:
                    con.mix_mode = 'OFFSET'
        return res
    return run

def _run_group(context, v):
    res = bpy.ops.allset.group('EXEC_DEFAULT')
    grp = context.view_layer.objects.active
    if res == {'FINISHED'} and grp is not None:
        if v['group_under'] == _dcc_source('World') and grp.parent is not None:
            world = grp.matrix_world.copy()
            grp.parent = None
            grp.matrix_world = world
        if v[_dcc_source('pivot')] == _dcc_source('Center'):
            from .freeze import center_pivot
            center_pivot(context, [grp])
    return res

def _run_combine(context, v):
    objects = [o for o in context.selected_objects if o.type == 'MESH']
    last = context.view_layer.objects.active
    point = last.matrix_world.translation.copy() if last is not None else Vector()
    res = bpy.ops.allset.combine('EXEC_DEFAULT')
    ob = context.view_layer.objects.active
    if res == {'FINISHED'} and ob is not None and (v[_dcc_source('pivot')] != _dcc_source('Center')) and objects:
        from .pivot import match_pivot
        match_pivot(ob, point if v[_dcc_source('pivot')] == _dcc_source('Last object') else Vector())
    return res

def _run_smooth(context, v):
    """Maya Smooth with the window's values: real Catmull-Clark geometry (operators/poly_maya.py, step 139)."""
    if context.mode != 'EDIT_MESH' and (not any((o.type == 'MESH' for o in context.selected_objects))):
        raise RuntimeError(_dcc_source('Select a mesh first.'))
    return bpy.ops.allset.smooth('EXEC_DEFAULT', divisions=v['levels'])

def _run_bevel(context, v):
    fraction = v['offset_type'].startswith(_dcc_source('Fractional'))
    kw = dict(segments=v['segments'], depth=max(-1.0, min(1.0, v['depth'])), offset_as_fraction=fraction)
    if fraction:
        kw['fraction'] = max(0.0, min(1.0, v['width']))
    else:
        kw['offset'] = max(0.0, v['width'])
    if context.mode == 'EDIT_MESH' and tuple(context.scene.tool_settings.mesh_select_mode) == (True, False, False):
        bpy.ops.mesh.select_mode(type='EDGE')
    return _components(context, 'allset.bevel', 'EDGE', **kw)

def _run_extrude(context, v):

    def go():
        return bpy.ops.allset.extrude('EXEC_DEFAULT', thickness=v['thickness'], offset=v['offset'], divisions=v['divisions'])
    if context.mode == 'EDIT_MESH':
        return go()
    meshes = [o for o in context.selected_objects if o.type == 'MESH']
    if not meshes:
        raise RuntimeError(_dcc_source('Select faces (or a mesh) to extrude.'))
    bpy.ops.object.mode_set(mode='EDIT')
    try:
        bpy.ops.mesh.select_mode(type='FACE')
        bpy.ops.mesh.select_all(action='SELECT')
        return go()
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')

def _run_set_key(context, v):
    return _with_hierarchy(context, v['hierarchy'] == _dcc_source('Below'), lambda : bpy.ops.allset.set_key('EXEC_DEFAULT'))

def _run_bake(context, v):
    return bpy.ops.allset.bake_simulation('EXEC_DEFAULT', hierarchy_below=v['hierarchy'] == _dcc_source('Below'), use_time_slider=v['time_range'] == _dcc_source('Time Slider'), start=int(round(v['start'])), end=int(round(v['end'])), sample_by=max(1, int(round(v['sample_by']))), keep_unbaked=bool(v['keep_unbaked']), disable_implicit=bool(v['disable_implicit']))

def _run_uv_planar(context, v):
    from .menu_extras import planar_uvs
    axis = {_dcc_source('X axis'): Vector((1, 0, 0)), _dcc_source('Y axis'): Vector((0, 0, 1)), _dcc_source('Z axis'): Vector((0, -1, 0))}
    if v['fit'] == _dcc_source('Best plane') or v['project_from'] == _dcc_source('Camera'):
        return bpy.ops.allset.uv_planar('EXEC_DEFAULT')
    normal = axis[v['project_from']]
    obs = [o for o in (context.objects_in_mode if context.mode == 'EDIT_MESH' else context.selected_objects) if o.type == 'MESH']
    if not obs:
        raise RuntimeError(_dcc_source('Select faces (or a mesh) to project.'))
    for ob in obs:
        edit = ob.mode == 'EDIT'
        bm = bmesh.from_edit_mesh(ob.data) if edit else bmesh.new()
        if not edit:
            bm.from_mesh(ob.data)
        faces = [f for f in bm.faces if f.select] if edit else list(bm.faces)
        layer = bm.loops.layers.uv.active or bm.loops.layers.uv.new(_dcc_source('UVMap'))
        loops = [lp for f in faces for lp in f.loops]
        for (lp, uv) in zip(loops, planar_uvs([lp.vert.co for lp in loops], normal)):
            lp[layer].uv = uv
        if edit:
            bmesh.update_edit_mesh(ob.data)
        else:
            bm.to_mesh(ob.data)
            bm.free()
    return {'FINISHED'}

def _run_uv_auto(context, v):
    return bpy.ops.allset.uv_automatic('EXEC_DEFAULT', planes=v['planes'], spacing=v['spacing'])

def _run_new_scene(context, v):
    values = dict(v)

    def later():
        from .. import first_start
        first_start.new_maya_scene()
        scene = bpy.context.scene
        us = scene.unit_settings
        if not values['keep_units']:
            us.length_unit = {_dcc_source('millimeter'): 'MILLIMETERS', _dcc_source('centimeter'): 'CENTIMETERS', _dcc_source('meter'): 'METERS', _dcc_source('inch'): 'INCHES', _dcc_source('foot'): 'FEET', _dcc_source('yard'): 'YARDS'}[values['linear']]
            if values['linear'] in (_dcc_source('inch'), _dcc_source('foot'), _dcc_source('yard')):
                us.system = 'IMPERIAL'
            us.system_rotation = 'DEGREES' if values['angular'] == _dcc_source('degrees') else 'RADIANS'
            fps = float(values['fps'].split()[0])
            (scene.render.fps, scene.render.fps_base) = (round(fps), round(fps) / fps)
        (scene.frame_start, scene.frame_end) = (int(values['anim_start']), int(values['anim_end']))
        scene.use_preview_range = True
        (scene.frame_preview_start, scene.frame_preview_end) = (int(values['play_start']), int(values['play_end']))
        scene.frame_current = int(values['play_start'])
        return None
    from ..ui import save_prompt
    save_prompt.ask(context, later)
    return {'FINISHED'}

def _run_save(context, v):
    if v['incremental'] and bpy.data.filepath:
        return bpy.ops.allset.increment_save('EXEC_DEFAULT')
    if not bpy.data.filepath:
        return bpy.ops.allset.save_scene_as('INVOKE_DEFAULT')
    return bpy.ops.wm.save_mainfile('EXEC_DEFAULT', compress=v['compressed'])
AXIS = F('axis', _dcc_source('Axis:'), 'enum', 'Y', items=('X', 'Y', 'Z'), translation_context='MWK:operators/option_windows.py:350')
UVS = F('create_uvs', _dcc_source('Texture mapping:'), 'bool', True, text=_zh_native('Create UVs', 'MWK:operators/option_windows.py:351'), translation_context='MWK:operators/option_windows.py:351')
_FREEZE_RESET = lambda kind: [F('translate', f'{kind}:', 'bool', True, text=_zh_native('Translate', 'MWK:operators/option_windows.py:352'), translation_context='MWK:operators/option_windows.py:352'), F('rotate', '', 'bool', True, text=_zh_native('Rotate', 'MWK:operators/option_windows.py:353'), translation_context='MWK:operators/option_windows.py:353'), F('scale', '', 'bool', True, text=_zh_native('Scale', 'MWK:operators/option_windows.py:353'), translation_context='MWK:operators/option_windows.py:353')]
_CON_AXES = [F('all', _dcc_source('Constraint axes:'), 'bool', True, text=_zh_native('All', 'MWK:operators/option_windows.py:354'), translation_context='MWK:operators/option_windows.py:354'), F('x', '', 'bool', False, text=_zh_native('X', 'MWK:operators/option_windows.py:354'), translation_context='MWK:operators/option_windows.py:354'), F('y', '', 'bool', False, text=_zh_native('Y', 'MWK:operators/option_windows.py:355'), translation_context='MWK:operators/option_windows.py:355'), F('z', '', 'bool', False, text=_zh_native('Z', 'MWK:operators/option_windows.py:355'), translation_context='MWK:operators/option_windows.py:355'), F('weight', _dcc_source('Weight:'), 'float', 1.0, lo=0.0, hi=1.0, translation_context='MWK:operators/option_windows.py:356')]
WINDOWS = [Window('poly_cube', _dcc_source('Polygon Cube Options'), _dcc_source('Create'), ('allset.create', {'kind': 'CUBE'}), [F('width', _dcc_source('Width:'), 'length', 1.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:360'), F('height', _dcc_source('Height:'), 'length', 1.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:360'), F('depth', _dcc_source('Depth:'), 'length', 1.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:361'), F('width_div', _dcc_source('Width divisions:'), 'int', 1, lo=1, hi=50, translation_context='MWK:operators/option_windows.py:362'), F('height_div', _dcc_source('Height divisions:'), 'int', 1, lo=1, hi=50, translation_context='MWK:operators/option_windows.py:362'), F('depth_div', _dcc_source('Depth divisions:'), 'int', 1, lo=1, hi=50, translation_context='MWK:operators/option_windows.py:363'), AXIS, UVS], _primitive('CUBE'), missing=(_dcc_source('Normalize'), _dcc_source('Collectively / Each face separately'), _dcc_source('Preserve aspect ratio')), translation_context='MWK:operators/option_windows.py:359'), Window('poly_sphere', _dcc_source('Polygon Sphere Options'), _dcc_source('Create'), ('allset.create', {'kind': 'SPHERE'}), [F('radius', _dcc_source('Radius:'), 'length', 1.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:366'), F('axis_div', _dcc_source('Axis divisions:'), 'int', 20, lo=3, hi=200, translation_context='MWK:operators/option_windows.py:366'), F('height_div', _dcc_source('Height divisions:'), 'int', 20, lo=3, hi=200, translation_context='MWK:operators/option_windows.py:367'), AXIS, UVS], _primitive('SPHERE'), missing=(_dcc_source('Pinched / Sawtooth at poles'),), translation_context='MWK:operators/option_windows.py:365'), Window('poly_cylinder', _dcc_source('Polygon Cylinder Options'), _dcc_source('Create'), ('allset.create', {'kind': 'CYLINDER'}), [F('radius', _dcc_source('Radius:'), 'length', 1.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:370'), F('height', _dcc_source('Height:'), 'length', 2.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:370'), F('axis_div', _dcc_source('Axis divisions:'), 'int', 20, lo=3, hi=200, translation_context='MWK:operators/option_windows.py:371'), F('height_div', _dcc_source('Height divisions:'), 'int', 1, lo=1, hi=100, translation_context='MWK:operators/option_windows.py:371'), F('cap_div', _dcc_source('Cap divisions:'), 'int', 1, lo=0, hi=100, translation_context='MWK:operators/option_windows.py:372'), F('round_cap', '', 'bool', False, text=_zh_native('Round cap', 'MWK:operators/option_windows.py:372'), translation_context='MWK:operators/option_windows.py:372'), AXIS, UVS], _primitive('CYLINDER'), missing=(_dcc_source('Normalize'), _dcc_source('Preserve aspect ratio')), translation_context='MWK:operators/option_windows.py:369'), Window('poly_cone', _dcc_source('Polygon Cone Options'), _dcc_source('Create'), ('allset.create', {'kind': 'CONE'}), [F('radius', _dcc_source('Radius:'), 'length', 1.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:375'), F('height', _dcc_source('Height:'), 'length', 2.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:375'), F('axis_div', _dcc_source('Axis divisions:'), 'int', 20, lo=3, hi=200, translation_context='MWK:operators/option_windows.py:376'), F('height_div', _dcc_source('Height divisions:'), 'int', 1, lo=1, hi=100, translation_context='MWK:operators/option_windows.py:376'), F('cap_div', _dcc_source('Cap divisions:'), 'int', 0, lo=0, hi=100, translation_context='MWK:operators/option_windows.py:377'), F('round_cap', '', 'bool', False, text=_zh_native('Round cap', 'MWK:operators/option_windows.py:377'), translation_context='MWK:operators/option_windows.py:377'), AXIS, UVS], _primitive('CONE'), missing=(_dcc_source('Normalize'), _dcc_source('Preserve aspect ratio')), translation_context='MWK:operators/option_windows.py:374'), Window('poly_torus', _dcc_source('Polygon Torus Options'), _dcc_source('Create'), ('allset.create', {'kind': 'TORUS'}), [F('radius', _dcc_source('Radius:'), 'length', 1.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:380'), F('section_radius', _dcc_source('Section Radius:'), 'length', 0.5, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:381'), F('twist', _dcc_source('Twist:'), 'float', 0.0, lo=-360, hi=360, translation_context='MWK:operators/option_windows.py:382'), F('axis_div', _dcc_source('Axis divisions:'), 'int', 20, lo=3, hi=200, translation_context='MWK:operators/option_windows.py:383'), F('height_div', _dcc_source('Height divisions:'), 'int', 20, lo=3, hi=200, translation_context='MWK:operators/option_windows.py:383'), AXIS, UVS], _primitive('TORUS'), translation_context='MWK:operators/option_windows.py:379'), Window('poly_plane', _dcc_source('Polygon Plane Options'), _dcc_source('Create'), ('allset.create', {'kind': 'PLANE'}), [F('width', _dcc_source('Width:'), 'length', 1.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:386'), F('height', _dcc_source('Height:'), 'length', 1.0, lo=0.0001, hi=100, translation_context='MWK:operators/option_windows.py:386'), F('width_div', _dcc_source('Width divisions:'), 'int', 10, lo=1, hi=200, translation_context='MWK:operators/option_windows.py:387'), F('height_div', _dcc_source('Height divisions:'), 'int', 10, lo=1, hi=200, translation_context='MWK:operators/option_windows.py:387'), AXIS, UVS], _primitive('PLANE'), missing=(_dcc_source('Preserve aspect ratio'),), translation_context='MWK:operators/option_windows.py:385'), Window('group', _dcc_source('Group Options'), _dcc_source('Group'), ('allset.group', {}), [F('group_under', _dcc_source('Group under:'), 'enum', _dcc_source('Parent'), items=(_dcc_source('Parent'), _dcc_source('World')), translation_context='MWK:operators/option_windows.py:390'), F(_dcc_source('pivot'), _dcc_source('Group pivot:'), 'enum', _dcc_source('Origin'), items=(_dcc_source('Center'), _dcc_source('Origin')), translation_context='MWK:operators/option_windows.py:391')], _run_group, translation_context='MWK:operators/option_windows.py:389'), Window('freeze', _dcc_source('Freeze Transformations Options'), _dcc_source('Freeze Transform'), ('allset.freeze_transform', {}), _FREEZE_RESET(_dcc_source('Freeze')), lambda c, v: bpy.ops.allset.freeze_transform('EXEC_DEFAULT', translate=v['translate'], rotate=v['rotate'], scale=v['scale']), missing=(_dcc_source('Joint orient'), _dcc_source('Lock normals'), _dcc_source('Preserve normals')), translation_context='MWK:operators/option_windows.py:392'), Window('reset', _dcc_source('Reset Transformations Options'), _dcc_source('Reset Transform'), ('allset.reset_transform', {}), _FREEZE_RESET(_dcc_source('Reset')), lambda c, v: bpy.ops.allset.reset_transform('EXEC_DEFAULT', translate=v['translate'], rotate=v['rotate'], scale=v['scale']), translation_context='MWK:operators/option_windows.py:397'), Window('combine', _dcc_source('Combine Options'), _dcc_source('Combine'), ('allset.combine', {}), [F(_dcc_source('pivot'), _dcc_source('Pivot Position:'), 'enum', _dcc_source('Center'), items=(_dcc_source('Center'), _dcc_source('Last object'), _dcc_source('World origin')), translation_context='MWK:operators/option_windows.py:402')], _run_combine, missing=(_dcc_source('Merge UV Sets'), _dcc_source('Combine Skinning')), translation_context='MWK:operators/option_windows.py:401'), Window('smooth', _dcc_source('Smooth Options'), _dcc_source('Smooth'), None, [F('levels', _dcc_source('Division levels:'), 'int', 1, lo=0, hi=6, translation_context='MWK:operators/option_windows.py:405')], _run_smooth, paths=('Mesh/Smooth',), missing=(_dcc_source('Exponentially / Linearly'), 'Maya Catmull-Clark', _dcc_source('Propagate Edge Hardness'), _dcc_source('Vertex Boundary: Sharp edges'), _dcc_source('Smooth UVs: off'), _dcc_source('Map borders'), _dcc_source('Preserve: Geometry / Selection borders')), translation_context='MWK:operators/option_windows.py:404'), Window('extrude', _dcc_source('Extrude Face Options'), _dcc_source('Extrude'), ('allset.extrude', {}), [F('divisions', _dcc_source('Divisions:'), 'int', 1, lo=1, hi=50, translation_context='MWK:operators/option_windows.py:411'), F('offset', _dcc_source('Offset:'), 'float', 0.0, translation_context='MWK:operators/option_windows.py:411'), F('thickness', _dcc_source('Thickness:'), 'float', 0.0, translation_context='MWK:operators/option_windows.py:412')], _run_extrude, missing=(_dcc_source('Smoothing angle'), _dcc_source('Curve'), _dcc_source('Taper'), _dcc_source('Twist')), translation_context='MWK:operators/option_windows.py:410'), Window('bevel', _dcc_source('Bevel Options'), _dcc_source('Bevel'), None, [F('offset_type', _dcc_source('Offset type:'), 'enum', _dcc_source('Fractional (prevents inside out bevels)'), items=(_dcc_source('Fractional (prevents inside out bevels)'), _dcc_source('Absolute')), translation_context='MWK:operators/option_windows.py:415'), F('width', _dcc_source('Width:'), 'float', 0.5, lo=0.0, hi=1.0, translation_context='MWK:operators/option_windows.py:417'), F('segments', _dcc_source('Segments:'), 'int', 1, lo=1, hi=50, translation_context='MWK:operators/option_windows.py:417'), F('depth', _dcc_source('Depth:'), 'float', 1.0, lo=-1.0, hi=1.0, translation_context='MWK:operators/option_windows.py:418')], _run_bevel, paths=('Edit Mesh/Bevel',), missing=(_dcc_source('Offset space'), _dcc_source('Mitering / Miter Along'), _dcc_source('Chamfer'), _dcc_source('Smoothing Angle'), _dcc_source('Automatically fit bevel to object')), translation_context='MWK:operators/option_windows.py:414'), Window('bridge', _dcc_source('Bridge Options'), _dcc_source('Bridge'), None, [F('divisions', _dcc_source('Divisions:'), 'int', 5, lo=0, hi=100, translation_context='MWK:operators/option_windows.py:422'), F('twist', _dcc_source('Twist:'), 'int', 0, lo=-100, hi=100, translation_context='MWK:operators/option_windows.py:422')], lambda c, v: _components(c, 'mesh.bridge_edge_loops', 'EDGE', number_cuts=v['divisions'], twist_offset=v['twist']), paths=('Edit Mesh/Bridge',), missing=(_dcc_source('Bridge type: Smooth path / curve'), _dcc_source('Taper'), _dcc_source('Smoothing angle')), translation_context='MWK:operators/option_windows.py:421'), Window('merge', _dcc_source('Merge Vertices Options'), _dcc_source('Merge'), None, [F('threshold', _dcc_source('Threshold:'), 'length', 0.01, lo=0.0, hi=1.0, translation_context='MWK:operators/option_windows.py:427'), F('always_two', '', 'bool', True, text=_zh_native('Always merge for two vertices', 'MWK:operators/option_windows.py:428'), translation_context='MWK:operators/option_windows.py:428')], lambda c, v: _components(c, 'allset.merge', 'VERT', threshold=v['threshold'], always_two=v['always_two']), paths=('Edit Mesh/Merge',), translation_context='MWK:operators/option_windows.py:426'), Window('parent_constraint', _dcc_source('Parent Constraint Options'), _dcc_source('Add'), ('allset.constrain', {'type': 'CHILD_OF'}), [F('maintain_offset', _dcc_source('Maintain offset:'), 'bool', True, translation_context='MWK:operators/option_windows.py:432'), F('all_t', _dcc_source('Translate:'), 'bool', True, text=_zh_native('All', 'MWK:operators/option_windows.py:433'), translation_context='MWK:operators/option_windows.py:433'), F('tx', '', 'bool', False, text=_zh_native('X', 'MWK:operators/option_windows.py:433'), translation_context='MWK:operators/option_windows.py:433'), F('ty', '', 'bool', False, text=_zh_native('Y', 'MWK:operators/option_windows.py:434'), translation_context='MWK:operators/option_windows.py:434'), F('tz', '', 'bool', False, text=_zh_native('Z', 'MWK:operators/option_windows.py:434'), translation_context='MWK:operators/option_windows.py:434'), F('all_r', _dcc_source('Rotate:'), 'bool', True, text=_zh_native('All', 'MWK:operators/option_windows.py:435'), translation_context='MWK:operators/option_windows.py:435'), F('rx', '', 'bool', False, text=_zh_native('X', 'MWK:operators/option_windows.py:435'), translation_context='MWK:operators/option_windows.py:435'), F('ry', '', 'bool', False, text=_zh_native('Y', 'MWK:operators/option_windows.py:436'), translation_context='MWK:operators/option_windows.py:436'), F('rz', '', 'bool', False, text=_zh_native('Z', 'MWK:operators/option_windows.py:436'), translation_context='MWK:operators/option_windows.py:436'), F('weight', _dcc_source('Weight:'), 'float', 1.0, lo=0.0, hi=1.0, translation_context='MWK:operators/option_windows.py:437')], _constraint('CHILD_OF'), missing=(_dcc_source('Decompose near object'), _dcc_source('Animation Layer')), translation_context='MWK:operators/option_windows.py:431'), Window('point_constraint', _dcc_source('Point Constraint Options'), _dcc_source('Add'), ('allset.constrain', {'type': 'COPY_LOCATION'}), [F('maintain_offset', _dcc_source('Maintain offset:'), 'bool', False, translation_context='MWK:operators/option_windows.py:440')] + _CON_AXES, _constraint('COPY_LOCATION'), missing=(_dcc_source('Offset'), _dcc_source('Animation Layer')), translation_context='MWK:operators/option_windows.py:439'), Window('orient_constraint', _dcc_source('Orient Constraint Options'), _dcc_source('Add'), ('allset.constrain', {'type': 'COPY_ROTATION'}), [F('maintain_offset', _dcc_source('Maintain offset:'), 'bool', False, translation_context='MWK:operators/option_windows.py:443')] + _CON_AXES, _constraint('COPY_ROTATION'), missing=(_dcc_source('Offset'), _dcc_source('Animation Layer')), translation_context='MWK:operators/option_windows.py:442'), Window('set_key', _dcc_source('Set Key Options'), _dcc_source('Set Key'), ('allset.set_key', {}), [F('hierarchy', _dcc_source('Hierarchy:'), 'enum', _dcc_source('Selected'), items=(_dcc_source('Selected'), _dcc_source('Below')), translation_context='MWK:operators/option_windows.py:446')], _run_set_key, missing=(_dcc_source('Set keys on: manipulator handles'), _dcc_source('Set keys at: Prompt'), 'Set IK/FK keys', _dcc_source('Channels: From Channel Box'), _dcc_source('Control points'), _dcc_source('Shapes')), translation_context='MWK:operators/option_windows.py:445'), Window('bake_simulation', _dcc_source('Bake Simulation Options'), _dcc_source('Bake'), ('allset.bake_simulation', {}), [F('hierarchy', _dcc_source('Hierarchy:'), 'enum', _dcc_source('Selected'), items=(_dcc_source('Selected'), _dcc_source('Below')), translation_context='MWK:operators/option_windows.py:450'), F('time_range', _dcc_source('Time range:'), 'enum', _dcc_source('Time Slider'), items=(_dcc_source('Time Slider'), _dcc_source('Start/End')), translation_context='MWK:operators/option_windows.py:451'), F('start', _dcc_source('Start time:'), 'float', 0.0, translation_context='MWK:operators/option_windows.py:452'), F('end', _dcc_source('End time:'), 'float', 10.0, translation_context='MWK:operators/option_windows.py:452'), F('sample_by', _dcc_source('Sample by:'), 'float', 1.0, lo=1.0, hi=100.0, translation_context='MWK:operators/option_windows.py:453'), F('keep_unbaked', _dcc_source('Keep unbaked keys:'), 'bool', True, translation_context='MWK:operators/option_windows.py:454'), F('disable_implicit', _dcc_source('Disable implicit control:'), 'bool', True, translation_context='MWK:operators/option_windows.py:455')], _run_bake, missing=(_dcc_source('Channels: From Channel Box'), _dcc_source('Bake To: New Layer'), _dcc_source('Smart Bake'), _dcc_source('Sparse curve bake')), translation_context='MWK:operators/option_windows.py:449'), Window('uv_planar', _dcc_source('Planar Mapping Options'), _dcc_source('Project'), ('allset.uv_planar', {}), [F('fit', _dcc_source('Fit projection to:'), 'enum', _dcc_source('Bounding box'), items=(_dcc_source('Best plane'), _dcc_source('Bounding box')), translation_context='MWK:operators/option_windows.py:458'), F('project_from', _dcc_source('Project from:'), 'enum', _dcc_source('X axis'), items=(_dcc_source('X axis'), _dcc_source('Y axis'), _dcc_source('Z axis'), _dcc_source('Camera')), translation_context='MWK:operators/option_windows.py:459')], _run_uv_planar, paths=('UV/Planar',), missing=('Keep image width/height ratio', _dcc_source('Insert projection before deformers'), _dcc_source('Create new UV Set')), translation_context='MWK:operators/option_windows.py:457'), Window('uv_automatic', _dcc_source('Polygon Automatic Mapping Options'), _dcc_source('Project'), ('allset.uv_automatic', {}), [F('planes', _dcc_source('Planes:'), 'enum', '6', items=('3', '4', '5', '6', '8', '12'), translation_context='MWK:operators/option_windows.py:463'), F('spacing', _dcc_source('Percentage space:'), 'float', 0.2, lo=0.0, hi=5.0, translation_context='MWK:operators/option_windows.py:464')], _run_uv_auto, paths=('UV/Automatic',), missing=(_dcc_source('Optimize for'), _dcc_source('Shell layout / Scale mode / Shell stacking'), _dcc_source('Create new UV set')), translation_context='MWK:operators/option_windows.py:462'), Window('new_scene', _dcc_source('New Scene Options'), _dcc_source('New'), None, [F('keep_units', '', 'bool', False, text=_zh_native('Do not reset working units', 'MWK:operators/option_windows.py:467'), translation_context='MWK:operators/option_windows.py:467'), F('linear', _dcc_source('Linear:'), 'enum', _dcc_source('centimeter'), items=(_dcc_source('millimeter'), _dcc_source('centimeter'), _dcc_source('meter'), _dcc_source('inch'), _dcc_source('foot'), _dcc_source('yard')), translation_context='MWK:operators/option_windows.py:468'), F('angular', _dcc_source('Angular:'), 'enum', _dcc_source('degrees'), items=(_dcc_source('degrees'), _dcc_source('radians')), translation_context='MWK:operators/option_windows.py:469'), F('fps', _dcc_source('Time:'), 'enum', _dcc_source('24 fps'), items=(_dcc_source('12 fps'), _dcc_source('15 fps'), _dcc_source('23.976 fps'), _dcc_source('24 fps'), _dcc_source('25 fps'), _dcc_source('29.97 fps'), _dcc_source('30 fps'), _dcc_source('48 fps'), _dcc_source('50 fps'), _dcc_source('60 fps')), translation_context='MWK:operators/option_windows.py:470'), F('play_start', _dcc_source('Playback start:'), 'int', 1, lo=-100000, translation_context='MWK:operators/option_windows.py:472'), F('play_end', _dcc_source('Playback end:'), 'int', 120, lo=-100000, translation_context='MWK:operators/option_windows.py:472'), F('anim_start', _dcc_source('Animation start:'), 'int', 1, lo=-100000, translation_context='MWK:operators/option_windows.py:473'), F('anim_end', _dcc_source('Animation end:'), 'int', 200, lo=-100000, translation_context='MWK:operators/option_windows.py:473')], _run_new_scene, paths=('File/New Scene',), missing=(_dcc_source('Enable default scene'), _dcc_source('Show the Compass'), _dcc_source('Color Management enabled')), translation_context='MWK:operators/option_windows.py:466'), Window('save_scene', _dcc_source('Save Scene Options'), _dcc_source('Save Scene'), None, [F('incremental', '', 'bool', False, text=_zh_native('Incremental save', 'MWK:operators/option_windows.py:476'), translation_context='MWK:operators/option_windows.py:476'), F('compressed', '', 'bool', False, text=_zh_native('Compressed save', 'MWK:operators/option_windows.py:477'), translation_context='MWK:operators/option_windows.py:477')], _run_save, paths=('File/Save Scene',), missing=(_dcc_source('Limit incremental saves'), 'Save Thumbnail/Playblast', _dcc_source('USD edits')), translation_context='MWK:operators/option_windows.py:475')]

def _extend():
    from . import option_windows_curves, option_windows_deform, option_windows_display, option_windows_edit, option_windows_modify, option_windows_render, option_windows_rig, option_windows_surfaces, option_windows_visualize, option_windows_mesh_display
    WINDOWS.extend(option_windows_rig.WINDOWS + option_windows_edit.WINDOWS + option_windows_deform.WINDOWS + option_windows_display.WINDOWS + option_windows_render.WINDOWS + option_windows_curves.WINDOWS + option_windows_modify.WINDOWS + option_windows_visualize.WINDOWS + option_windows_surfaces.WINDOWS + option_windows_mesh_display.WINDOWS)
    from . import option_windows_misc196, option_windows_prims
    WINDOWS.extend(option_windows_prims.WINDOWS + option_windows_misc196.WINDOWS)
    from . import option_windows_197
    WINDOWS.extend(option_windows_197.WINDOWS)
    from . import deformers_205a, deformers_205b, pins_205
    WINDOWS.extend(deformers_205a.windows() + deformers_205b.windows() + pins_205.windows())
    from . import option_windows_199
    WINDOWS.extend(option_windows_199.WINDOWS)
    from . import option_windows_curves207
    WINDOWS.extend(option_windows_curves207.WINDOWS)
    from . import motion_path_228
    WINDOWS.extend(motion_path_228.windows())
_extend()
_BY_KEY = {w.key: w for w in WINDOWS}

def find(action):
    """The option window of a menu / marking-menu / shelf action (raw ``menu_map`` value or normalised), or None."""
    from ..ui import menu_map
    if isinstance(action, tuple) and len(action) == 3 and (action[0] in ('op', 'v3d')) and isinstance(action[2], dict):
        s = action
    else:
        s = menu_map.normalize(action)
    if s is None or s[0] not in ('op', 'v3d'):
        return None
    (target, props) = (s[1], s[2])
    for w in WINDOWS:
        if w.match is None:
            continue
        (op, want) = w.match
        if op == target and all((props.get(k) == val for (k, val) in want.items())):
            return w
    return None

def find_path(path):
    """The option window of a Maya menu path (explicit ``paths`` first, then its menu twin's, then its action). A twin
    (``menu_map.TWINS``) runs the same Maya command, so its box opens the same window (step 211: nHair > Modify Curves
    Bend / Curl / Scale Curvature = the Curves windows, audit 16 quant)."""
    from ..ui import menu_map
    source = menu_map.TWINS.get(path)
    for w in WINDOWS:
        if path in w.paths:
            return w
    for w in WINDOWS:
        if source is not None and source in w.paths:
            return w
    return find(menu_map.MAP.get(path)) if path in menu_map.MAP else None

def _prefs():
    from .. import preferences
    try:
        return preferences.get()
    except KeyError:
        return None

def saved(key):
    prefs = _prefs()
    try:
        return json.loads(prefs.option_settings).get(key) if prefs is not None and prefs.option_settings else None
    except ValueError:
        return None

def store(key, values):
    prefs = _prefs()
    if prefs is None:
        return
    try:
        data = json.loads(prefs.option_settings) if prefs.option_settings else {}
    except ValueError:
        data = {}
    if values is None:
        data.pop(key, None)
    else:
        data[key] = values
    prefs.option_settings = json.dumps(data)

def values_of(window, holder):
    out = {}
    for f in window.fields:
        val = getattr(holder, f.name)
        out[f.name] = tuple(val) if f.kind.startswith('vec') else val
    return out

def run(window, context, values):
    """Run ``window``'s command with ``values`` (Maya values, defaults filled in)."""
    v = {**window.defaults(), **(values or {})}
    try:
        res = window.run(context, v)
    except RuntimeError as ex:
        return str(ex).strip().splitlines()[-1]
    return res

def run_saved(window, context):
    return run(window, context, saved(window.key))
_PATHS = {}

def _menu_path(window):
    """The first main-menu path whose action opens ``window`` (windows bound by action, not by path)."""
    if window.key not in _PATHS:
        from ..ui import menu_map
        _PATHS[window.key] = next((p for (p, a) in menu_map.MAP.items() if not p.startswith(('Graph Editor/', 'Dope Sheet/', 'UV Editor/')) and find(a) is window), None)
    return _PATHS[window.key]

def _record(window, context, res):
    """A window command that ran is Maya's last command (G repeats it with the saved values, step 175)."""
    if not window.click_saved or isinstance(res, str) or (not (isinstance(res, set) and 'FINISHED' in res)):
        return
    from ..ui import menu_map
    path = window.paths[0] if window.paths else _menu_path(window)
    action = menu_map.MAP.get(path) if path else window.match
    if action is None:
        return
    from . import repeat_maya
    repeat_maya.record(path.rsplit('/', 1)[-1] if path else window.title, action, path, context)

def _apply_update(window):

    def update(self, context):
        if not self.apply_now:
            return
        apply_run = getattr(window, 'apply_run', None)
        if apply_run is not None:
            res = apply_run(context, {**window.defaults(), **values_of(window, self)})
        else:
            res = run(window, context, values_of(window, self))
        store(window.key, values_of(window, self))
        if apply_run is None:
            _record(window, context, res)
        self.apply_now = False
        if isinstance(res, str):
            from ..ui import notices
            notices.show(f'{window.title}: {res}')
    return update

def _save_update(window):

    def update(self, context):
        if self.save_now:
            store(window.key, values_of(window, self))
            self.save_now = False
    return update

def _reset_update(window):

    def update(self, context):
        if self.reset_now:
            for f in window.fields:
                setattr(self, f.name, f.default)
            store(window.key, None)
            self.reset_now = False
    return update

def _make(window):
    ann = {f.name: f.prop() for f in window.fields}
    ann['apply_now'] = BoolProperty(name=_zh_native('Apply', 'MWK:operators/option_windows.py:668'), options={'SKIP_SAVE'}, update=_apply_update(window), description=_zh_native('Run with these settings and keep the window open (Maya Apply)', 'MWK:operators/option_windows.py:668'), translation_context='MWK:operators/option_windows.py:668')
    ann['save_now'] = BoolProperty(name=_zh_native('Save Settings', 'MWK:operators/option_windows.py:670'), options={'SKIP_SAVE'}, update=_save_update(window), description=_zh_native('Keep these settings for next time (Maya Edit > Save Settings)', 'MWK:operators/option_windows.py:670'), translation_context='MWK:operators/option_windows.py:670')
    ann['reset_now'] = BoolProperty(name=_zh_native('Reset Settings', 'MWK:operators/option_windows.py:672'), options={'SKIP_SAVE'}, update=_reset_update(window), description=_zh_native("Back to Maya's factory settings (Maya Edit > Reset Settings)", 'MWK:operators/option_windows.py:672'), translation_context='MWK:operators/option_windows.py:672')

    def invoke(self, context, event):
        if window.key == 'paint_skin_weights':
            return bpy.ops.allset.weight_workspace('INVOKE_DEFAULT')
        for (name, val) in (saved(window.key) or {}).items():
            if name in ann:
                try:
                    setattr(self, name, val)
                except (TypeError, ValueError):
                    pass
        return context.window_manager.invoke_props_dialog(self, width=window.width, title=_zh(window.title, window.translation_context), confirm_text=_zh(window.action, window.translation_context))

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.prop(self, 'save_now', toggle=True)
        row.prop(self, 'reset_now', toggle=True)
        layout.separator()
        col = layout.column()
        col.use_property_split = True
        col.use_property_decorate = False
        fields = list(window.fields)
        i = 0
        while i < len(fields):
            f = fields[i]
            if f.kind == 'bool' and f.text in ('X', 'Y', 'Z'):
                split = col.split(factor=0.4)
                split.label(text=_dcc_display(''))
                row = split.row()
                row.use_property_split = False
                while i < len(fields) and fields[i].kind == 'bool' and (fields[i].text in ('X', 'Y', 'Z')):
                    row.prop(self, fields[i].name, text=_zh(fields[i].text, 'MWK:operators/option_windows.py:707'))
                    i += 1
                continue
            i += 1
            if f.kind == 'bool':
                col.column(heading=f.label.rstrip(':')).prop(self, f.name, text=_zh(f.text or '', 'MWK:operators/option_windows.py:712'))
                continue
            elif f.kind == 'enum':
                col.row().prop(self, f.name, text=_zh(f.label.rstrip(':') or ' ', 'MWK:operators/option_windows.py:717'), expand=bool(f.label) and len(f.items) <= 4)
            else:
                col.prop(self, f.name, text=_zh(f.label.rstrip(':'), 'MWK:operators/option_windows.py:720'))
        if window.missing:
            sub = layout.column(align=True)
            sub.enabled = False
            sub.label(text=_zh('Not in Blender:', 'MWK:operators/option_windows.py:724'))
            for name in window.missing:
                sub.label(text=_zh('    ' + name, 'MWK:operators/option_windows.py:726'))
        layout.separator()
        layout.prop(self, 'apply_now', toggle=True, text=_zh(window.apply_text, window.translation_context))

    def execute(self, context):
        values = values_of(window, self)
        store(window.key, values)
        res = run(window, context, values)
        if isinstance(res, str):
            self.report({'WARNING'}, _zh(res, 'MWK:operators/option_windows.py:735'))
            return {'CANCELLED'}
        _record(window, context, res)
        return {'FINISHED'} if res is None or 'FINISHED' in res else {'CANCELLED'}
    return type(f'ALLSET_OT_opt_{window.key}', (bpy.types.Operator,), {'bl_translation_context': 'MWK:operators/option_windows.py:740', '__annotations__': ann, 'bl_idname': window.idname, 'bl_label': _zh_native(window.title, 'MWK:operators/option_windows.py:740'), 'bl_description': _zh_native(f'Maya {window.title}', 'MWK:operators/option_windows.py:740'), 'bl_options': {'UNDO'}, 'invoke': invoke, 'draw': draw, 'execute': execute})

class ALLSET_OT_option_generic(bpy.types.Operator):
    """Option box of a Maya command whose settings Blender has no equivalent for: the window says so and runs
    the command (Maya: every option box opens a window)"""
    bl_translation_context = 'MWK:operators/option_windows.py:750'
    bl_idname = 'allset.option_generic'
    bl_label = _zh_native('Options', 'MWK:operators/option_windows.py:750')
    bl_description = _zh_native('Option box of a Maya command whose settings Blender has no equivalent for: the window says so and runs\nthe command (Maya: every option box opens a window)', 'MWK:operators/option_windows.py:750')
    bl_options = {'INTERNAL'}
    item: bpy.props.StringProperty(options={'SKIP_SAVE'}, translation_context='MWK:operators/option_windows.py:753')

    def invoke(self, context, event):
        from .option_windows_render import no_options_text
        text = no_options_text(self.item, context.scene)
        if text:
            self.report({'WARNING'}, _zh(text, 'MWK:operators/option_windows.py:759'))
            return {'CANCELLED'}
        label = self.item.rsplit('/', 1)[-1].rstrip('.').split('#')[0]
        return context.window_manager.invoke_props_dialog(self, width=400, title=_zh(f'{label} Options', 'MWK:operators/option_windows.py:762'), confirm_text=_zh(label, 'MWK:operators/option_windows.py:763'))

    def draw(self, context):
        from ..ui import chrome, notices
        n = notices.notice(self.item)
        text = _dcc_source("Maya's settings for this command have no Blender equivalent: it runs with Blender's own.") + (f' {n[1]}' if n else '')
        chrome.paragraph(self.layout, context, text, width=380)

    def execute(self, context):
        from ..ui import menu_map
        from ..marking.modal import run_action
        action = menu_map.MAP.get(self.item)
        if action is None:
            return {'CANCELLED'}
        try:
            run_action(context, action, path=self.item)
        except RuntimeError as ex:
            from . import maya_errors
            maya_errors.report_nested(self, ex)
            return {'CANCELLED'}
        return {'FINISHED'}
classes = tuple((_make(w) for w in WINDOWS)) + (ALLSET_OT_option_generic,)
